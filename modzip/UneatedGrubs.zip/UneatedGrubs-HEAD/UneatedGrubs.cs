﻿using Modding;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UObject = UnityEngine.Object;

namespace UneatedGrubs
{
    public class UneatedGrubs : Mod, ITogglableMod
    {
        internal static UneatedGrubs Instance;

        //public override List<ValueTuple<string, string>> GetPreloadNames()
        //{
        //    return new List<ValueTuple<string, string>>
        //    {
        //        new ValueTuple<string, string>("White_Palace_18", "White Palace Fly")
        //    };
        //}

        public override string GetVersion() => Assembly.GetExecutingAssembly().GetName().Version.ToString();

        public UneatedGrubs() : base("Uneated Grubs") { }

        public override void Initialize(Dictionary<string, Dictionary<string, GameObject>> preloadedObjects)
        {
            if (UneatedGrubs.Instance != null) return;

            UneatedGrubs.Instance = this;

            // hooks
            On.DeactivateIfPlayerdataTrue.OnEnable += DeactivateIfPlayerdataTrue_OnEnable;

            this.Log("Loaded Uneaten Grubs!");
        }

        private void DeactivateIfPlayerdataTrue_OnEnable(On.DeactivateIfPlayerdataTrue.orig_OnEnable orig, DeactivateIfPlayerdataTrue self)
        {
            GameManager gm_hook = GameManager.instance;
            PlayerData pd_hook = gm_hook.playerData;
            pd_hook.SetBool("fatGrubKing", false);
            orig(self);
        }

        public void Unload()
        {
            UneatedGrubs.Instance = null;

            // destroy hooks
            On.DeactivateIfPlayerdataTrue.OnEnable -= DeactivateIfPlayerdataTrue_OnEnable;

            this.Log("Unloaded Uneaten Grubs!");
        }
    }
}