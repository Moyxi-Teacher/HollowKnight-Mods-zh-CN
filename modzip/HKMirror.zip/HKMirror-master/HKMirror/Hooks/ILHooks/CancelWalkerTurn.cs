namespace HKMirror.Hooks.ILHooks;

/// <summary>
///     Contains all correct IL Hooks for CancelWalkerTurn.<br />
///     Gives the correct GetStateMachineTarget version of IEnumerators ILs that run after every yeild return.<br />
///     Includes ILHooks that aren't in the IL namespace such as API generated functions and property getters/setters.
/// </summary>
public static class ILCancelWalkerTurn
{
    public static event ILContext.Manipulator Apply
    {
        add => IL.CancelWalkerTurn.Apply += value;
        remove => IL.CancelWalkerTurn.Apply -= value;
    }
}