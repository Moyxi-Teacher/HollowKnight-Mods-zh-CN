# Abyssal Bloom
Takes the walk boost from crystalmaster and further multiples it by 5% on half hp and 15% at 1 hp.

Works with Lemm's strength by multiplying the boost it(Lemm's strength) already gives with the usual values.

# Boon of Hallownest

Scales spell size the same way normal spells scale with Shaman Amp.

Slows down daggers the same way Snail Soul slows down fireballs.

If Vepsa's Vengence is equiped,wraiths will be replaced with bees and not Boon Blasts.

# Vessel's Lament
If florist's blessing is equipped,damage of blasts is doubled(can be doubled again(so,quadrupled) with deep focus).
