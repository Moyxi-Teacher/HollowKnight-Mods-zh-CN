# 资源文件说明

本目录下的 **二进制资源（dll / onnx 模型）不随源码分发**，需自行下载放入本目录。
原因：① 体积较大（dll 数 MB、模型数十 MB），不适合放 git；② 部分模型受各自协议约束；③ YOLO 模型由用户自行训练。

放置完成后，目录结构应为：

```
src-tauri/resources/
├── README.md                              ← 本文件
├── onnxruntime.dll                        ← 用户下载（ONNX Runtime CPU build）
└── models/
    ├── ch_PP-OCRv5_rec_mobile_infer.onnx  ← 用户下载（PaddleOCR PP-OCRv5 rec mobile）
    └── yolo.onnx                          ← 用户自训练（英雄血条检测）
```

> ⚠️ 这些文件已在根目录 `.gitignore` 中排除，不会被提交到仓库。

---

## 1. onnxruntime.dll

ONNX Runtime 的 Windows 动态库，运行期由 Rust `ort` crate（`load-dynamic` feature）通过 `ORT_DYLIB_PATH` 加载。

### 下载步骤

1. 访问 [ONNX Runtime Releases](https://github.com/microsoft/onnxruntime/releases)。
2. 下载 **ONNX Runtime 1.22.x** 版本的 `onnxruntime-win-x64-*.zip`（CPU build）。
   - 版本需与 `src-tauri/Cargo.toml` 中 `ort = "=2.0.0-rc.10"` 兼容（对应 ONNX Runtime 1.22.x）。
   - **务必用 CPU build**，不要用 DirectML build（DirectML build 会依赖 `DirectML.dll`，本项目未打包）。
3. 解压后，将 `lib/onnxruntime.dll` 复制到本目录（`src-tauri/resources/onnxruntime.dll`）。

### 验证

```powershell
# 确认 dll 是 CPU build（不应依赖 DirectML.dll）
dumpbin /dependents src-tauri\resources\onnxruntime.dll | findstr /i "DirectML"
# 上面命令应无输出（即不依赖 DirectML.dll）
```

---

## 2. ch_PP-OCRv5_rec_mobile_infer.onnx

PaddleOCR PP-OCRv5 的 mobile rec 模型，用于英雄名称文字识别。

### 下载步骤

1. 访问 [PaddleOCR 模型库](https://paddlepaddle.org.cn/models) 或 [PaddleOCR GitHub Releases](https://github.com/PaddlePaddle/PaddleOCR)。
2. 下载 **PP-OCRv5 rec mobile** 推理模型（ONNX 格式），文件名 `ch_PP-OCRv5_rec_mobile_infer.onnx`。
3. 放入 `src-tauri/resources/models/` 目录。

### 字典说明

- 本项目**不需要外部字典文件**（`ppocr_keys_v1.txt` 等）。
- PP-OCRv5 rec mobile 是多语言模型，输出 18385 类（1 blank + 18384 字符：简中/繁中/拼音/英文/日文）。
- 字典直接从模型 ONNX metadata 的 `character` 字段读取（`paddle-ocr-rs` 的 `init_model` 路径），与模型类别严格对应。
- 若使用外部 txt 字典（`init_model_dict_file` 路径），会因为字典字符数（6623）与模型类别数（18384）不匹配导致 argmax 索引映射错误，识别结果全是乱码。

### 原始模型转换（可选）

如拿到的是 PaddlePaddle 原生模型（`.pdmodel` + `.pdiparams`），需用 `paddle2onnx` 转换：

```bash
pip install paddle2onnx
paddle2onnx --model_dir inference/ --model_filename inference.pdmodel --params_filename inference.pdiparams --save_file ch_PP-OCRv5_rec_mobile_infer.onnx --opset_version 14
```

---

## 3. yolo.onnx

自训练的 YOLOv8 模型，用于棋盘英雄血条检测（一键卖出功能）。本项目**不含模型文件**，需用户自行训练并导出。

### 训练要点

- **数据**：在游戏内截图棋盘英雄区域，标注英雄血条（单类 `health_bar`）。
- **模型**：YOLOv8n（最轻量，足够单类检测）。
- **输入尺寸**：640×640（与 `src-tauri/src/yolo.rs` 顶部 `INPUT_SIZE` 常量对齐）。
- **类别数**：1（仅血条；与 `NUM_CLASSES` 常量对齐）。
- **导出**：`yolo export model=yolo8n.pt format=onnx imgsz=640 dynamic=False`。
- **后处理**：代码兼容两种 YOLOv8 标准导出输出布局：`[1, 4+nc, anchors]` 或 `[1, anchors, 4+nc]`；置信度阈值 0.25，NMS IoU 0.45。
- **命名**：导出后命名为 `yolo.onnx`，放入 `src-tauri/resources/models/`。

### 标注建议

- 血条为英雄头顶的细长绿色/红色条，标注时框住整条血条（包含背景边框）。
- 训练集建议 200+ 张截图，覆盖不同英雄、不同血量、不同阵容站位。
- 验证集独立标注 50+ 张，监控 mAP。

### 与代码的对接

若你的模型输入尺寸 / 类别数不同：

- 修改 `src-tauri/src/yolo.rs` 顶部的 `INPUT_SIZE` 和 `NUM_CLASSES` 常量。
- 重新 `npm run tauri build` 即可生效。

---

## 模型加载与资源释放

- **OCR 模型**：应用启动时加载，全程驻留内存（约 30-50 MB），不使用时不释放。模型常驻避免每次拿牌重新加载的延迟（加载约 500ms，推理约 30ms）。
- **YOLO 模型**：应用启动时加载，全程驻留内存（约 10-20 MB），不使用时不释放。模型缺失时走 `new_disabled()` 降级，应用仍可启动，一键卖出功能调用时返回错误但不崩溃。
- **CPU 占用**：模型不推理时不占用 CPU（仅占用内存）；推理时按 `available_parallelism().clamp(2, 4)` 限定的线程数并行。

如需进一步降低内存占用，可改为「按需加载 + 用完释放」，但会增加每次拿牌/卖出的延迟。
