//! 找图方案可行性验证脚本（独立工具，不依赖主项目内部模块）
//!
//! 用途：验证《游戏找图多尺度模板匹配方案》在 TFT 商店场景下是否可行。
//! 用真实游戏截图 + 官网 624×318 卡牌原图，跑 ZNCC（零均值归一化互相关）匹配，
//! 输出每个卡牌区域的 top-N 英雄匹配 + 分数，由用户对比 ground truth 判断可行性。
//!
//! # 用法
//!
//! ```text
//! cargo run --example verify_image_match -- \
//!     --screenshot <截图路径> \
//!     --season <s17 | s16m17> \
//!     --regions "x1,y1,w1,h1;x2,y2,w2,h2;..." \
//!     [--top 5] \
//!     [--scale-radius 5] \
//!     [--mode crop80 | full] \
//!     [--cache-dir ./card_cache]
//! ```
//!
//! # 参数说明
//!
//! - `--screenshot`：游戏商店截图路径（PNG/JPG）。建议截整屏，包含 5 张卡牌。
//! - `--season`：赛季代号，与项目 GameMode.season 一致（如 s17=星神、s16m17=恭喜发财）。
//! - `--regions`：5 个卡牌区域的屏幕坐标，分号分隔。格式 `x,y,w,h`（屏幕物理像素）。
//!   建议框选整张卡牌（含头像+名字+费用），不是只框名字条带。
//!   可只指定 1 个区域做快速验证。
//! - `--top`：每个区域输出 top-N 匹配（默认 5）。
//! - `--scale-radius`：高度搜索半径 R，缩放高度范围 [h-R, h+R]（默认 5）。
//! - `--mode`：模板裁剪方式：
//!   - `crop80`（默认）：按文档方案，距右 50、距上 50 的 80×80 方块（避开原图左侧多余内容）。
//!   - `full`：整张缩放后的卡牌作模板。
//! - `--cache-dir`：卡牌原图缓存目录（默认 ./card_cache）。
//!
//! # 输出
//!
//! 每个区域一个表格，列出 top-N 英雄 + ZNCC 分数 + 最佳尺度。
//! ZNCC ∈ [-1, 1]，越接近 1 越相似。一般认为 ≥0.85 且与第二名拉开差距才算可行。
//!
//! # 决策标准
//!
//! - 若每个区域 top-1 都正确，且 top-1 ≥ 0.85、top-1 - top-2 ≥ 0.05 → 可行，可集成。
//! - 若 top-1 频繁错误或分数普遍 < 0.7 → 不可行（修饰层干扰过大），放弃或换颜色直方图。
//! - 介于两者之间 → 调参（scale_radius / mode / 阈值）再测。

use anyhow::{anyhow, Context, Result};
use image::{imageops, DynamicImage, GrayImage, RgbaImage};
use rayon::prelude::*;
use reqwest::Client;
use serde::Deserialize;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicUsize, Ordering};

// ============ 数据模型（与主项目 models.rs 一致，但独立定义避免依赖内部模块） ============

#[derive(Deserialize, Debug, Clone)]
struct VersionConfig {
    #[serde(rename = "idSeason")]
    id_season: String,
    #[serde(rename = "urlChessData")]
    url_chess_data: String,
    #[serde(rename = "stringName", default)]
    string_name: String,
}

#[derive(Deserialize, Debug, Clone)]
struct ChessWrap {
    #[serde(rename = "modeId", default)]
    #[allow(dead_code)]
    mode_id: String,
    data: Vec<Chess>,
}

#[derive(Deserialize, Debug, Clone)]
struct Chess {
    #[serde(rename = "chessId")]
    chess_id: String,
    #[serde(rename = "displayName")]
    display_name: String,
    #[serde(rename = "raceIds", default)]
    race_ids: String,
    #[serde(rename = "jobIds", default)]
    job_ids: String,
}

impl Chess {
    /// 过滤道具/锻造器（raceIds 与 jobIds 均空）
    fn is_real_hero(&self) -> bool {
        !self.race_ids.trim().is_empty() || !self.job_ids.trim().is_empty()
    }
}

// ============ 常量 ============

const VERSION_CONFIG_URL: &str = "https://lol.qq.com/zmtftzone/public-lib/versionconfig.json";
/// 卡牌原图 CDN 基址：{base}{season}/624x318/{chessId}.{png|jpg}
const CARD_IMG_BASE: &str = "https://game.gtimg.cn/images/lol/tftstore/";
/// 原图尺寸（文档第 1 节）
const ORIG_W: u32 = 624;
const ORIG_H: u32 = 318;
/// 文档方案模板参数（第 4 节）：距右 50、距上 50、80×80
const TMPL_MARGIN_RIGHT: u32 = 50;
const TMPL_MARGIN_TOP: u32 = 50;
const TMPL_SIZE: u32 = 80;

// ============ 入口 ============

#[tokio::main]
async fn main() -> Result<()> {
    let args = parse_args()?;
    eprintln!("[verify] 配置: season={}, regions={}, top={}, scale_radius={}, mode={}",
        args.season, args.regions.len(), args.top, args.scale_radius, args.mode);

    // 1. 拉英雄列表（versionconfig.json → chess.js）
    eprintln!("[verify] 拉取英雄列表...");
    let heroes = fetch_heroes(&args.season).await?;
    eprintln!("[verify] 共 {} 个英雄", heroes.len());

    // 2. 下载卡牌原图（带缓存）
    eprintln!("[verify] 下载卡牌原图到 {}...", args.cache_dir.display());
    let client = Client::builder()
        .user_agent("Mozilla/5.0 TFT-AutoPick-Verify")
        .build()?;
    let mut templates = Vec::with_capacity(heroes.len());
    for h in &heroes {
        match download_card_image(&client, &args.season, &h.chess_id, &args.cache_dir).await {
            Ok(path) => {
                let img = image::open(&path)
                    .with_context(|| format!("打开卡牌图失败: {}", path.display()))?
                    .to_luma8();
                templates.push((h.clone(), img));
            }
            Err(e) => {
                eprintln!("[verify]   跳过 {}({}): {}", h.display_name, h.chess_id, e);
            }
        }
    }
    eprintln!("[verify] 成功加载 {} 张卡牌模板", templates.len());
    if templates.is_empty() {
        return Err(anyhow!("无可用模板，检查网络或 season 是否正确"));
    }

    // 3. 加载截图
    eprintln!("[verify] 加载截图: {}", args.screenshot.display());
    let screenshot = image::open(&args.screenshot)
        .with_context(|| format!("打开截图失败: {}", args.screenshot.display()))?
        .to_rgba8();
    eprintln!("[verify] 截图尺寸: {}x{}", screenshot.width(), screenshot.height());

    // 4. 对每个区域跑模板匹配
    for (idx, region) in args.regions.iter().enumerate() {
        eprintln!("\n========== 区域 {} ==========", idx + 1);
        eprintln!("ROI: x={}, y={}, w={}, h={}", region.0, region.1, region.2, region.3);

        let crop = crop_screenshot(&screenshot, *region);
        if crop.width() < TMPL_SIZE || crop.height() < TMPL_SIZE {
            eprintln!("[verify] 区域太小 ({}x{})，至少需要 {}x{}，跳过",
                crop.width(), crop.height(), TMPL_SIZE, TMPL_SIZE);
            continue;
        }
        let search = to_gray(&crop);
        eprintln!("[verify] 搜索区域: {}x{}", search.width(), search.height());

        // 搜索区域积分图只算一次，所有英雄模板共享（O(1) 窗口和/平方和查询）
        eprintln!("[verify] 构建积分图...");
        let search_integral = IntegralImage::from_gray(&search);

        // 对每个英雄模板并行匹配：rayon 并行 + 每 10 个打印进度
        let total = templates.len();
        let progress = AtomicUsize::new(0);
        eprintln!("[verify] 开始匹配 {} 个英雄...", total);
        let mut scores: Vec<(Chess, f32, u32)> = templates
            .par_iter()
            .map(|(hero, tmpl_orig)| {
                let (score, best_h) = match_template(
                    &search,
                    &search_integral,
                    tmpl_orig,
                    region.3, // 用户框选高度
                    args.scale_radius,
                    args.mode,
                );
                let done = progress.fetch_add(1, Ordering::Relaxed) + 1;
                if done % 10 == 0 || done == total {
                    eprintln!("[verify]   匹配进度: {}/{}", done, total);
                }
                (hero.clone(), score, best_h)
            })
            .collect();

        // 按分数降序取 top-N
        scores.sort_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        eprintln!("\nTop-{} 匹配:", args.top);
        eprintln!("{:<4} {:<12} {:<10} {:<10} {}", "#", "chessId", "name", "score", "best_h");
        for (i, (hero, score, best_h)) in scores.iter().take(args.top).enumerate() {
            eprintln!(
                "{:<4} {:<12} {:<10} {:<10.4} {}",
                i + 1, hero.chess_id, hero.display_name, score, best_h
            );
        }

        // 输出 top-1 vs top-2 差距（决策关键指标）
        if scores.len() >= 2 {
            let gap = scores[0].1 - scores[1].1;
            eprintln!("\ntop-1 - top-2 差距: {:.4} {}", gap,
                if gap >= 0.05 { "✓ 拉开差距" } else { "✗ 差距过小，易混淆" });
        }
    }

    eprintln!("\n[verify] 完成。判断标准：top-1 正确 + score ≥ 0.85 + gap ≥ 0.05 → 可行");
    Ok(())
}

// ============ 英雄数据拉取 ============

/// 拉 versionconfig.json → 找 season → 拉 chess.js → 过滤真实英雄
async fn fetch_heroes(season: &str) -> Result<Vec<Chess>> {
    let client = Client::builder()
        .user_agent("Mozilla/5.0 TFT-AutoPick-Verify")
        .build()?;

    let configs: Vec<VersionConfig> = fetch_json(&client, VERSION_CONFIG_URL).await?;
    let cfg = configs
        .iter()
        .find(|c| c.id_season == season)
        .ok_or_else(|| anyhow!("season {} 不在 versionconfig（共{}条）", season, configs.len()))?;

    eprintln!("[verify] season={} 对应 {}", season, cfg.string_name);

    let chess_url = normalize_url(&cfg.url_chess_data);
    let wrap: ChessWrap = fetch_json(&client, &chess_url).await?;
    let heroes: Vec<Chess> = wrap.data.into_iter().filter(|c| c.is_real_hero()).collect();
    Ok(heroes)
}

/// 把 //game.gtimg.cn/... 补全为 https://
fn normalize_url(url: &str) -> String {
    if url.starts_with("//") {
        format!("https:{}", url)
    } else {
        url.to_string()
    }
}

async fn fetch_json<T: serde::de::DeserializeOwned>(client: &Client, url: &str) -> Result<T> {
    let resp = client.get(url).send().await?.error_for_status()?;
    let body = resp.bytes().await?;
    Ok(serde_json::from_slice(&body)?)
}

// ============ 卡牌原图下载（带缓存） ============

/// 下载某英雄的 624×318 卡牌原图。先试 .png 再试 .jpg（不同模式扩展名不同）。
/// 成功后缓存到 <cache_dir>/<season>/<chessId>.<ext>，下次直接读缓存。
async fn download_card_image(
    client: &Client,
    season: &str,
    chess_id: &str,
    cache_dir: &Path,
) -> Result<PathBuf> {
    let dir = cache_dir.join(season);
    std::fs::create_dir_all(&dir)?;

    // 先看缓存（png 或 jpg）
    for ext in &["png", "jpg"] {
        let cached = dir.join(format!("{}.{}", chess_id, ext));
        if cached.exists() {
            return Ok(cached);
        }
    }

    // 在线下载：先试 png，失败试 jpg
    for ext in &["png", "jpg"] {
        let url = format!("{}{}/624x318/{}.{}", CARD_IMG_BASE, season, chess_id, ext);
        match client.get(&url).send().await {
            Ok(resp) if resp.status().is_success() => {
                let bytes = resp.bytes().await?;
                let path = dir.join(format!("{}.{}", chess_id, ext));
                std::fs::write(&path, &bytes)?;
                eprintln!("[verify]   下载 {}({}) -> {}", chess_id, ext, path.file_name().unwrap().to_string_lossy());
                return Ok(path);
            }
            _ => continue,
        }
    }
    Err(anyhow!("png/jpg 均下载失败"))
}

// ============ 模板匹配（ZNCC） ============

/// 积分图（Summed-Area Table）：O(1) 计算任意矩形区域的像素和与平方和。
/// 用于加速 ZNCC 中窗口 ΣS / ΣS² 的计算（从 O(tw·th) 降为 O(1)）。
/// 一张搜索区域只需算一次积分图，所有英雄模板共享（60 英雄省 60 倍重复计算）。
/// 注：ΣST（互相关）仍需 O(tw·th)，但 ΣS/ΣS² 是原暴力实现的主要开销之一。
struct IntegralImage {
    /// sum[y*stride+x] = Σ_{i<y, j<x} pixel(j,i)，大小 (h+1)×(w+1)，边界行/列为 0
    sum: Vec<f64>,
    /// sq_sum 同结构，存像素平方的累加和
    sq_sum: Vec<f64>,
    stride: usize,
}

impl IntegralImage {
    fn from_gray(img: &GrayImage) -> Self {
        let (w, h) = (img.width() as usize, img.height() as usize);
        let stride = w + 1;
        let mut sum = vec![0f64; stride * (h + 1)];
        let mut sq_sum = vec![0f64; stride * (h + 1)];
        let pixels = img.as_raw();
        for y in 0..h {
            for x in 0..w {
                let p = pixels[y * w + x] as f64;
                let idx = (y + 1) * stride + (x + 1);
                let up = y * stride + (x + 1);
                let left = (y + 1) * stride + x;
                let up_left = y * stride + x;
                sum[idx] = p + sum[up] + sum[left] - sum[up_left];
                sq_sum[idx] = p * p + sq_sum[up] + sq_sum[left] - sq_sum[up_left];
            }
        }
        Self { sum, sq_sum, stride }
    }

    /// 矩形 [x, x+w) × [y, y+h) 的像素和（O(1)）
    #[inline]
    fn rect_sum(&self, x: usize, y: usize, w: usize, h: usize) -> f64 {
        let (x2, y2) = (x + w, y + h);
        let s = |xx: usize, yy: usize| yy * self.stride + xx;
        self.sum[s(x2, y2)] - self.sum[s(x, y2)] - self.sum[s(x2, y)] + self.sum[s(x, y)]
    }

    /// 矩形 [x, x+w) × [y, y+h) 的平方和（O(1)）
    #[inline]
    fn rect_sq_sum(&self, x: usize, y: usize, w: usize, h: usize) -> f64 {
        let (x2, y2) = (x + w, y + h);
        let s = |xx: usize, yy: usize| yy * self.stride + xx;
        self.sq_sum[s(x2, y2)] - self.sq_sum[s(x, y2)] - self.sq_sum[s(x2, y)] + self.sq_sum[s(x, y)]
    }
}

/// 对单个英雄模板做匹配：在 [h-R, h+R] 高度范围内步进，每个尺度缩放模板 → 裁剪 → ZNCC 扫位置。
/// 返回 (最高 ZNCC 分数, 对应的缩放高度 h)。
/// integral 是搜索区域的积分图（外部算好传入，所有英雄共享）。
fn match_template(
    search: &GrayImage,
    integral: &IntegralImage,
    tmpl_orig: &GrayImage,
    target_h: u32,
    radius: u32,
    mode: TemplateMode,
) -> (f32, u32) {
    let mut best_score = -1.0f32;
    let mut best_h = target_h;

    let h_lo = target_h.saturating_sub(radius).max(1);
    let h_hi = target_h + radius;

    for h in h_lo..=h_hi {
        let scale = h as f32 / ORIG_H as f32;
        let scaled_w = ((ORIG_W as f32) * scale).round() as u32;
        let scaled_h = h;

        // 缩放原图到目标高度
        let scaled = imageops::resize(tmpl_orig, scaled_w, scaled_h, imageops::FilterType::Lanczos3);

        // 裁剪模板
        let tmpl: GrayImage = match mode {
            TemplateMode::Crop80 => {
                // 文档方案：距右 50、距上 50 的 80×80 方块
                if scaled_w <= TMPL_MARGIN_RIGHT + TMPL_SIZE || scaled_h <= TMPL_MARGIN_TOP + TMPL_SIZE {
                    continue;
                }
                let tx = scaled_w - TMPL_MARGIN_RIGHT - TMPL_SIZE;
                let ty = TMPL_MARGIN_TOP;
                imageops::crop_imm(&scaled, tx, ty, TMPL_SIZE, TMPL_SIZE).to_image()
            }
            TemplateMode::Full => {
                // 整张缩放后的卡牌作模板
                scaled
            }
        };

        let score = find_max_zncc(search, integral, &tmpl);
        if score > best_score {
            best_score = score;
            best_h = h;
        }
    }

    (best_score, best_h)
}

/// 在 search 区域内扫描所有位置，找 max ZNCC（用积分图加速）。
/// ZNCC ∈ [-1, 1]，1 = 完全相似。
/// 积分图将窗口 ΣS/ΣS² 降为 O(1)，ΣST（互相关）仍 O(tw·th)。
fn find_max_zncc(search: &GrayImage, integral: &IntegralImage, tmpl: &GrayImage) -> f32 {
    let (sw, sh) = (search.width() as usize, search.height() as usize);
    let (tw, th) = (tmpl.width() as usize, tmpl.height() as usize);
    if tw > sw || th > sh {
        return -1.0;
    }

    let tmpl_pixels = tmpl.as_raw();
    let n = (tw * th) as f64;

    // 预计算模板统计量（ΣT, μ_T, ΣT² → Σ(T-μ_T)²）
    let tmpl_sum: f64 = tmpl_pixels.iter().map(|&v| v as f64).sum();
    let tmpl_mean = tmpl_sum / n;
    let tmpl_sq_sum: f64 = tmpl_pixels.iter().map(|&v| (v as f64) * (v as f64)).sum();
    let tmpl_var = tmpl_sq_sum - tmpl_sum * tmpl_sum / n; // Σ(T-μ_T)²
    if tmpl_var <= 0.0 {
        return -1.0; // 模板全黑或全白，无法区分
    }

    // 模板转 f64（避免内层循环反复 as f64 转换）
    let tmpl_f64: Vec<f64> = tmpl_pixels.iter().map(|&v| v as f64).collect();
    let search_pixels = search.as_raw();
    let mut max_score = -1.0f32;

    for y in 0..=(sh - th) {
        for x in 0..=(sw - tw) {
            // O(1): 窗口和与平方和（积分图），替代原来 O(tw·th) 的暴力求和
            let win_sum = integral.rect_sum(x, y, tw, th);
            let win_sq_sum = integral.rect_sq_sum(x, y, tw, th);
            let win_var = win_sq_sum - win_sum * win_sum / n; // Σ(S-μ_S)²
            if win_var <= 0.0 {
                continue; // 窗口无变化，跳过
            }

            // O(tw·th): 互相关 ΣST（无法用积分图优化，依赖模板位置）
            let mut st_sum: f64 = 0.0;
            for ty in 0..th {
                let s_base = (y + ty) * sw + x;
                let t_base = ty * tw;
                for tx in 0..tw {
                    st_sum += search_pixels[s_base + tx] as f64 * tmpl_f64[t_base + tx];
                }
            }

            // ZNCC = (ΣST - n·μ_S·μ_T) / sqrt(Σ(S-μ_S)² · Σ(T-μ_T)²)
            let win_mean = win_sum / n;
            let num = st_sum - n * win_mean * tmpl_mean;
            let denom = (win_var * tmpl_var).sqrt();
            if denom > 0.0 {
                let zncc = (num / denom) as f32;
                if zncc > max_score {
                    max_score = zncc;
                }
            }
        }
    }

    max_score
}

// ============ 图像工具 ============

/// 从截屏裁剪指定区域（带边界保护）
fn crop_screenshot(screen: &RgbaImage, region: (i32, i32, u32, u32)) -> RgbaImage {
    let (x, y, w, h) = region;
    let rx = x.max(0) as u32;
    let ry = y.max(0) as u32;
    let rw = w.min(screen.width().saturating_sub(rx));
    let rh = h.min(screen.height().saturating_sub(ry));
    if rw == 0 || rh == 0 {
        return RgbaImage::new(1, 1);
    }
    imageops::crop_imm(screen, rx, ry, rw, rh).to_image()
}

/// RgbaImage → GrayImage
fn to_gray(img: &RgbaImage) -> GrayImage {
    DynamicImage::ImageRgba8(img.clone()).into_luma8()
}

// ============ 命令行解析 ============

#[derive(Debug, Clone, Copy)]
enum TemplateMode {
    Crop80,
    Full,
}

impl std::fmt::Display for TemplateMode {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TemplateMode::Crop80 => write!(f, "crop80"),
            TemplateMode::Full => write!(f, "full"),
        }
    }
}

impl std::str::FromStr for TemplateMode {
    type Err = anyhow::Error;
    fn from_str(s: &str) -> Result<Self, Self::Err> {
        match s {
            "crop80" => Ok(TemplateMode::Crop80),
            "full" => Ok(TemplateMode::Full),
            _ => Err(anyhow!("未知 mode: {}（可选 crop80 | full）", s)),
        }
    }
}

struct Args {
    screenshot: PathBuf,
    season: String,
    regions: Vec<(i32, i32, u32, u32)>,
    top: usize,
    scale_radius: u32,
    mode: TemplateMode,
    cache_dir: PathBuf,
}

fn parse_args() -> Result<Args> {
    let mut screenshot: Option<PathBuf> = None;
    let mut season: Option<String> = None;
    let mut regions_str: Option<String> = None;
    let mut top: usize = 5;
    let mut scale_radius: u32 = 5;
    let mut mode: TemplateMode = TemplateMode::Crop80;
    let mut cache_dir: PathBuf = PathBuf::from("./card_cache");

    let args: Vec<String> = std::env::args().skip(1).collect();
    let mut i = 0;
    while i < args.len() {
        let key = args[i].as_str();
        let val = args.get(i + 1).ok_or_else(|| anyhow!("参数 {} 缺少值", key))?;
        match key {
            "--screenshot" => screenshot = Some(PathBuf::from(val)),
            "--season" => season = Some(val.clone()),
            "--regions" => regions_str = Some(val.clone()),
            "--top" => top = val.parse()?,
            "--scale-radius" => scale_radius = val.parse()?,
            "--mode" => mode = val.parse()?,
            "--cache-dir" => cache_dir = PathBuf::from(val),
            _ => return Err(anyhow!("未知参数: {}（可用 --screenshot/--season/--regions/--top/--scale-radius/--mode/--cache-dir）", key)),
        }
        i += 2;
    }

    let screenshot = screenshot.ok_or_else(|| anyhow!("缺少 --screenshot"))?;
    let season = season.ok_or_else(|| anyhow!("缺少 --season（如 s17 / s16m17）"))?;
    let regions_str = regions_str.ok_or_else(|| anyhow!("缺少 --regions（如 \"100,200,300,150;400,200,300,150\"）"))?;

    let regions: Vec<(i32, i32, u32, u32)> = regions_str
        .split(';')
        .map(|s| {
            let parts: Vec<&str> = s.trim().split(',').collect();
            if parts.len() != 4 {
                return Err(anyhow!("region 格式错误: {}（应为 x,y,w,h）", s));
            }
            Ok((parts[0].parse()?, parts[1].parse()?, parts[2].parse()?, parts[3].parse()?))
        })
        .collect::<Result<Vec<_>>>()?;

    if regions.is_empty() {
        return Err(anyhow!("regions 为空"));
    }

    Ok(Args {
        screenshot,
        season,
        regions,
        top,
        scale_radius,
        mode,
        cache_dir,
    })
}
