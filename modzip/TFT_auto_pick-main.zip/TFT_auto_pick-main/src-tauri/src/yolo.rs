//! YOLO 目标检测引擎：识别 TFT 棋盘上英雄的血条坐标，用于"一键卖出"。
//!
//! 模型（yolo.onnx）由用户后期自行训练导出放入 resources/models/。
//! 推理复用 OCR 同一个 onnxruntime.dll（ORT_DYLIB_PATH 已在 lib.rs 设置）。
//!
//! 设计参照 ocr.rs：Session::run 是 &mut self，故用 Mutex 包裹；模型缺失走 new_disabled 降级。
//! 不开启 ort 的 ndarray feature，用原始 (shape, &[f32]) API 提取输出，零额外依赖。

use anyhow::{anyhow, Context, Result};
use image::{imageops, DynamicImage, RgbImage};
use ort::session::{builder::GraphOptimizationLevel, Session};
use ort::value::Tensor;
use std::path::Path;
use std::sync::Mutex;

/// YOLO 输入尺寸（正方形，YOLOv8n 标准导出默认 640）
const INPUT_SIZE: usize = 640;
/// 检测类别数（仅1类：英雄血条）
const NUM_CLASSES: usize = 1;
/// 置信度阈值：低于此分数的检测框丢弃
const CONF_THRESHOLD: f32 = 0.25;
/// NMS 的 IoU 阈值：高于此值的同类别框被视为重复，保留分数最高者
const IOU_THRESHOLD: f32 = 0.45;
/// letterbox 填充值（YOLO 惯例 114 灰）
const PAD_FILL: u8 = 114;

/// 一个检测框（xywh 为相对输入裁切图的像素坐标）
#[derive(Clone, Debug)]
pub struct DetBox {
    pub x: f32,
    pub y: f32,
    pub w: f32,
    pub h: f32,
    pub score: f32,
    /// 类别索引。当前单类模型恒为 0，保留字段供后期多类模型使用
    #[allow(dead_code)]
    pub class: u32,
}

pub struct YoloEngine {
    /// None = 模型缺失/加载失败，detect 返回 Err（由调用方降级处理）
    session: Option<Mutex<Session>>,
}

impl YoloEngine {
    /// 从 model_dir 加载 yolo.onnx。模型不存在返回 Err（调用方走 new_disabled）。
    pub fn new(model_dir: &Path) -> Result<Self> {
        let model_path = model_dir.join("yolo.onnx");
        if !model_path.exists() {
            return Err(anyhow!("YOLO 模型不存在: {}", model_path.display()));
        }
        let session = Session::builder()?
            .with_optimization_level(GraphOptimizationLevel::Level1)?
            .with_intra_threads(2)?
            .commit_from_file(&model_path)
            .with_context(|| format!("加载 YOLO 模型失败: {}", model_path.display()))?;
        Ok(Self {
            session: Some(Mutex::new(session)),
        })
    }

    /// 降级构造：模型缺失时不崩溃，detect 返回 Err
    pub fn new_disabled() -> Self {
        Self { session: None }
    }

    /// 检测一张裁切图中的英雄血条，返回检测框列表（坐标已映射回原图像素）。
    pub fn detect(&self, img: &RgbImage) -> Result<Vec<DetBox>> {
        let session = self
            .session
            .as_ref()
            .ok_or_else(|| anyhow!("YOLO 引擎未初始化（模型加载失败或未放入 yolo.onnx）"))?;
        let mut session = session.lock().unwrap();

        // 预处理：letterbox 到 640×640 + RGB 归一化 + NCHW 布局
        let (input_data, scale, pad_x, pad_y) = preprocess(img);
        let input = Tensor::from_array((
            [1usize, 3, INPUT_SIZE, INPUT_SIZE],
            input_data.into_boxed_slice(),
        ))
        .context("构造 YOLO 输入张量失败")?;

        let outputs = session
            .run(ort::inputs![input])
            .context("YOLO 推理失败")?;

        // 取第0个输出张量（YOLOv8 标准导出只有1个检测输出）
        let output_value = &outputs[0];
        let (shape, data) = output_value
            .try_extract_tensor::<f32>()
            .context("提取 YOLO 输出张量失败")?;
        let dims: &[i64] = &**shape;

        let mut boxes = postprocess(data, dims, NUM_CLASSES);
        // 反向 letterbox 映射：640 坐标系 → 原图像素坐标
        for b in boxes.iter_mut() {
            b.x = (b.x - pad_x) / scale;
            b.y = (b.y - pad_y) / scale;
            b.w /= scale;
            b.h /= scale;
        }
        Ok(boxes)
    }
}

// ============ 预处理 ============

/// letterbox 预处理：保持比例缩放使长边=INPUT_SIZE，短边居中填充 PAD_FILL。
/// 返回 (NCHW f32 数据, 缩放比例, x 方向 padding, y 方向 padding)，用于后处理反向映射。
fn preprocess(img: &RgbImage) -> (Vec<f32>, f32, f32, f32) {
    let (ow, oh) = (img.width() as f32, img.height() as f32);
    let scale = (INPUT_SIZE as f32 / ow).min(INPUT_SIZE as f32 / oh);
    let new_w = (ow * scale).round() as u32;
    let new_h = (oh * scale).round() as u32;
    let pad_x = ((INPUT_SIZE as u32 - new_w) as f32) / 2.0;
    let pad_y = ((INPUT_SIZE as u32 - new_h) as f32) / 2.0;

    // 先 resize 到 new_w×new_h
    let resized = imageops::resize(img, new_w, new_h, imageops::FilterType::Triangle);

    // 放到 INPUT_SIZE×INPUT_SIZE 画布上，填充 PAD_FILL
    let mut canvas =
        RgbImage::from_pixel(INPUT_SIZE as u32, INPUT_SIZE as u32, image::Rgb([PAD_FILL; 3]));
    imageops::overlay(&mut canvas, &resized, pad_x as i64, pad_y as i64);

    // NCHW f32 归一化 [0,1]
    let mut data = vec![0f32; 3 * INPUT_SIZE * INPUT_SIZE];
    let channel_size = INPUT_SIZE * INPUT_SIZE;
    for y in 0..INPUT_SIZE {
        for x in 0..INPUT_SIZE {
            let px = canvas.get_pixel(x as u32, y as u32);
            let idx = y * INPUT_SIZE + x;
            data[idx] = px[0] as f32 / 255.0; // R
            data[channel_size + idx] = px[1] as f32 / 255.0; // G
            data[2 * channel_size + idx] = px[2] as f32 / 255.0; // B
        }
    }
    (data, scale, pad_x, pad_y)
}

// ============ 后处理（YOLOv8 decode + NMS） ============

/// YOLOv8 后处理：兼容 [1, 4+nc, anchors] 和 [1, anchors, 4+nc] 两种输出布局。
/// 坐标已是输入图像素坐标（xywh 中心点格式），无需 anchor decode，仅过滤 + NMS。
fn postprocess(data: &[f32], dims: &[i64], num_classes: usize) -> Vec<DetBox> {
    if dims.len() < 3 {
        return Vec::new();
    }
    let channels = 4 + num_classes;
    // 判断布局：dims[1]==channels → [1, 4+nc, anchors]（v8 标准）；否则 [1, anchors, 4+nc]
    let (num_anchors, is_transposed) = if dims[1] as usize == channels {
        (dims[2] as usize, true)
    } else {
        (dims[1] as usize, false)
    };

    let mut candidates: Vec<DetBox> = Vec::new();
    for a in 0..num_anchors {
        // 取该 anchor 所有类别分数的最大值作为该框分数
        let mut best_cls = 0u32;
        let mut best_score = 0f32;
        for c in 0..num_classes {
            let idx = if is_transposed {
                (4 + c) * num_anchors + a
            } else {
                a * channels + 4 + c
            };
            if data[idx] > best_score {
                best_score = data[idx];
                best_cls = c as u32;
            }
        }
        if best_score < CONF_THRESHOLD {
            continue;
        }

        let (cx, cy, w, h) = if is_transposed {
            (
                data[a],
                data[num_anchors + a],
                data[2 * num_anchors + a],
                data[3 * num_anchors + a],
            )
        } else {
            let base = a * channels;
            (data[base], data[base + 1], data[base + 2], data[base + 3])
        };

        // xywh(中心) → xywh(左上)
        candidates.push(DetBox {
            x: cx - w / 2.0,
            y: cy - h / 2.0,
            w,
            h,
            score: best_score,
            class: best_cls,
        });
    }

    nms(candidates, IOU_THRESHOLD)
}

/// 非极大值抑制：按分数降序，逐个保留并剔除 IoU 过高的同类别框
fn nms(boxes: Vec<DetBox>, iou_thresh: f32) -> Vec<DetBox> {
    let mut sorted = boxes;
    sorted.sort_by(|a, b| b.score.partial_cmp(&a.score).unwrap_or(std::cmp::Ordering::Equal));
    let mut result = Vec::new();
    while let Some(best) = sorted.pop() {
        result.push(best.clone());
        sorted.retain(|b| iou(&best, b) < iou_thresh);
    }
    result
}

/// 两个框的交并比
fn iou(a: &DetBox, b: &DetBox) -> f32 {
    let (ax2, ay2) = (a.x + a.w, a.y + a.h);
    let (bx2, by2) = (b.x + b.w, b.y + b.h);
    let inter_x1 = a.x.max(b.x);
    let inter_y1 = a.y.max(b.y);
    let inter_x2 = ax2.min(bx2);
    let inter_y2 = ay2.min(by2);
    let inter = ((inter_x2 - inter_x1).max(0.0)) * ((inter_y2 - inter_y1).max(0.0));
    let union = a.w * a.h + b.w * b.h - inter;
    if union <= 0.0 {
        0.0
    } else {
        inter / union
    }
}

/// DynamicImage 转RgbImage 的便捷入口（供调用方用）
#[allow(dead_code)]
pub fn to_rgb(img: &DynamicImage) -> RgbImage {
    img.to_rgb8()
}
