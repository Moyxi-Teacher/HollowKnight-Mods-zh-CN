//! 全局热键管理：用 Windows 低级键盘钩子（WH_KEYBOARD_LL）监听按键
//!
//! tauri-plugin-global-shortcut 使用 RegisterHotKey API，在游戏内不触发
//! （游戏窗口拦截了 WM_HOTKEY 消息分发）。
//! WH_KEYBOARD_LL 是全局低级钩子，在任何应用（包括全屏游戏）中都能捕获键盘输入。
//!
//! 支持两类热键：
//! - Action（手动）：按下 = 刷新商店 + 检测拿牌一次（emit detect-triggered）
//! - AutoToggle（自动）：按下 = 开启/关闭自动循环检测（emit auto-toggle）
//!
//! 钩子回调在专用线程的消息泵中执行，通过全局静态变量访问 AppHandle 和目标热键。

use std::sync::{OnceLock, RwLock};
use std::thread;
use std::time::Instant;

use tauri::{AppHandle, Emitter};

/// 手动热键触发事件（前端监听后执行一次截屏+OCR+匹配+点击）
pub const EVT_DETECT_TRIGGERED: &str = "detect-triggered";
/// 自动模式开关事件（前端监听后 toggle 自动循环检测）
pub const EVT_AUTO_TOGGLE: &str = "auto-toggle";
/// 一键卖出触发事件（前端监听后截图+YOLO识别+按E卖出）
pub const EVT_SELL_TRIGGERED: &str = "sell-triggered";

// ============ 全局静态状态（低级钩子回调无法捕获闭包变量） ============

/// AppHandle（init 时设置，用于在钩子回调中触发事件）
static APP_HANDLE: OnceLock<AppHandle> = OnceLock::new();

/// 热键种类
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum HotkeyKind {
    /// 手动：刷新+检测一次
    Action,
    /// 自动：toggle 循环检测
    AutoToggle,
    /// 一键卖出：截图+YOLO识别+按E卖出
    Sell,
}

impl HotkeyKind {
    pub fn from_str(s: &str) -> Result<Self, String> {
        match s {
            "action" => Ok(HotkeyKind::Action),
            "auto" => Ok(HotkeyKind::AutoToggle),
            "sell" => Ok(HotkeyKind::Sell),
            other => Err(format!("未知热键种类: {}", other)),
        }
    }
}

#[derive(Clone, Copy)]
struct HotkeyTarget {
    vk: u32,
    ctrl: bool,
    shift: bool,
    alt: bool,
    kind: HotkeyKind,
}

/// 各类热键的目标，None 表示未注册
static ACTION_TARGET: RwLock<Option<HotkeyTarget>> = RwLock::new(None);
static AUTO_TARGET: RwLock<Option<HotkeyTarget>> = RwLock::new(None);
static SELL_TARGET: RwLock<Option<HotkeyTarget>> = RwLock::new(None);

/// 各类热键各自的防抖时间（避免按住键时 WM_KEYDOWN 重复触发）
static LAST_ACTION_TRIGGER: RwLock<Option<Instant>> = RwLock::new(None);
static LAST_AUTO_TRIGGER: RwLock<Option<Instant>> = RwLock::new(None);
static LAST_SELL_TRIGGER: RwLock<Option<Instant>> = RwLock::new(None);

// ============ Windows API 绑定 ============

use windows_sys::Win32::Foundation::{LPARAM, LRESULT, WPARAM};
use windows_sys::Win32::UI::Input::KeyboardAndMouse::{GetAsyncKeyState, VK_CONTROL, VK_MENU, VK_SHIFT};
use windows_sys::Win32::UI::WindowsAndMessaging::{
    CallNextHookEx, DispatchMessageW, GetMessageW, SetWindowsHookExW, TranslateMessage,
    HHOOK, HOOKPROC, KBDLLHOOKSTRUCT, MSG, WH_KEYBOARD_LL,
};

/// WM_KEYDOWN / WM_SYSKEYDOWN 消息常量
const WM_KEYDOWN: u32 = 0x0100;
const WM_SYSKEYDOWN: u32 = 0x0104;
/// HC_ACTION：钩子回调 code 参数，表示有事件待处理
const HC_ACTION: i32 = 0;
/// 防抖间隔（毫秒）：避免按住键时重复触发
const DEBOUNCE_MS: u128 = 300;

/// 尝试匹配一个热键目标：若匹配且通过防抖，则 emit 对应事件
/// 返回 true 表示已匹配（用于日志）
fn try_match(
    target_opt: &Option<HotkeyTarget>,
    last_trigger: &RwLock<Option<Instant>>,
    kb_vk: u32,
    evt_name: &str,
) -> bool {
    if let Some(t) = target_opt.as_ref() {
        // 用 GetAsyncKeyState 检查修饰键实时状态（高位 0x8000 为 1 表示按下）
        // GetAsyncKeyState 是 unsafe 的 Windows API，需在 unsafe block 中调用
        let (ctrl, shift, alt) = unsafe {
            (
                (GetAsyncKeyState(VK_CONTROL as i32) as u16) & 0x8000 != 0,
                (GetAsyncKeyState(VK_SHIFT as i32) as u16) & 0x8000 != 0,
                (GetAsyncKeyState(VK_MENU as i32) as u16) & 0x8000 != 0,
            )
        };

        if kb_vk == t.vk && ctrl == t.ctrl && shift == t.shift && alt == t.alt {
            let now = Instant::now();
            let should_trigger = {
                let last = last_trigger.read().unwrap();
                last.map(|x| now.duration_since(x).as_millis() > DEBOUNCE_MS).unwrap_or(true)
            };
            if should_trigger {
                *last_trigger.write().unwrap() = Some(now);
                eprintln!(
                    "[hotkey] 触发 {:?}: vk=0x{:02X} ctrl={} shift={} alt={}",
                    t.kind, t.vk, t.ctrl, t.shift, t.alt
                );
                if let Some(app) = APP_HANDLE.get() {
                    let app2 = app.clone();
                    let evt = evt_name.to_string();
                    // 异步 emit 事件给前端，避免阻塞钩子线程
                    tauri::async_runtime::spawn(async move {
                        let _ = app2.emit(&evt, ());
                    });
                }
            }
            return true;
        }
    }
    false
}

/// 低级键盘钩子回调：在钩子线程的消息泵中被调用
unsafe extern "system" fn low_level_keyboard_proc(
    code: i32,
    wparam: WPARAM,
    lparam: LPARAM,
) -> LRESULT {
    if code == HC_ACTION {
        let msg = wparam as u32;
        // 只处理按键按下事件（WM_KEYDOWN / WM_SYSKEYDOWN）
        if msg == WM_KEYDOWN || msg == WM_SYSKEYDOWN {
            let kb = &*(lparam as *const KBDLLHOOKSTRUCT);
            let vk = kb.vkCode;
            // 先匹配 Action 热键，再匹配 Auto 热键（两者互斥，一个按键只触发一类）
            let action = ACTION_TARGET.read().unwrap();
            let matched_action = try_match(&action, &LAST_ACTION_TRIGGER, vk, EVT_DETECT_TRIGGERED);
            if !matched_action {
                let auto = AUTO_TARGET.read().unwrap();
                try_match(&auto, &LAST_AUTO_TRIGGER, vk, EVT_AUTO_TOGGLE);
            }
            // Sell 热键独立判断：Ctrl+Space 与 Action(纯 Space) 修饰键不同，不会重复触发
            let sell = SELL_TARGET.read().unwrap();
            try_match(&sell, &LAST_SELL_TRIGGER, vk, EVT_SELL_TRIGGERED);
            // 不吞掉按键（不 return 1），让游戏也能收到按键：
            // Action 热键让游戏刷新商店，同时程序触发检测，实现"刷新+检测"合一
        }
    }
    // 传递给下一个钩子
    CallNextHookEx(std::ptr::null_mut(), code, wparam, lparam)
}

// ============ HotkeyManager ============

pub struct HotkeyManager {
    /// 当前已注册的热键字符串（前端录制格式，如 "Ctrl+Shift+Space"）
    action: RwLock<Option<String>>,
    auto: RwLock<Option<String>>,
    sell: RwLock<Option<String>>,
}

impl HotkeyManager {
    pub fn new() -> Self {
        Self {
            action: RwLock::new(None),
            auto: RwLock::new(None),
            sell: RwLock::new(None),
        }
    }

    /// 初始化低级键盘钩子（在 setup 中调用一次）
    /// 启动专用线程运行消息泵，钩子回调在该线程中执行
    pub fn init(&self, app: &AppHandle) {
        let _ = APP_HANDLE.set(app.clone());
        eprintln!("[hotkey] 初始化低级键盘钩子...");

        thread::spawn(|| unsafe {
            // 设置 WH_KEYBOARD_LL 全局低级键盘钩子
            let hook = SetWindowsHookExW(
                WH_KEYBOARD_LL,
                Some(low_level_keyboard_proc),
                std::ptr::null_mut(),
                0,
            );
            if hook.is_null() {
                eprintln!("[hotkey] SetWindowsHookExW 失败: {}", std::io::Error::last_os_error());
                return;
            }
            eprintln!("[hotkey] 钩子注册成功, hook={:?}", hook);

            // 运行消息泵：钩子回调在 GetMessageW 调用中被触发
            let mut msg: MSG = std::mem::zeroed();
            loop {
                let ret = GetMessageW(&mut msg, std::ptr::null_mut(), 0, 0);
                if ret <= 0 {
                    break;
                }
                let _ = TranslateMessage(&msg);
                DispatchMessageW(&msg);
            }

            windows_sys::Win32::UI::WindowsAndMessaging::UnhookWindowsHookEx(hook);
            eprintln!("[hotkey] 钩子线程退出");
        });
    }

    /// 注册热键（按 kind 设置对应全局 target，钩子回调会自动匹配）
    pub fn register(&self, _app: &AppHandle, hotkey: &str, kind: HotkeyKind) -> Result<(), String> {
        eprintln!("[hotkey] 注册 {:?} 热键: {}", kind, hotkey);
        let mut target = parse_hotkey(hotkey)?;
        target.kind = kind;
        eprintln!(
            "[hotkey] 解析成功: vk=0x{:02X} ctrl={} shift={} alt={}",
            target.vk, target.ctrl, target.shift, target.alt
        );

        match kind {
            HotkeyKind::Action => {
                *ACTION_TARGET.write().unwrap() = Some(target);
                *LAST_ACTION_TRIGGER.write().unwrap() = None;
                *self.action.write().unwrap() = Some(hotkey.to_string());
            }
            HotkeyKind::AutoToggle => {
                *AUTO_TARGET.write().unwrap() = Some(target);
                *LAST_AUTO_TRIGGER.write().unwrap() = None;
                *self.auto.write().unwrap() = Some(hotkey.to_string());
            }
            HotkeyKind::Sell => {
                *SELL_TARGET.write().unwrap() = Some(target);
                *LAST_SELL_TRIGGER.write().unwrap() = None;
                *self.sell.write().unwrap() = Some(hotkey.to_string());
            }
        }
        eprintln!("[hotkey] {:?} 热键注册完成: {}", kind, hotkey);
        Ok(())
    }

    /// 注销指定种类的热键
    pub fn unregister(&self, _app: &AppHandle, kind: HotkeyKind) {
        match kind {
            HotkeyKind::Action => {
                *ACTION_TARGET.write().unwrap() = None;
                *self.action.write().unwrap() = None;
            }
            HotkeyKind::AutoToggle => {
                *AUTO_TARGET.write().unwrap() = None;
                *self.auto.write().unwrap() = None;
            }
            HotkeyKind::Sell => {
                *SELL_TARGET.write().unwrap() = None;
                *self.sell.write().unwrap() = None;
            }
        }
    }

    /// 当前已注册的指定种类热键
    pub fn current(&self, kind: HotkeyKind) -> Option<String> {
        match kind {
            HotkeyKind::Action => self.action.read().unwrap().clone(),
            HotkeyKind::AutoToggle => self.auto.read().unwrap().clone(),
            HotkeyKind::Sell => self.sell.read().unwrap().clone(),
        }
    }
}

// ============ 热键解析 ============

/// 把前端录制的热键字符串解析为 HotkeyTarget（kind 默认 Action，由调用方覆盖）
/// 前端格式: "Ctrl+Shift+Space" / "F5" / "Ctrl+D"
fn parse_hotkey(hotkey: &str) -> Result<HotkeyTarget, String> {
    let parts: Vec<&str> = hotkey.split('+').map(|s| s.trim()).collect();
    if parts.is_empty() {
        return Err("热键为空".into());
    }

    let mut ctrl = false;
    let mut shift = false;
    let mut alt = false;
    let mut vk: Option<u32> = None;

    for (i, p) in parts.iter().enumerate() {
        let is_last = i == parts.len() - 1;
        match p.to_lowercase().as_str() {
            "ctrl" | "control" => ctrl = true,
            "shift" => shift = true,
            "alt" => alt = true,
            "cmd" | "super" | "meta" | "win" => {
                return Err("暂不支持 Win 键作为修饰键".into());
            }
            _ if !is_last => return Err(format!("未知修饰键: {}", p)),
            key => {
                vk = Some(parse_vk(key).ok_or_else(|| format!("未知按键: {}", p))?);
            }
        }
    }

    let vk = vk.ok_or("缺少主按键")?;
    Ok(HotkeyTarget {
        vk,
        ctrl,
        shift,
        alt,
        kind: HotkeyKind::Action,
    })
}

/// 把按键名解析为 Windows 虚拟键码（VK_*）
fn parse_vk(key: &str) -> Option<u32> {
    match key.to_lowercase().as_str() {
        "space" => Some(0x20),       // VK_SPACE
        "enter" | "return" => Some(0x0D), // VK_RETURN
        "esc" | "escape" => Some(0x1B),   // VK_ESCAPE
        "tab" => Some(0x09),         // VK_TAB
        "backspace" | "back" => Some(0x08), // VK_BACK
        "delete" | "del" => Some(0x2E),    // VK_DELETE
        "insert" => Some(0x2D),      // VK_INSERT
        "home" => Some(0x24),        // VK_HOME
        "end" => Some(0x23),         // VK_END
        "pageup" => Some(0x21),      // VK_PRIOR
        "pagedown" => Some(0x22),    // VK_NEXT
        "up" => Some(0x26),          // VK_UP
        "down" => Some(0x28),        // VK_DOWN
        "left" => Some(0x25),        // VK_LEFT
        "right" => Some(0x27),       // VK_RIGHT
        // F1-F12
        "f1" => Some(0x70),
        "f2" => Some(0x71),
        "f3" => Some(0x72),
        "f4" => Some(0x73),
        "f5" => Some(0x74),
        "f6" => Some(0x75),
        "f7" => Some(0x76),
        "f8" => Some(0x77),
        "f9" => Some(0x78),
        "f10" => Some(0x79),
        "f11" => Some(0x7A),
        "f12" => Some(0x7B),
        // 单字符：字母 A-Z (0x41-0x5A) 或 数字 0-9 (0x30-0x39)
        s if s.len() == 1 => {
            let c = s.chars().next().unwrap();
            if c.is_ascii_alphabetic() {
                Some(c.to_ascii_uppercase() as u32)
            } else if c.is_ascii_digit() {
                Some(c as u32)
            } else {
                None
            }
        }
        _ => None,
    }
}
