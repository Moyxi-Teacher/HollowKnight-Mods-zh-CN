//! 找图模式：HSV 颜色直方图 + 巴氏系数匹配
//!
//! 用官网 624×318 卡牌原图作模板，对游戏截图做 HSV 颜色直方图匹配。
//!
//! # 为什么放弃 ZNCC 改用 HSV 直方图
//!
//! ZNCC 是像素级模板匹配，对游戏内修饰层（费用边框、星级、技能图标、升级光效等）
//! 非常敏感——这些修饰层会破坏 ZNCC 的统计特性，导致匹配错乱、胡乱购买。
//!
//! HSV 颜色直方图统计的是颜色分布，不关心像素位置：
//! - 天然抗修饰层：边框/星星/光效都是少量像素，对整体颜色分布影响小
//! - 英雄区分度大：每个英雄主色差异明显（克格莫紫绿、慎蓝白、凯尔金白）
//! - 速度极快：直方图 + 巴氏系数比 ZNCC 快 50-100 倍
//!
//! # 算法
//!
//! 1. 模板预处理：原图 624×318 → 取距右15、距上50的 80×80 方块 → RGB→HSV
//!    → 量化到 H(16)×S(8)×V(8)=1024 bin 直方图 → L1 归一化
//! 2. 匹配：截图区 → 缩放到 624×318（与模板同基准）→ 取同样 80×80 方块
//!    → HSV 直方图 → 与所有模板算巴氏系数 → top-1 ≥ 阈值视为匹配
//! 3. 巴氏系数 BC = Σ√(pᵢ·qᵢ) ∈ [0,1]，越大越相似（1=完全相同）
//!
//! 卡牌原图 URL: https://game.gtimg.cn/images/lol/tftstore/{season}/624x318/{chessId}.{png|jpg}

use anyhow::{anyhow, Context, Result};
use image::{imageops, Rgb, RgbImage};
use rayon::prelude::*;
use reqwest::Client;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::sync::RwLock;
use std::sync::atomic::{AtomicUsize, Ordering};
use tauri::{AppHandle, Emitter};

use crate::models::Chess;
use crate::provider::DataProvider;

/// 原图尺寸（官网卡牌统一规格）
const ORIG_W: u32 = 624;
const ORIG_H: u32 = 318;

/// 巴氏系数匹配阈值：> 此值视为匹配。
/// 用户调整为 0.8（与前端 IMG_THRESHOLD=0.8 同步）。
/// 之前 0.9 是为了在 Rust 端过滤空区域，但现在合并逻辑有 A 分支防线：
/// OCR 没认出英雄且商店变了就不信任找图——空背景场景被 A 分支拦住，
/// Rust 端不再需要严格过滤，0.8 即可。
/// 注意：空区域方差检测（is_likely_empty_region，std<30）仍保留，
///       它独立于巴氏系数阈值，是 Rust 端第一道空背景防线。
const MATCH_THRESHOLD: f32 = 0.8;

/// Crop80 模板参数：在 624×318 原图上取距右15、距上50的 80×80 方块。
/// 位置避开费用边框（左下角圆形）和技能图标（左上角），聚焦英雄头像右上区域。
const TMPL_MARGIN_RIGHT: u32 = 15;
const TMPL_MARGIN_TOP: u32 = 50;
const TMPL_SIZE: u32 = 80;

/// HSV 直方图量化级数：H(色相)8 × S(饱和度)4 × V(亮度)4 = 128 bin。
/// 80×80=6400 像素 / 128 bin = 50 像素/bin，直方图稠密不稀疏。
/// 1024 bin 时 6 像素/bin 过于稀疏，巴氏系数偏低（0.58-0.85）；
/// 128 bin 让同英雄分数提升到 0.85+，区分度仍足够（H 8 bin = 45°/bin）。
const H_BINS: usize = 8;
const S_BINS: usize = 4;
const V_BINS: usize = 4;
const TOTAL_BINS: usize = H_BINS * S_BINS * V_BINS; // 128

/// 模板项：英雄数据 + 归一化 HSV 直方图（128 bin）
type Template = (Chess, Vec<f32>);

/// 进度事件 payload（推送给前端显示「模板加载 X/Y」）
#[derive(Clone, serde::Serialize)]
struct ProgressPayload {
    done: usize,
    total: usize,
}

pub struct CardMatchEngine {
    /// None=未就绪（首次加载或切赛季中），Some=模板已加载可匹配
    templates: RwLock<Option<Arc<Vec<Template>>>>,
    /// 模板缓存目录：<cache_dir>/card_images/<season>/
    cache_dir: PathBuf,
    /// 当前赛季代号（与 GameMode.season 一致）
    season: RwLock<String>,
    /// 共享 DataProvider 的 client（避免重复构造）
    client: Client,
    /// 预加载进度（done/total），供 is_ready 检查
    progress: Arc<(AtomicUsize, AtomicUsize)>,
    /// 每个区域的 Y 轴裁剪偏移（Settings 测试时步进搜索记录，正式匹配直接用）。
    /// 补偿框选时的高度对齐误差：基准 Y 位置按比例计算，偏移在基准上微调。
    /// 空数组=未设置，用基准位置（偏移0）。
    offsets: RwLock<Vec<i32>>,
}

impl CardMatchEngine {
    /// 构造引擎但不加载模板。setup 中 tokio::spawn 调 preload 后台预热。
    pub fn new(cache_dir: PathBuf, season: String) -> Self {
        let client = Client::builder()
            .user_agent("Mozilla/5.0 TFT-AutoPick")
            .build()
            .unwrap_or_else(|_| Client::new());
        Self {
            templates: RwLock::new(None),
            cache_dir,
            season: RwLock::new(season),
            client,
            progress: Arc::new((AtomicUsize::new(0), AtomicUsize::new(0))),
            offsets: RwLock::new(Vec::new()),
        }
    }

    /// 是否就绪（preload 完成）。当前未暴露为 Tauri 命令，预留给前端就绪检测。
    #[allow(dead_code)]
    pub fn is_ready(&self) -> bool {
        self.templates.read().unwrap().is_some()
    }

    /// 当前进度 (done, total)
    pub fn progress(&self) -> (usize, usize) {
        (
            self.progress.0.load(Ordering::Relaxed),
            self.progress.1.load(Ordering::Relaxed),
        )
    }

    /// 切换赛季：清空模板 + 更新 season（由调用方 spawn 后台 preload）。
    /// 同步函数——只短暂持锁改字符串 / 清 Option，不阻塞。
    pub fn set_season(&self, season: &str) {
        {
            let mut g = self.season.write().unwrap();
            if &*g == season {
                return; // 赛季未变，不重载
            }
            *g = season.to_string();
        }
        // 清空旧模板（新赛季 chessId 体系不同，必须重新加载）
        *self.templates.write().unwrap() = None;
        self.progress.0.store(0, Ordering::Relaxed);
        self.progress.1.store(0, Ordering::Relaxed);
    }

    /// 设置 Y 轴裁剪偏移（Settings 测试时步进搜索记录，正式匹配直接用）。
    /// offsets 长度应与卡牌区域数一致（5），空数组=用基准位置。
    pub fn set_offsets(&self, offsets: Vec<i32>) {
        *self.offsets.write().unwrap() = offsets;
    }

    /// 后台预热：从 DataProvider 拿英雄列表 → 下载卡牌原图 → 解码为 HSV 直方图。
    /// 进度通过 tauri event "card-templates-progress" 推送前端。
    /// 串行下载（每张图几十 ms，101 张总耗时 5-10 秒可接受，避免并发 Send 问题）。
    pub async fn preload(&self, app: AppHandle, provider: Arc<DataProvider>) -> Result<()> {
        let season = self.season.read().unwrap().clone();
        let champions = provider.get_champions();
        if champions.is_empty() {
            return Err(anyhow!("英雄列表为空，无法加载卡牌模板"));
        }
        let total = champions.len();
        self.progress.0.store(0, Ordering::Relaxed);
        self.progress.1.store(total, Ordering::Relaxed);

        // 模板缓存目录：<cache_dir>/card_images/<season>/
        let img_dir = self.cache_dir.join("card_images").join(&season);
        std::fs::create_dir_all(&img_dir)?;

        // 串行下载：每张图先看缓存，缺失才联网。下载后立即转 HSV 直方图。
        let client = self.client.clone();
        let progress = self.progress.clone();
        let mut templates: Vec<Template> = Vec::with_capacity(total);

        for hero in champions.iter() {
            let r = async {
                let img = download_card_image(&client, &season, &hero.chess_id, &img_dir).await?;
                let rgb = image::open(&img)
                    .with_context(|| format!("打开卡牌图失败: {}", img.display()))?
                    .to_rgb8();
                // 原图 624×318 → 取距右15、距上50的 80×80 方块 → HSV 直方图
                // 模板用固定尺寸裁剪（原图已是 624×318）
                let tmpl = crop_template_fixed(&rgb)?;
                let hist = compute_hsv_histogram(&tmpl);
                Ok::<Vec<f32>, anyhow::Error>(hist)
            }
            .await;

            match r {
                Ok(hist) => templates.push((hero.clone(), hist)),
                Err(e) => eprintln!("[image_match] 跳过 {}: {}", hero.chess_id, e),
            }

            let d = progress.0.fetch_add(1, Ordering::Relaxed) + 1;
            // 每 10 张或最后一张推送进度
            if d % 10 == 0 || d == total {
                let _ = app.emit(
                    "card-templates-progress",
                    ProgressPayload { done: d, total },
                );
            }
        }

        if templates.is_empty() {
            return Err(anyhow!("所有模板加载失败"));
        }

        eprintln!("[image_match] 模板加载完成: {}/{} 张", templates.len(), total);
        *self.templates.write().unwrap() = Some(Arc::new(templates));
        let _ = app.emit(
            "card-templates-progress",
            ProgressPayload { done: total, total },
        );
        Ok(())
    }

    /// 正式匹配（capture_card_regions 用）：返回每张卡的 (chessId, score)。
    /// 应用 MATCH_THRESHOLD 阈值过滤：分数 < 阈值返回 None。
    /// 关键修复：卡牌被买后的空区域/背景颜色分布可能碰巧与某英雄相似（分数 0.85+），
    /// 必须在 Rust 端严格过滤，避免空区域被识别成英雄导致误点击。
    pub fn match_with_threshold(
        &self,
        crops: &[RgbImage],
        _target_hs: &[u32],
    ) -> Result<Vec<(Option<String>, f32)>> {
        self.match_internal(crops, true)
    }

    /// 测试匹配（Settings 测试按钮用）：返回每张卡的 (chessId, score)，不应用阈值。
    /// 让用户看到所有卡的实际识别结果（包括低分的），便于调试框选是否正确。
    pub fn test_match(
        &self,
        crops: &[RgbImage],
        _target_hs: &[u32],
    ) -> Result<Vec<(Option<String>, f32)>> {
        self.match_internal(crops, false)
    }

    /// 测试匹配 + 步进搜索最佳 Y 轴偏移（Settings 测试按钮用）：
    /// 对每个截图区，在基准裁剪 Y 位置附近搜索 dy∈[-5,5]，
    /// 找到分数最高的偏移 dy，返回 (chessId, score, dy)。
    /// 前端保存 offsets 后，正式匹配直接用（set_offsets），不需每次搜索。
    /// 5区域并行（par_iter），每区域11次偏移×101模板串行，总耗时约10-50ms。
    pub fn test_match_with_offsets(
        &self,
        crops: &[RgbImage],
    ) -> Result<Vec<(Option<String>, f32, i32)>> {
        let templates = self
            .templates
            .read()
            .unwrap()
            .clone()
            .ok_or_else(|| anyhow!("模板未就绪: {}/{} 已加载", self.progress().0, self.progress().1))?;

        if crops.is_empty() {
            return Ok(Vec::new());
        }

        let results: Vec<(Option<String>, f32, i32)> = crops
            .par_iter()
            .map(|crop| {
                if is_likely_empty_region(crop) {
                    return (None, 0.0, 0);
                }
                // 步进搜索：dy∈[-5,5]，步长1，共11次
                let mut best: (Option<String>, f32, i32) = (None, -1.0, 0);
                for dy in -5..=5 {
                    let tmpl = match crop_template_with_offset(crop, dy) {
                        Ok(t) => t,
                        Err(_) => continue,
                    };
                    let hist = compute_hsv_histogram(&tmpl);
                    // 串行遍历模板找 top-1
                    let mut top_id = String::new();
                    let mut top_score = -1.0f32;
                    for (hero, tmpl_hist) in templates.iter() {
                        let score = bhattacharyya_coefficient(&hist, tmpl_hist);
                        if score > top_score {
                            top_score = score;
                            top_id = hero.chess_id.clone();
                        }
                    }
                    if top_score > best.1 {
                        best = (Some(top_id), top_score, dy);
                    }
                }
                best
            })
            .collect();

        Ok(results)
    }

    /// 内部匹配实现：apply_threshold=true 时应用阈值过滤，false 时返回原始 top-1。
    /// 用 self.offsets 里的偏移裁剪（Settings 测试时记录，补偿框选误差）。
    fn match_internal(
        &self,
        crops: &[RgbImage],
        apply_threshold: bool,
    ) -> Result<Vec<(Option<String>, f32)>> {
        let templates = self
            .templates
            .read()
            .unwrap()
            .clone()
            .ok_or_else(|| anyhow!("模板未就绪: {}/{} 已加载", self.progress().0, self.progress().1))?;

        if crops.is_empty() {
            return Ok(Vec::new());
        }

        let offsets = self.offsets.read().unwrap().clone();

        let results: Vec<(Option<String>, f32)> = crops
            .par_iter()
            .enumerate()
            .map(|(i, crop)| {
                // 空区域检测：卡牌被买后的空背景颜色单一，HSV 直方图会碰巧与某英雄
                // 相似（分数 0.9+），导致空区域被误识别成英雄。用亮度方差判断：
                // 真实卡牌方差高（头像+文字+边框），空背景方差低。方差 < 30 直接返回 None。
                if is_likely_empty_region(crop) {
                    return (None, 0.0);
                }
                // 用 offsets 里的 Y 轴偏移裁剪（补偿框选高度误差，未设置则0）
                let dy = offsets.get(i).copied().unwrap_or(0);
                let tmpl = match crop_template_with_offset(crop, dy) {
                    Ok(t) => t,
                    Err(_) => return (None, 0.0),
                };
                let hist = compute_hsv_histogram(&tmpl);

                let best: (String, f32) = templates
                    .par_iter()
                    .map(|(hero, tmpl_hist)| {
                        let score = bhattacharyya_coefficient(&hist, tmpl_hist);
                        (hero.chess_id.clone(), score)
                    })
                    .reduce(|| (String::new(), -1.0f32), |a, b| if b.1 > a.1 { b } else { a });

                if !apply_threshold || best.1 >= MATCH_THRESHOLD {
                    (Some(best.0), best.1)
                } else {
                    (None, best.1)
                }
            })
            .collect();

        Ok(results)
    }
}

// ============ 模板裁剪 ============

/// 空区域检测：判断截图区是否为「卡牌被买后的空背景」。
/// 关键问题：HSV 颜色直方图无法区分「纯色卡牌」和「纯色空背景」——
/// 两者颜色分布都集中在少数 bin，巴氏系数可达 0.9+，导致空区域被误识别成某英雄。
/// 解决方案：用像素方差判断——真实卡牌有头像+文字+边框+光效，方差高；
/// 空背景颜色单一，方差低。方差 < 阈值直接返回 None，跳过匹配。
fn is_likely_empty_region(img: &RgbImage) -> bool {
    if img.width() == 0 || img.height() == 0 {
        return true;
    }
    // 计算亮度方差（Y 分量）
    let n = (img.width() * img.height()) as f64;
    let mut sum: f64 = 0.0;
    let mut sum_sq: f64 = 0.0;
    for p in img.pixels() {
        // BT.601 亮度公式
        let lum = 0.299 * p[0] as f64 + 0.587 * p[1] as f64 + 0.114 * p[2] as f64;
        sum += lum;
        sum_sq += lum * lum;
    }
    let mean = sum / n;
    let variance = (sum_sq / n) - mean * mean;
    let std = variance.max(0.0).sqrt();
    // 真实卡牌区域：std 通常 40-80+（头像+文字+边框+光效，颜色丰富）
    // 空背景：std 通常 < 25（颜色单一，可能有微弱光效）
    // 阈值 30：宁可漏检也不误检（漏检的空区域会走 OCR 兜底，OCR 对空区域也识别不到）
    // 之前 20 太低，部分空背景（带渐变/光效）方差 > 20 没被过滤
    std < 30.0
}

/// 从 624×318 原图裁剪距右15、距上50的 80×80 固定方块（模板预处理用）。
/// 原图已是 624×318，直接按固定坐标裁剪。
fn crop_template_fixed(img: &RgbImage) -> Result<RgbImage> {
    let x = ORIG_W
        .saturating_sub(TMPL_MARGIN_RIGHT + TMPL_SIZE)
        .min(ORIG_W.saturating_sub(TMPL_SIZE));
    let y = TMPL_MARGIN_TOP.min(ORIG_H.saturating_sub(TMPL_SIZE));
    if x + TMPL_SIZE > ORIG_W || y + TMPL_SIZE > ORIG_H {
        return Err(anyhow!("模板方块超出原图范围"));
    }
    Ok(imageops::crop_imm(img, x, y, TMPL_SIZE, TMPL_SIZE).to_image())
}

/// 从截图区裁剪等价方块（匹配用）。
/// 不缩放截图区到 624×318（避免比例变形），而是按截图区实际尺寸等比计算方块位置和大小。
/// 模板在原图的位置：距右15、距上50，尺寸 80×80。
/// 截图区等比缩放后裁剪同样位置（比例一致），确保内容对齐。
/// dy：Y 轴像素偏移（Settings 测试时步进搜索记录，补偿框选高度对齐误差）。
fn crop_template_with_offset(crop: &RgbImage, dy: i32) -> Result<RgbImage> {
    let cw = crop.width();
    let ch = crop.height();
    if cw < 10 || ch < 10 {
        return Err(anyhow!("截图区过小"));
    }
    // 按截图区与原图的比例计算方块位置和尺寸
    let scale_x = cw as f32 / ORIG_W as f32;
    let scale_y = ch as f32 / ORIG_H as f32;
    let tmpl_w = ((TMPL_SIZE as f32) * scale_x).round().max(1.0) as u32;
    let tmpl_h = ((TMPL_SIZE as f32) * scale_y).round().max(1.0) as u32;
    let margin_right = ((TMPL_MARGIN_RIGHT as f32) * scale_x).round() as u32;
    let margin_top = ((TMPL_MARGIN_TOP as f32) * scale_y).round() as i32;
    // X 轴基准位置（距右 margin_right），Y 轴基准位置 + 偏移（补偿框选高度误差）
    let x = cw.saturating_sub(margin_right + tmpl_w);
    let y = margin_top + dy;
    if y < 0 || (y as u32) + tmpl_h > ch {
        return Err(anyhow!("截图区方块越界"));
    }
    Ok(imageops::crop_imm(crop, x, y as u32, tmpl_w, tmpl_h).to_image())
}

// ============ HSV 直方图 ============

/// 计算 RgbImage 的 HSV 直方图（128 bin，L1 归一化）。
/// 直方图统计颜色分布，对像素位置不敏感——这是抗修饰层的关键。
fn compute_hsv_histogram(img: &RgbImage) -> Vec<f32> {
    let mut hist = vec![0f32; TOTAL_BINS];
    for pixel in img.pixels() {
        let Rgb([r, g, b]) = *pixel;
        let (h, s, v) = rgb_to_hsv(r, g, b);
        let bin = hsv_to_bin(h, s, v);
        hist[bin] += 1.0;
    }
    // L1 归一化：让不同尺寸图的直方图可比（虽然模板和截图区都缩放到 624×318 同尺寸，
    // 但归一化后巴氏系数有明确的概率含义：Σ√(pᵢ·qᵢ) ∈ [0,1]）
    let total: f32 = hist.iter().sum();
    if total > 0.0 {
        for v in hist.iter_mut() {
            *v /= total;
        }
    }
    hist
}

/// RGB → HSV（色相 0-360°，饱和度 0-1，亮度 0-1）
fn rgb_to_hsv(r: u8, g: u8, b: u8) -> (f32, f32, f32) {
    let r = r as f32 / 255.0;
    let g = g as f32 / 255.0;
    let b = b as f32 / 255.0;
    let max = r.max(g).max(b);
    let min = r.min(g).min(b);
    let delta = max - min;

    let h = if delta == 0.0 {
        0.0
    } else if max == r {
        60.0 * (((g - b) / delta) % 6.0)
    } else if max == g {
        60.0 * ((b - r) / delta + 2.0)
    } else {
        60.0 * ((r - g) / delta + 4.0)
    };
    let h = if h < 0.0 { h + 360.0 } else { h };

    let s = if max == 0.0 { 0.0 } else { delta / max };
    let v = max;

    (h, s, v)
}

/// HSV → 直方图 bin index（H 8 bin × S 4 bin × V 4 bin = 128）
#[inline]
fn hsv_to_bin(h: f32, s: f32, v: f32) -> usize {
    let h_bin = ((h / 360.0) * H_BINS as f32).floor() as usize % H_BINS;
    let s_bin = ((s * S_BINS as f32).floor() as usize).min(S_BINS - 1);
    let v_bin = ((v * V_BINS as f32).floor() as usize).min(V_BINS - 1);
    h_bin * (S_BINS * V_BINS) + s_bin * V_BINS + v_bin
}

/// 巴氏系数 BC = Σ√(pᵢ·qᵢ) ∈ [0,1]。
/// 1=完全相同，0=完全不同。越大越相似。
/// 比巴氏距离 DB=√(1-BC) 更直观（无需 1- 转换），且与 ZNCC 同方向（越大越好）。
fn bhattacharyya_coefficient(h1: &[f32], h2: &[f32]) -> f32 {
    h1.iter()
        .zip(h2.iter())
        .map(|(a, b)| (*a * *b).sqrt())
        .sum()
}

// ============ 卡牌原图下载（带缓存） ============

/// 下载某英雄的 624×318 卡牌原图。先试 .png 再试 .jpg。
/// 成功后缓存到 <cache_dir>/card_images/<season>/<chessId>.<ext>。
async fn download_card_image(
    client: &Client,
    season: &str,
    chess_id: &str,
    cache_dir: &Path,
) -> Result<PathBuf> {
    std::fs::create_dir_all(cache_dir)?;

    // 先看缓存
    if let Some(cached) = find_cached_card(cache_dir, chess_id) {
        return Ok(cached);
    }

    // 在线下载：先试 png，失败试 jpg
    const CARD_IMG_BASE: &str = "https://game.gtimg.cn/images/lol/tftstore/";
    for ext in &["png", "jpg"] {
        let url = format!("{}{}/624x318/{}.{}", CARD_IMG_BASE, season, chess_id, ext);
        match client.get(&url).send().await {
            Ok(resp) if resp.status().is_success() => {
                let bytes = resp.bytes().await?;
                let path = cache_dir.join(format!("{}.{}", chess_id, ext));
                std::fs::write(&path, &bytes)?;
                return Ok(path);
            }
            _ => continue,
        }
    }
    Err(anyhow!("png/jpg 均下载失败: chessId={}", chess_id))
}

/// 查找已缓存的卡牌原图（png 或 jpg）
fn find_cached_card(cache_dir: &Path, chess_id: &str) -> Option<PathBuf> {
    for ext in &["png", "jpg"] {
        let p = cache_dir.join(format!("{}.{}", chess_id, ext));
        if p.exists() {
            return Some(p);
        }
    }
    None
}
