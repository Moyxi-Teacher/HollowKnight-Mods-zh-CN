//! 与官方接口对应的 serde 数据模型
use serde::{Deserialize, Serialize};

/// versionconfig.json 元素：当前赛季各数据 URL
#[derive(Deserialize, Debug, Clone)]
pub struct VersionConfig {
    #[serde(rename = "arrVersionLimit")]
    pub arr_version_limit: Vec<String>,
    #[serde(rename = "stringName")]
    pub string_name: String,
    #[serde(rename = "idSeason")]
    pub id_season: String,
    #[serde(rename = "urlChessData")]
    pub url_chess_data: String,
    #[serde(rename = "urlRaceData")]
    pub url_race_data: String,
    #[serde(rename = "urlJobData")]
    pub url_job_data: String,
    #[serde(rename = "urlEquipData")]
    pub url_equip_data: String,
    #[serde(rename = "urlBuffData")]
    pub url_buff_data: String,
}

/// versionlist 响应
#[derive(Deserialize, Debug, Clone)]
pub struct VersionListWrap {
    pub code: i32,
    pub data: Vec<VersionEntry>,
}

#[derive(Deserialize, Debug, Clone)]
pub struct VersionEntry {
    pub name: String,
    pub vkey: String,
}

/// chess.js 响应外层
#[derive(Deserialize, Debug, Clone)]
pub struct ChessWrap {
    pub version: String,
    pub season: String,
    #[serde(rename = "modeId")]
    pub mode_id: String,
    pub data: Vec<Chess>,
}

/// 单个英雄/棋子
#[derive(Deserialize, Serialize, Debug, Clone)]
pub struct Chess {
    #[serde(rename = "chessId")]
    pub chess_id: String,
    #[serde(rename = "displayName")]
    pub display_name: String,
    pub price: String,
    #[serde(rename = "raceIds")]
    pub race_ids: String,
    #[serde(rename = "jobIds")]
    pub job_ids: String,
    #[serde(rename = "originalImage", default)]
    pub original_image: String,
    #[serde(rename = "hero_EN_name", default)]
    pub hero_en_name: String,
}

impl Chess {
    /// 过滤掉道具/锻造器（raceIds 与 jobIds 均空，非真正英雄）
    pub fn is_real_hero(&self) -> bool {
        !self.race_ids.trim().is_empty() || !self.job_ids.trim().is_empty()
    }

    pub fn price_u8(&self) -> u8 {
        self.price.parse().unwrap_or(0)
    }
}

/// lineup_detail_total.json 外层
#[derive(Deserialize, Debug, Clone)]
pub struct LineupWrap {
    #[serde(rename = "lineup_list")]
    pub lineup_list: Vec<Lineup>,
}

#[derive(Deserialize, Serialize, Debug, Clone)]
pub struct Lineup {
    pub id: String,
    pub quality: String,
    /// 二次嵌套的 JSON 字符串，需再 parse 为 LineupDetail
    pub detail: String,
}

/// lineup.detail 解析后的结构
#[derive(Deserialize, Debug, Clone)]
pub struct LineupDetail {
    #[serde(rename = "line_name", default)]
    pub line_name: String,
    #[serde(rename = "search_card_rhythm", default)]
    pub search_card_rhythm: Vec<Vec<RhythmCard>>,
}

#[derive(Deserialize, Serialize, Debug, Clone)]
pub struct RhythmCard {
    #[serde(rename = "isNew")]
    pub is_new: bool,
    pub id: String,
}

// ============ 前端交互类型 ============

#[derive(Serialize, Debug, Clone)]
pub struct VersionInfo {
    pub version: String,
    pub season: String,
    pub season_name: String,
    pub vkey: String,
    pub chess_count: usize,
}

/// 一个游戏模式（来自主网站 tft-mode-registry.js 的活跃模式注册表）
#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct GameMode {
    /// 模式显示名，如 "星神"、"恭喜发财 英雄联盟传奇"
    pub name: String,
    /// 模式代号，等于 versionconfig.json 的 idSeason，如 "s17"、"s16m17"
    pub season: String,
    /// 是否娱乐模式（恭喜发财等限时模式为 true，正赛为 false）
    pub is_rgm: bool,
    /// 队列 ID（如 1100=星神正赛、1210=恭喜发财），来自 registry
    pub queue_id: String,
    /// 阵容数据 URL（来自 registry 的 lineupListUrl，已去时间戳参数）
    pub lineup_url: String,
}

/// 当前活跃模式注册表（从 tft-mode-registry.js 解析）
#[derive(Serialize, Debug, Clone)]
pub struct CurrentModeInfo {
    /// 当前正赛代号（window.CurrentSet），如 "s17"
    pub current_set: String,
    /// 全部活跃模式（已排除被注释的过期模式）
    pub modes: Vec<GameMode>,
}

#[derive(Serialize, Debug, Clone)]
pub struct LineupBrief {
    pub id: String,
    pub line_name: String,
    pub quality: String,
    /// 每阶段该拿的 chessId 列表
    pub pick_stages: Vec<Vec<String>>,
}

#[derive(Serialize, Debug, Clone)]
pub struct PickCard {
    pub chess_id: String,
    pub name: String,
    pub price: u8,
    pub is_new: bool,
    pub image: String,
}

/// 本地缓存元信息
#[derive(Deserialize, Serialize, Debug, Clone)]
pub struct CacheMeta {
    pub vkey: String,
    pub version: String,
    pub season: String,
    pub season_name: String,
}

/// 商店区域（屏幕物理像素坐标，由 RegionPicker 转换后传入）
#[derive(Deserialize, Serialize, Debug, Clone, Copy)]
pub struct ShopRegion {
    pub x: i32,
    pub y: i32,
    pub width: u32,
    pub height: u32,
}

/// 5个卡牌名字区域（用户依次框选5次）
#[derive(Deserialize, Serialize, Debug, Clone, Default)]
pub struct NameRegions {
    pub regions: Vec<ShopRegion>,
}
