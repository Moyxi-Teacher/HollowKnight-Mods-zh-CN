//! PaddleOCR 识别引擎：用 ort 直接推理（绕过 paddle-ocr-rs，支持字符级 mask 约束解码）
//!
//! 核心改进：字符级约束解码（constrained decoding）。
//! 在 CTC argmax 前对 logits 做 mask，把不在英雄名字用字集合里的字符 logit 视为 -inf。
//! 模型只能从英雄字 + blank 里选，从根源杜绝识别出无关字，避免误匹配。
//! 这是比编辑距离/别名映射更彻底的方案——OCR 根本不会输出英雄名以外的字。
//!
//! 其余逻辑（预处理/字典/CTC 解码）与 paddle-ocr-rs 0.6.1 完全一致：
//! - resize 到 height=48，width 按比例缩放
//! - subtract mean [127.5,127.5,127.5], normalize [1/127.5,1/127.5,1/127.5]
//! - 字典从模型 metadata character 字段读取：keys = ["#"(blank)] + chars + [" "]
//! - CTC 解码：argmax 每个时间步，跳过 blank(index 0) 和连续重复
//!
//! 双变体预处理择优（保留）：Otsu二值化反转 + 自适应阈值反转，按 text_score 择优。
//! Session 非 Sync，用 Mutex 包裹（与原 paddle-ocr-rs 用法一致）。

use anyhow::{anyhow, Context, Result};
use image::imageops::{self, FilterType};
use image::{DynamicImage, GrayImage, RgbImage};
use imageproc::contrast::{adaptive_threshold, otsu_level, stretch_contrast, threshold, ThresholdType};
use ndarray::{Array, Array4};
use ort::session::{builder::GraphOptimizationLevel, Session};
use ort::value::Tensor;
use ort::inputs;
use std::collections::HashSet;
use std::path::Path;
use std::sync::Mutex;

const CRNN_DST_HEIGHT: u32 = 48;
const MEAN_VALUES: [f32; 3] = [127.5, 127.5, 127.5];
const NORM_VALUES: [f32; 3] = [1.0 / 127.5, 1.0 / 127.5, 1.0 / 127.5];

struct OcrInner {
    session: Session,
    keys: Vec<String>,
    input_name: String,
    /// 字符级 mask：长度 = keys.len()，true=允许该字符，false=屏蔽。
    /// None = 不约束（开放词汇表）。设置后 argmax 只在允许的字符里选。
    /// 完整英雄名匹配由前端 runDetect 的「完全匹配 + 双向包含」逻辑负责，
    /// Rust 端只保证 OCR 输出只含英雄名字用字（不输出「假」「的」等无关字）。
    allowed_mask: Option<Vec<bool>>,
}

pub struct OcrEngine {
    /// None = 初始化失败（模型文件缺失等），OCR 不可用但应用仍可运行
    inner: Option<Mutex<OcrInner>>,
}

/// 单行文本识别结果
struct TextLine {
    text: String,
    text_score: f32,
}

impl OcrEngine {
    /// 从 model_dir 加载 rec 模型。
    /// 字典从模型 metadata 的 character 字段读取（与 paddle-ocr-rs 一致），
    /// 与 PP-OCRv5 模型 18385 输出类严格对应，无需外部 txt。
    pub fn new(model_dir: &Path) -> Result<Self> {
        let rec_path = model_dir.join("ch_PP-OCRv5_rec_mobile_infer.onnx");
        if !rec_path.exists() {
            return Err(anyhow!("rec 模型不存在: {}", rec_path.display()));
        }

        let threads = std::thread::available_parallelism()
            .map(|n| n.get())
            .unwrap_or(2)
            .clamp(2, 4);

        let session = Session::builder()?
            .with_optimization_level(GraphOptimizationLevel::Level2)?
            .with_intra_threads(threads)?
            .with_inter_threads(threads)?
            .commit_from_file(rec_path.to_str().context("rec 路径转字符串失败")?)?;

        let input_name = session.inputs[0].name.clone();

        // 字典从模型 metadata character 字段读取
        // PP-OCRv5_rec_mobile 输出 18385 类（1 blank + 18384 字符），metadata 自带 character
        let character = session
            .metadata()
            .context("crnn metadata 读取失败")?
            .custom("character")
            .context("character 字段缺失")?
            .context("character 字段为空")?;

        let mut keys = Vec::with_capacity((character.len() as f32 / 3.9) as usize);
        keys.push("#".to_string()); // index 0 = CTC blank
        keys.extend(character.split('\n').map(|s| s.to_string()));
        keys.push(" ".to_string()); // 最后一个 = 空格

        eprintln!(
            "[ocr] 模型加载成功，字典 {} 字符（含 blank + 空格）",
            keys.len()
        );

        Ok(Self {
            inner: Some(Mutex::new(OcrInner {
                session,
                keys,
                input_name,
                allowed_mask: None,
            })),
        })
    }

    /// 降级构造：模型缺失时不崩溃，recognize 返回 Err，应用仍可启动改设置
    pub fn new_disabled() -> Self {
        Self { inner: None }
    }

    /// 设置字符级约束：传入当前赛季所有英雄名，提取字符合集构建 mask。
    /// 模型 argmax 时只能在英雄字 + blank 里选，从根源杜绝识别出英雄名以外的字。
    /// 完整英雄名匹配（完全匹配 / 双向包含）由前端 runDetect 负责，Rust 端只约束字符。
    /// 传入 None 清除约束（恢复开放词汇表）。
    /// 返回 (允许字符数, 总字符数) 供前端验证 mask 是否生效。
    pub fn set_allowed_chars(&self, names: Option<&[String]>) -> (usize, usize) {
        let Some(inner) = &self.inner else { return (0, 0); };
        let mut inner = inner.lock().unwrap();
        match names {
            None => {
                inner.allowed_mask = None;
                eprintln!("[ocr] 字符约束已清除");
                (0, 0)
            }
            Some(names) => {
                let chars: HashSet<char> = names
                    .iter()
                    .flat_map(|s| s.chars())
                    .filter(|c| ('\u{4e00}'..='\u{9fff}').contains(c))
                    .collect();
                let mask: Vec<bool> = inner
                    .keys
                    .iter()
                    .map(|k| {
                        if k == "#" || k == " " {
                            return true; // blank 和空格始终允许
                        }
                        let cv: Vec<char> = k.chars().collect();
                        cv.len() == 1 && chars.contains(&cv[0])
                    })
                    .collect();
                let allowed = mask.iter().filter(|b| **b).count();
                eprintln!(
                    "[ocr] 字符约束已设置：{} / {} 类允许（英雄名字用字 + blank），{} 个英雄名",
                    allowed,
                    mask.len(),
                    names.len()
                );
                inner.allowed_mask = Some(mask);
                (allowed, inner.keys.len())
            }
        }
    }

    /// 批量识别单行文本图，返回每张图的识别文本。
    /// 每张图生成 VARIANTS_PER_IMG 个预处理变体，逐变体推理后按置信度择优。
    pub fn recognize(&self, imgs: &[RgbImage]) -> Result<Vec<String>> {
        let inner = self
            .inner
            .as_ref()
            .ok_or_else(|| anyhow!("OCR 引擎未初始化（模型加载失败）"))?;
        let mut inner = inner.lock().unwrap();

        let mut results = Vec::with_capacity(imgs.len());
        for img in imgs.iter() {
            let mut best_text = String::new();
            let mut best_score: f32 = -1.0;
            for var in build_variants(img) {
                let line = Self::infer_one(&mut inner, &var)?;
                if line.text_score > best_score {
                    best_score = line.text_score;
                    best_text = line.text;
                }
            }
            results.push(best_text);
        }
        Ok(results)
    }

    /// 单张图推理：预处理 → ort run → CTC 解码（含 mask）
    fn infer_one(inner: &mut OcrInner, img: &RgbImage) -> Result<TextLine> {
        // 预处理：resize 到 height=48，width 按比例（与 paddle-ocr-rs 一致）
        let scale = CRNN_DST_HEIGHT as f32 / img.height() as f32;
        let dst_width = (img.width() as f32 * scale) as u32;
        let resized = imageops::resize(img, dst_width, CRNN_DST_HEIGHT, FilterType::Triangle);

        // subtract mean + normalize → Array4 [1, 3, 48, width]（CHW 布局）
        let input_array = subtract_mean_normalize(&resized, &MEAN_VALUES, &NORM_VALUES);
        let input_tensor = Tensor::from_array(input_array)?;

        let outputs = inner
            .session
            .run(inputs![inner.input_name.clone() => input_tensor])?;

        let (_, output_value) = outputs.iter().next().context("模型无输出")?;
        let (shape, data) = output_value.try_extract_tensor::<f32>()?;
        // shape = [1, seq_len, num_classes]
        let seq_len = shape[1] as usize;
        let num_classes = shape[2] as usize;

        Ok(Self::ctc_decode(
            data,
            seq_len,
            num_classes,
            &inner.keys,
            inner.allowed_mask.as_deref(),
        ))
    }

    /// CTC 解码：argmax 每个时间步，跳过 blank 和连续重复。
    /// 应用字符 mask：被屏蔽的字符 logit 视为 -inf，不会被选中。
    /// 完整英雄名匹配由前端负责（runDetect 的完全匹配 + 双向包含），
    /// 此处只保证输出文本只含英雄字，不做组合级校验（避免事中回退导致漏识别）。
    fn ctc_decode(
        output_data: &[f32],
        seq_len: usize,
        num_classes: usize,
        keys: &[String],
        mask: Option<&[bool]>,
    ) -> TextLine {
        let mut text = String::new();
        let mut last_index = 0usize;
        let mut score_sum = 0.0f32;
        let mut score_count = 0usize;

        for i in 0..seq_len {
            let start = i * num_classes;
            let stop = (i + 1) * num_classes;
            let slice = &output_data[start..stop.min(output_data.len())];

            // argmax（应用 mask：被屏蔽的字符 logit 视为 -inf，不会被选中）
            let (max_index, max_value) = match mask {
                Some(m) => {
                    // 1. 先在所有字符里找 raw argmax（含被屏蔽的非英雄字）
                    let (raw_idx, raw_val) = slice.iter().enumerate().fold(
                        (0usize, f32::MIN),
                        |(mi, mv), (idx, &val)| if val > mv { (idx, val) } else { (mi, mv) },
                    );
                    // 2. raw argmax 是允许字符（英雄字或 blank）→ 直接用
                    if raw_idx < m.len() && m[raw_idx] {
                        (raw_idx, raw_val)
                    } else {
                        // 3. raw argmax 是被屏蔽的非英雄字 → 选第二高英雄字（排除 blank）
                        //    不选 blank 是为了防止丢字导致误匹配：
                        //    如"塞恩"少"塞"→"恩"→误匹配"薇恩"；
                        //    选错英雄字最多导致漏识别（不匹配），比误匹配安全
                        slice.iter().enumerate().fold(
                            (0usize, f32::MIN),
                            |(mi, mv), (idx, &val)| {
                                if idx > 0 && idx < m.len() && m[idx] && val > mv {
                                    (idx, val)
                                } else {
                                    (mi, mv)
                                }
                            },
                        )
                    }
                }
                None => slice.iter().enumerate().fold(
                    (0usize, f32::MIN),
                    |(max_idx, max_val), (idx, &val)| {
                        if val > max_val {
                            (idx, val)
                        } else {
                            (max_idx, max_val)
                        }
                    },
                ),
            };

            // CTC 解码：跳过 blank(index 0) 和连续重复
            if max_index > 0 && max_index < keys.len() && !(i > 0 && max_index == last_index) {
                text.push_str(&keys[max_index]);
                score_sum += max_value;
                score_count += 1;
            }
            last_index = max_index;
        }

        let text_score = if score_count > 0 {
            score_sum / score_count as f32
        } else {
            0.0
        };
        TextLine { text, text_score }
    }
}

/// 预处理：subtract mean + normalize，返回 Array4 [1, 3, H, W]（与 paddle-ocr-rs OcrUtils 一致）
fn subtract_mean_normalize(img: &RgbImage, mean_vals: &[f32], norm_vals: &[f32]) -> Array4<f32> {
    let cols = img.width();
    let rows = img.height();
    let mut tensor = Array::zeros((1, 3, rows as usize, cols as usize));
    for r in 0..rows {
        for c in 0..cols {
            for ch in 0..3usize {
                let value = img.get_pixel(c, r)[ch] as f32;
                let data = value * norm_vals[ch] - mean_vals[ch] * norm_vals[ch];
                tensor[[0, ch, r as usize, c as usize]] = data;
            }
        }
    }
    tensor
}

/// 为一张裁切图生成预处理变体（均转为 RgbImage）。
///
/// 对齐《游戏白字OCR预处理指南》推荐流水线：裁剪(前端已做) → 放大2~3x → 转灰度 → 反色(关键) → 对比度增强 → (可选)二值化。
/// 注意：imageproc 0.25 无 CLAHE，按指南 3.1 用 stretch_contrast 替代（"简单对比度拉伸，替代 CLAHE，简单有效"）。
///
/// 三变体择优（覆盖三种典型场景，无冗余）：
/// - v0=Otsu全局二值化+BinaryInverted：干净背景 + 二值化，对复杂字（如「慎」）笔画更完整
/// - v1=自适应阈值反转：不均匀背景 + 二值化，对局部亮度不均更鲁棒
/// - v2=指南基础版(3.1)：反色 + 对比度拉伸（不二值化）
///   反色让白字→黑字，对齐 PaddleOCR 训练分布（黑字白底为主）；
///   stretch_contrast(10,245,0,255) 增强字身与背景分离，同时保留抗锯齿/发光细节（不二值化）
fn build_variants(img: &RgbImage) -> Vec<RgbImage> {
    let gray = DynamicImage::ImageRgb8(img.clone()).into_luma8();
    let (w, h) = (gray.width(), gray.height());
    let up = imageops::resize(&gray, w * 2, h * 2, FilterType::Lanczos3);

    let v0 = {
        let t = otsu_level(&up);
        let b = threshold(&up, t, ThresholdType::BinaryInverted);
        DynamicImage::ImageLuma8(b).into_rgb8()
    };

    let v1 = {
        let mut a = adaptive_threshold(&up, 5);
        invert_in_place(&mut a);
        DynamicImage::ImageLuma8(a).into_rgb8()
    };

    // v2=指南基础版(3.1)：灰度→放大→反色→对比度拉伸（不二值化）
    //   反色是指南核心步骤——PaddleOCR 训练以黑字白底为主，白字反转为黑字后模型更稳定
    //   stretch_contrast(10, 245, 0, 255) 线性映射 [10,245]→[0,255]，增强对比度（替代 CLAHE）
    let v2 = {
        let mut inv = up.clone();
        invert_in_place(&mut inv);
        let stretched = stretch_contrast(&inv, 10, 245, 0, 255);
        DynamicImage::ImageLuma8(stretched).into_rgb8()
    };

    vec![v0, v1, v2]
}

/// 原地反转灰度图（0↔255）
fn invert_in_place(img: &mut GrayImage) {
    for p in img.iter_mut() {
        *p = 255 - *p;
    }
}
