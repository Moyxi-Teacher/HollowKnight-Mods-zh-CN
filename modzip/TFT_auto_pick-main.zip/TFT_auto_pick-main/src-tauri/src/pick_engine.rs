//! 拿牌引擎：截屏 + 裁切名字区域 + OCR 识别 + 模拟点击
//!
//! OCR 识别在 Rust 端用 PaddleOCR（paddle-ocr-rs）完成，前端仅负责匹配 + 点击。
//! 流程：截屏 → 裁切5个名字区域 → aHash 变化检测 → PaddleOCR rec → 返回文本。

use anyhow::{anyhow, Context, Result};
use enigo::{Button, Coordinate, Direction, Enigo, Key, Keyboard, Mouse, Settings};
use image::{imageops, RgbImage, RgbaImage};
use std::sync::RwLock;

use crate::image_match::CardMatchEngine;
use crate::models::ShopRegion;
use crate::ocr::OcrEngine;
use crate::yolo::YoloEngine;

pub struct PickEngine {
    name_regions: RwLock<Vec<ShopRegion>>,
    /// 上次5个名字区域的 aHash，用于变化检测（None=未缓存）。
    /// 商店未变化时跳过 OCR，大幅降低自动循环模式下的 CPU 占用。
    last_hash: RwLock<Option<[u64; 5]>>,
    /// 一键卖出的英雄所在区域（用户框选，None=未设置）
    sell_region: RwLock<Option<ShopRegion>>,
    /// 找图模式：5 个卡牌整体区域（与 name_regions 平行，尺寸更大，覆盖整张卡）
    card_regions: RwLock<Vec<ShopRegion>>,
    /// 找图模式 aHash 缓存（与 last_hash 独立，避免模式切换互相污染）
    last_card_hash: RwLock<Option<[u64; 5]>>,
}

/// OCR 模式 aHash 阈值：单区域汉明距离阈值（任一区域 ≥ 此值即视为「变化」）。
/// 名字区域静止时 aHash 极稳定，刷新后完全不同。
/// 关键：用「单区域最大距离」而非「总和」，避免买牌后只 1 个区域变化时漏检。
const HASH_SINGLE_CHANGED_THRESHOLD: u32 = 6;

/// 找图模式 aHash 阈值：单区域汉明距离阈值（任一区域 ≥ 此值即视为「变化」）。
/// 卡牌整体区域更大、像素更多，aHash 抖动更明显，需调大。
/// 关键：用「单区域最大距离」而非「总和」，避免买牌后只 1 个区域变化时漏检。
const CARD_SINGLE_HASH_CHANGED_THRESHOLD: u32 = 8;

/// 卖出时英雄点击点相对血条框底部的 Y 偏移（像素）。
/// 正值下移、负值上移。当前 -100：点击点在血条框底部上方 100px 处（命中英雄身体中心）。
/// 模型训练后可按实际标注框范围微调。
const HERO_CLICK_Y_OFFSET: f32 = -100.0;

impl PickEngine {
    pub fn new() -> Self {
        Self {
            name_regions: RwLock::new(Vec::new()),
            last_hash: RwLock::new(None),
            sell_region: RwLock::new(None),
            card_regions: RwLock::new(Vec::new()),
            last_card_hash: RwLock::new(None),
        }
    }

    pub fn set_name_regions(&self, regions: Vec<ShopRegion>) {
        *self.name_regions.write().unwrap() = regions;
        // 区域变了，旧哈希失效，清空缓存强制下次重新识别
        *self.last_hash.write().unwrap() = None;
    }

    /// 设置找图模式的 5 个卡牌整体区域
    pub fn set_card_regions(&self, regions: Vec<ShopRegion>) {
        *self.card_regions.write().unwrap() = regions;
        // 只清 last_card_hash，不动 last_hash（避免模式切换互相污染）
        *self.last_card_hash.write().unwrap() = None;
    }

    /// 设置一键卖出的英雄所在区域（None = 清除）
    pub fn set_sell_region(&self, region: Option<ShopRegion>) {
        *self.sell_region.write().unwrap() = region;
    }

    /// 截屏 + 裁切5个名字区域 → PaddleOCR 识别 → 返回文本
    /// 变化检测：用 aHash 对比上次截屏，商店未变化时返回空 Vec（前端跳过匹配，省 CPU）。
    /// 空 Vec 表示商店未变化；非空 Vec 是5个区域对应的识别文本（与区域索引对齐）。
    pub fn capture_name_regions(&self, ocr: &OcrEngine) -> Result<Vec<String>> {
        let regions = self.name_regions.read().unwrap().clone();
        if regions.is_empty() {
            return Err(anyhow!("名字区域未设置"));
        }

        // 截屏
        let screen = self.capture_screen()?;

        // 裁切每个名字区域（保留原始 crop 用于 aHash + OCR）
        let mut crops: Vec<RgbaImage> = Vec::with_capacity(regions.len());
        let mut cur_hashes: [u64; 5] = [0; 5];
        for (i, region) in regions.iter().enumerate() {
            let rx = region.x.max(0) as u32;
            let ry = region.y.max(0) as u32;
            let rw = region.width.min(screen.width().saturating_sub(rx));
            let rh = region.height.min(screen.height().saturating_sub(ry));
            if rw == 0 || rh == 0 {
                crops.push(RgbaImage::new(1, 1));
                continue;
            }
            let crop = imageops::crop_imm(&screen, rx, ry, rw, rh).to_image();
            if i < 5 {
                cur_hashes[i] = ahash(&crop);
            }
            crops.push(crop);
        }

        // 变化检测：对比上次 aHash，未变化则返回空 Vec，前端跳过匹配
        // 关键修复：用「单区域最大汉明距离」而非「总和」判断变化。
        // 买牌后只有 1 个区域变化（卡牌消失），其他不变，总和可能 < 阈值被误判为「未变化」。
        // 任一区域汉明距离 ≥ HASH_SINGLE_CHANGED_THRESHOLD 即视为「变化」。
        let skip = {
            let last = self.last_hash.read().unwrap();
            if let Some(prev) = last.as_ref() {
                let n = regions.len().min(5);
                let max_dist: u32 = (0..n).map(|i| hamming(prev[i], cur_hashes[i])).max().unwrap_or(0);
                max_dist < HASH_SINGLE_CHANGED_THRESHOLD
            } else {
                false // 首次无缓存，必须识别
            }
        };
        if skip {
            return Ok(Vec::new());
        }

        // RgbaImage → RgbImage，调 PaddleOCR rec
        // 预处理（灰度/放大/二值化/反转）与多变体择优在 OcrEngine::recognize 内部完成，
        // 这里只负责把裁切转成 RGB 批量传入。
        // 全部 crop 一起识别（含1x1占位），保持与区域索引对齐；1x1 图 rec 输出空文本
        let rgb_imgs: Vec<RgbImage> = crops
            .iter()
            .map(|c| image::DynamicImage::ImageRgba8(c.clone()).into_rgb8())
            .collect();
        let texts = ocr.recognize(&rgb_imgs)?;

        // 更新哈希缓存
        *self.last_hash.write().unwrap() = Some(cur_hashes);
        Ok(texts)
    }

    /// 找图模式：截屏 + 裁切5个卡牌整体区域 → CardMatchEngine 全量 HSV 匹配 → 返回每张卡的 (chessId, score)。
    /// 全量识别所有 101 个英雄模板找 top-1，前端用结果做：
    /// - 显示实际识别成哪个英雄（便于观察识别错误）
    /// - 过滤拿牌池内的（chessId 在 customPicks + score ≥ 阈值）做点击
    /// 返回语义：
    /// - 空 Vec = 商店未变化（aHash 跳过），前端应用缓存重新匹配
    /// - 非空 Vec 含 (Option<String>, f32)：chessId=全量 top-1（None=模板未就绪），score=巴氏系数
    pub fn capture_card_regions(
        &self,
        matcher: &CardMatchEngine,
        force: bool,
    ) -> Result<Vec<(Option<String>, f32)>> {
        let regions = self.card_regions.read().unwrap().clone();
        if regions.is_empty() {
            return Err(anyhow!("卡牌区域未设置"));
        }

        // 截屏
        let screen = self.capture_screen()?;

        // 裁切每个卡牌整体区域（保留原始 crop 用于 aHash + 匹配）
        let mut crops: Vec<RgbImage> = Vec::with_capacity(regions.len());
        let mut cur_hashes: [u64; 5] = [0; 5];
        let mut target_hs: Vec<u32> = Vec::with_capacity(regions.len());
        for (i, region) in regions.iter().enumerate() {
            let rx = region.x.max(0) as u32;
            let ry = region.y.max(0) as u32;
            let rw = region.width.min(screen.width().saturating_sub(rx));
            let rh = region.height.min(screen.height().saturating_sub(ry));
            target_hs.push(rh);
            if rw == 0 || rh == 0 {
                crops.push(RgbImage::new(1, 1));
                continue;
            }
            let crop_rgba = imageops::crop_imm(&screen, rx, ry, rw, rh).to_image();
            let crop: RgbImage = image::DynamicImage::ImageRgba8(crop_rgba).into_rgb8();
            if i < 5 {
                // RgbImage 无 ahash 函数（其参数是 RgbaImage），用 Rgba 转 ahash
                let rgba = image::DynamicImage::ImageRgb8(crop.clone()).into_rgba8();
                cur_hashes[i] = ahash(&rgba);
            }
            crops.push(crop);
        }

        // 变化检测：对比上次 card aHash。force=true 时跳过（拿牌池变化需重新匹配）。
        // 关键修复：用「单区域最大汉明距离」而非「总和」判断变化。
        // 原逻辑用总和 < 16 判断「未变化」，但买牌后只有 1 个区域变化（如 slot5 卡牌消失），
        // 其他 4 个区域不变，总和可能 < 16 被误判为「未变化」→ 用缓存返回旧英雄 → 误点击。
        // 新逻辑：任一区域汉明距离 ≥ CARD_SINGLE_HASH_CHANGED_THRESHOLD 即视为「变化」。
        if !force {
            let skip = {
                let last = self.last_card_hash.read().unwrap();
                if let Some(prev) = last.as_ref() {
                    let n = regions.len().min(5);
                    let max_dist: u32 = (0..n).map(|i| hamming(prev[i], cur_hashes[i])).max().unwrap_or(0);
                    max_dist < CARD_SINGLE_HASH_CHANGED_THRESHOLD
                } else {
                    false
                }
            };
            if skip {
                return Ok(Vec::new());
            }
        }

        // 全量 HSV 匹配：遍历所有 101 个英雄模板找 top-1（巴氏系数 ~10ms，可接受）
        // 用 match_with_threshold 而不是 test_match：分数 < MATCH_THRESHOLD(0.9) 返回 None，
        // 避免空区域/卡牌消失后的背景被识别成英雄（分数 0.85+）导致误点击。
        let result = matcher.match_with_threshold(&crops, &target_hs)?;

        // 更新哈希缓存
        *self.last_card_hash.write().unwrap() = Some(cur_hashes);
        Ok(result)
    }

    /// 合并模式：一次截屏同时做 OCR + 找图，返回 (ocr_texts, image_results)。
    /// 比 capture_name_regions + capture_card_regions 各截一次屏省 1 次截屏开销，
    /// 且保证两个结果基于同一帧画面（避免时序不一致导致 OCR 和找图结果不对应）。
    /// 两套独立的 aHash 变化检测：各自 skip 时对应结果返回空 Vec。
    /// force=true 时跳过两套 aHash（拿牌池变化需重新匹配）。
    pub fn capture_both(
        &self,
        ocr: &OcrEngine,
        matcher: &CardMatchEngine,
        force: bool,
    ) -> Result<(Vec<String>, Vec<(Option<String>, f32)>)> {
        let t_start = std::time::Instant::now();

        // ===== 1. 截一次屏（两个模式共享）=====
        let screen = self.capture_screen()?;
        let t_capture = t_start.elapsed();

        // ===== 2. 裁切名字区 + aHash =====
        let name_regions = self.name_regions.read().unwrap().clone();
        let mut name_crops: Vec<RgbaImage> = Vec::with_capacity(name_regions.len());
        let mut name_hashes: [u64; 5] = [0; 5];
        for (i, region) in name_regions.iter().enumerate() {
            let rx = region.x.max(0) as u32;
            let ry = region.y.max(0) as u32;
            let rw = region.width.min(screen.width().saturating_sub(rx));
            let rh = region.height.min(screen.height().saturating_sub(ry));
            if rw == 0 || rh == 0 {
                name_crops.push(RgbaImage::new(1, 1));
                continue;
            }
            let crop = imageops::crop_imm(&screen, rx, ry, rw, rh).to_image();
            if i < 5 {
                name_hashes[i] = ahash(&crop);
            }
            name_crops.push(crop);
        }

        let ocr_skip = if !force {
            let last = self.last_hash.read().unwrap();
            if let Some(prev) = last.as_ref() {
                let n = name_regions.len().min(5);
                let max_dist: u32 = (0..n).map(|i| hamming(prev[i], name_hashes[i])).max().unwrap_or(0);
                max_dist < HASH_SINGLE_CHANGED_THRESHOLD
            } else {
                false
            }
        } else {
            false
        };

        // ===== 3. 裁切卡牌区 + aHash =====
        let card_regions = self.card_regions.read().unwrap().clone();
        let mut card_crops: Vec<RgbImage> = Vec::with_capacity(card_regions.len());
        let mut card_hashes: [u64; 5] = [0; 5];
        let mut target_hs: Vec<u32> = Vec::with_capacity(card_regions.len());
        for (i, region) in card_regions.iter().enumerate() {
            let rx = region.x.max(0) as u32;
            let ry = region.y.max(0) as u32;
            let rw = region.width.min(screen.width().saturating_sub(rx));
            let rh = region.height.min(screen.height().saturating_sub(ry));
            target_hs.push(rh);
            if rw == 0 || rh == 0 {
                card_crops.push(RgbImage::new(1, 1));
                continue;
            }
            let crop_rgba = imageops::crop_imm(&screen, rx, ry, rw, rh).to_image();
            let crop: RgbImage = image::DynamicImage::ImageRgba8(crop_rgba).into_rgb8();
            if i < 5 {
                let rgba = image::DynamicImage::ImageRgb8(crop.clone()).into_rgba8();
                card_hashes[i] = ahash(&rgba);
            }
            card_crops.push(crop);
        }

        let img_skip = if !force {
            let last = self.last_card_hash.read().unwrap();
            if let Some(prev) = last.as_ref() {
                let n = card_regions.len().min(5);
                let max_dist: u32 = (0..n).map(|i| hamming(prev[i], card_hashes[i])).max().unwrap_or(0);
                max_dist < CARD_SINGLE_HASH_CHANGED_THRESHOLD
            } else {
                false
            }
        } else {
            false
        };

        // 都 skip -> 返回两个空 Vec（前端用缓存）
        if ocr_skip && img_skip {
            return Ok((Vec::new(), Vec::new()));
        }

        // ===== 4. OCR（如果需要）=====
        let t_ocr_start = std::time::Instant::now();
        let ocr_texts = if ocr_skip {
            Vec::new()
        } else {
            let rgb_imgs: Vec<RgbImage> = name_crops
                .iter()
                .map(|c| image::DynamicImage::ImageRgba8(c.clone()).into_rgb8())
                .collect();
            let texts = ocr.recognize(&rgb_imgs)?;
            *self.last_hash.write().unwrap() = Some(name_hashes);
            texts
        };
        let t_ocr = t_ocr_start.elapsed();

        // ===== 5. 找图（如果需要）=====
        let t_img_start = std::time::Instant::now();
        let img_results = if img_skip {
            Vec::new()
        } else {
            let result = matcher.match_with_threshold(&card_crops, &target_hs)?;
            *self.last_card_hash.write().unwrap() = Some(card_hashes);
            result
        };
        let t_img = t_img_start.elapsed();

        eprintln!(
            "[capture_both] 截屏:{:?} OCR:{:?} 找图:{:?} 总计:{:?}",
            t_capture, t_ocr, t_img, t_start.elapsed()
        );

        Ok((ocr_texts, img_results))
    }

    /// 测试匹配（Settings 「测试匹配」按钮用）：
    /// 截屏 + 裁切5个卡牌区域 -> HSV 直方图匹配 -> 返回每张卡的 (chessId, score)（不应用阈值）
    pub fn test_card_match(
        &self,
        matcher: &CardMatchEngine,
    ) -> Result<Vec<(Option<String>, f32)>> {
        let regions = self.card_regions.read().unwrap().clone();
        if regions.is_empty() {
            return Err(anyhow!("卡牌区域未设置"));
        }

        let screen = self.capture_screen()?;
        let mut crops: Vec<RgbImage> = Vec::with_capacity(regions.len());
        let mut target_hs: Vec<u32> = Vec::with_capacity(regions.len());
        for region in regions.iter() {
            let rx = region.x.max(0) as u32;
            let ry = region.y.max(0) as u32;
            let rw = region.width.min(screen.width().saturating_sub(rx));
            let rh = region.height.min(screen.height().saturating_sub(ry));
            target_hs.push(rh);
            if rw == 0 || rh == 0 {
                crops.push(RgbImage::new(1, 1));
                continue;
            }
            let crop_rgba = imageops::crop_imm(&screen, rx, ry, rw, rh).to_image();
            let crop: RgbImage = image::DynamicImage::ImageRgba8(crop_rgba).into_rgb8();
            crops.push(crop);
        }

        matcher.test_match(&crops, &target_hs)
    }

    /// 测试匹配 + 步进搜索最佳 Y 轴偏移（Settings 测试按钮用）：
    /// 截屏 + 裁切5个卡牌区域 -> 步进搜索 -> 返回每张卡的 (chessId, score, dy)。
    /// 前端保存 offsets 后正式匹配直接用。
    pub fn test_card_match_with_offsets(
        &self,
        matcher: &CardMatchEngine,
    ) -> Result<Vec<(Option<String>, f32, i32)>> {
        let regions = self.card_regions.read().unwrap().clone();
        if regions.is_empty() {
            return Err(anyhow!("卡牌区域未设置"));
        }

        let screen = self.capture_screen()?;
        let mut crops: Vec<RgbImage> = Vec::with_capacity(regions.len());
        for region in regions.iter() {
            let rx = region.x.max(0) as u32;
            let ry = region.y.max(0) as u32;
            let rw = region.width.min(screen.width().saturating_sub(rx));
            let rh = region.height.min(screen.height().saturating_sub(ry));
            if rw == 0 || rh == 0 {
                crops.push(RgbImage::new(1, 1));
                continue;
            }
            let crop_rgba = imageops::crop_imm(&screen, rx, ry, rw, rh).to_image();
            let crop: RgbImage = image::DynamicImage::ImageRgba8(crop_rgba).into_rgb8();
            crops.push(crop);
        }

        matcher.test_match_with_offsets(&crops)
    }

    /// 模拟点击指定坐标（移动后短暂等待让游戏响应，按下释放间短暂间隔）
    pub fn click_position(&self, x: i32, y: i32) -> Result<()> {
        let mut enigo = Enigo::new(&Settings::default())
            .map_err(|e| anyhow!("创建Enigo失败: {}", e))?;

        // 移动鼠标到目标位置（绝对坐标）
        enigo
            .move_mouse(x, y, Coordinate::Abs)
            .map_err(|e| anyhow!("move_mouse失败: {}", e))?;
        std::thread::sleep(std::time::Duration::from_millis(5));

        // 点击（按下 + 释放）
        enigo
            .button(Button::Left, Direction::Press)
            .map_err(|e| anyhow!("press失败: {}", e))?;
        std::thread::sleep(std::time::Duration::from_millis(5));
        enigo
            .button(Button::Left, Direction::Release)
            .map_err(|e| anyhow!("release失败: {}", e))?;

        Ok(())
    }

    /// 一键卖出：截图卖出区域 → YOLO 识别血条 → 依次移到英雄位置按 E 卖出。
    /// 返回卖出的英雄数量。模型未就绪时 yolo.detect 返回 Err 向上抛出。
    pub fn sell_heroes(&self, yolo: &YoloEngine) -> Result<usize> {
        let region = self
            .sell_region
            .read()
            .unwrap()
            .ok_or_else(|| anyhow!("卖出区域未设置，请先框选"))?;

        // 截屏并裁切卖出区域（RgbaImage → RgbImage 喂给 YOLO）
        let screen = self.capture_screen()?;
        let rx = region.x.max(0) as u32;
        let ry = region.y.max(0) as u32;
        let rw = region.width.min(screen.width().saturating_sub(rx));
        let rh = region.height.min(screen.height().saturating_sub(ry));
        if rw == 0 || rh == 0 {
            return Err(anyhow!("卖出区域无效"));
        }
        let crop_rgba = imageops::crop_imm(&screen, rx, ry, rw, rh).to_image();
        let crop: RgbImage = image::DynamicImage::ImageRgba8(crop_rgba).into_rgb8();

        // YOLO 检测血条
        let boxes = yolo.detect(&crop)?;
        if boxes.is_empty() {
            return Ok(0);
        }

        let mut enigo = Enigo::new(&Settings::default())
            .map_err(|e| anyhow!("创建Enigo失败: {}", e))?;

        // 依次移到每个英雄位置按 E 卖出。
        // 点击点：血条框中心 X，框底部 + 偏移 = 英雄身体方向。
        // 屏幕绝对坐标 = 区域原点 + 框内坐标。
        for b in &boxes {
            let click_x = region.x + (b.x + b.w / 2.0) as i32;
            let click_y = region.y + (b.y + b.h + HERO_CLICK_Y_OFFSET) as i32;
            enigo
                .move_mouse(click_x, click_y, Coordinate::Abs)
                .map_err(|e| anyhow!("move_mouse失败: {}", e))?;
            std::thread::sleep(std::time::Duration::from_millis(30));
            // 按 E 键卖出（按下 + 释放）
            enigo
                .key(Key::Unicode('e'), Direction::Press)
                .map_err(|e| anyhow!("press E失败: {}", e))?;
            std::thread::sleep(std::time::Duration::from_millis(20));
            enigo
                .key(Key::Unicode('e'), Direction::Release)
                .map_err(|e| anyhow!("release E失败: {}", e))?;
            // 每个英雄间隔 50ms，给游戏留出卖出响应时间
            std::thread::sleep(std::time::Duration::from_millis(50));
        }

        Ok(boxes.len())
    }

    /// 点击屏幕左下角焦点位置（距左 200px、距底 200px），让游戏窗口获得焦点（框选卖出区域后调用）。
    /// RegionPicker 全屏窗口关闭后游戏自然显露，此点击确保鼠标移入游戏画面并激活焦点。
    /// 选左下角而非中心，避免误点棋盘中央的英雄/操作。
    pub fn click_focus_point(&self) -> Result<()> {
        let monitors = xcap::Monitor::all().context("获取显示器列表失败")?;
        let monitor = monitors
            .into_iter()
            .find(|m| m.is_primary())
            .ok_or_else(|| anyhow!("未找到主显示器"))?;
        // 距左下角宽高各 200：x=200，y=屏幕高-200
        let fx = 200i32;
        let fy = (monitor.height() as i32 - 200).max(0);

        let mut enigo = Enigo::new(&Settings::default())
            .map_err(|e| anyhow!("创建Enigo失败: {}", e))?;
        enigo
            .move_mouse(fx, fy, Coordinate::Abs)
            .map_err(|e| anyhow!("move_mouse失败: {}", e))?;
        std::thread::sleep(std::time::Duration::from_millis(30));
        enigo
            .button(Button::Left, Direction::Press)
            .map_err(|e| anyhow!("press失败: {}", e))?;
        std::thread::sleep(std::time::Duration::from_millis(20));
        enigo
            .button(Button::Left, Direction::Release)
            .map_err(|e| anyhow!("release失败: {}", e))?;
        Ok(())
    }

    /// 截取主显示器
    fn capture_screen(&self) -> Result<RgbaImage> {
        let monitors = xcap::Monitor::all().context("获取显示器列表失败")?;
        let monitor = monitors
            .into_iter()
            .find(|m| m.is_primary())
            .ok_or_else(|| anyhow!("未找到主显示器"))?;

        let img = monitor
            .capture_image()
            .context("截屏失败（可能需要管理员权限）")?;
        Ok(img)
    }
}

// ============ 图像哈希（变化检测） ============

/// 均值哈希（aHash）：图像缩放到 8x8 灰度，按均值二值化为 64 位哈希。
/// 用于快速判断商店名字区域是否变化，未变化时跳过 OCR 以降低 CPU 占用。
fn ahash(img: &RgbaImage) -> u64 {
    if img.width() == 0 || img.height() == 0 {
        return 0;
    }
    let small = imageops::resize(img, 8, 8, imageops::FilterType::Nearest);
    let gray = imageops::grayscale(&small);
    // 灰度图（Luma<u8>）每个像素 1 字节，as_raw() 直接拿到 &[u8] 像素数组
    let pixels: &[u8] = gray.as_raw();
    let mean: u32 = pixels.iter().map(|&v| v as u32).sum::<u32>() / 64;
    let mut hash: u64 = 0;
    for (i, &v) in pixels.iter().enumerate() {
        if v as u32 > mean {
            hash |= 1 << i;
        }
    }
    hash
}

/// 两个 64 位哈希的汉明距离（不同 bit 数）
fn hamming(a: u64, b: u64) -> u32 {
    (a ^ b).count_ones()
}
