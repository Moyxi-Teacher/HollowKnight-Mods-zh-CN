//! Tauri 应用入口与命令注册
mod hotkey;
mod image_match;
mod models;
mod ocr;
mod pick_engine;
mod provider;
mod yolo;

use std::sync::Arc;

use hotkey::HotkeyManager;
use image_match::CardMatchEngine;
use ocr::OcrEngine;
use pick_engine::PickEngine;
use provider::DataProvider;
use yolo::YoloEngine;
use tauri::Manager;

use models::*;

/// 拉取/刷新官方数据（带本地缓存，按版本指纹比对）
/// 刷新成功后顺便触发 CardMatchEngine 模板重载（如果赛季有变）
#[tauri::command]
async fn refresh_data(
    state: tauri::State<'_, Arc<DataProvider>>,
    matcher: tauri::State<'_, Arc<CardMatchEngine>>,
    app: tauri::AppHandle,
) -> Result<VersionInfo, String> {
    let info = state.refresh().await.map_err(|e| e.to_string())?;
    // 触发模板重载（set_season 内部判断赛季是否变化，未变则跳过）
    let provider = state.inner().clone();
    let app_clone = app.clone();
    let matcher_clone = matcher.inner().clone();
    let new_season = state.current_target_season();
    matcher.set_season(&new_season);
    // 后台预热（不阻塞 refresh 返回）
    tauri::async_runtime::spawn(async move {
        if let Err(e) = matcher_clone.preload(app_clone, provider).await {
            eprintln!("[image_match] 后台预热失败: {}", e);
        }
    });
    Ok(info)
}

/// 当前版本信息
#[tauri::command]
fn get_version_info(state: tauri::State<'_, Arc<DataProvider>>) -> Result<VersionInfo, String> {
    state.get_version_info().map_err(|e| e.to_string())
}

/// 全部英雄
#[tauri::command]
fn get_champions(state: tauri::State<'_, Arc<DataProvider>>) -> Vec<Chess> {
    state.get_champions()
}

/// 阵容简表（含每阶段该拿的 chessId）
#[tauri::command]
fn get_lineups(state: tauri::State<'_, Arc<DataProvider>>) -> Result<Vec<LineupBrief>, String> {
    state.get_lineups().map_err(|e| e.to_string())
}

/// 指定阵容、阶段(0/1/2) 的拿牌清单
#[tauri::command]
fn get_pick_list(
    state: tauri::State<'_, Arc<DataProvider>>,
    lineup_id: String,
    stage: usize,
) -> Result<Vec<PickCard>, String> {
    state
        .get_pick_list(&lineup_id, stage)
        .map_err(|e| e.to_string())
}

/// 拉取当前活跃模式注册表（主网站 tft-mode-registry.js）。
/// 返回当前正赛代号 + 全部活跃模式列表（星神/恭喜发财等，随版本自动更新）。
#[tauri::command]
async fn get_game_modes(state: tauri::State<'_, Arc<DataProvider>>) -> Result<CurrentModeInfo, String> {
    state.fetch_game_modes().await.map_err(|e| e.to_string())
}

/// 切换游戏模式：传入 versionconfig 的 idSeason 代号（如 "s17"=星神、"s16m17"=恭喜发财）。
/// 代号来自 get_game_modes 返回的 GameMode.season，随版本注册表自动同步，无需硬编码。
#[tauri::command]
fn set_game_mode(
    state: tauri::State<'_, Arc<DataProvider>>,
    season: String,
) -> Result<String, String> {
    if season.trim().is_empty() {
        return Err("游戏模式代号不能为空".to_string());
    }
    state.set_target_season(&season);
    Ok(state.current_target_season())
}

/// 当前游戏模式对应的 id_season 代号
#[tauri::command]
fn get_game_mode(state: tauri::State<'_, Arc<DataProvider>>) -> String {
    state.current_target_season()
}

// ============ 拿牌引擎命令 ============

/// 设置5个卡牌名字区域（前端框选后调用）
#[tauri::command]
fn set_name_regions(engine: tauri::State<'_, Arc<PickEngine>>, regions: Vec<ShopRegion>) {
    engine.set_name_regions(regions);
}

/// 设置找图模式的 5 个卡牌整体区域（前端框选后调用）
#[tauri::command]
fn set_card_regions(engine: tauri::State<'_, Arc<PickEngine>>, regions: Vec<ShopRegion>) {
    engine.set_card_regions(regions);
}

/// 找图模式：截屏 + 裁切5个卡牌区域 → HSV 全量匹配 → 返回每张卡的 (chessId, score)。
/// 返回 Vec<(Option<String>, f32)>：空 Vec=商店未变化（用缓存），非空 Vec 含 top-1 chessId + 巴氏系数。
/// 前端用结果做：显示实际识别成哪个英雄 + 过滤拿牌池内的做点击。
/// force=true 时跳过 aHash 变化检测，强制重新匹配（拿牌池变化时用）。
#[tauri::command]
async fn capture_card_regions(
    engine: tauri::State<'_, Arc<PickEngine>>,
    matcher: tauri::State<'_, Arc<CardMatchEngine>>,
    force: bool,
) -> Result<Vec<(Option<String>, f32)>, String> {
    let engine = engine.inner().clone();
    let matcher = matcher.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        engine.capture_card_regions(&matcher, force).map_err(|e| e.to_string())
    })
    .await
    .map_err(|e| format!("后台任务失败: {}", e))?
}

/// 合并模式：一次截屏同时做 OCR + 找图，返回 (ocr_texts, image_results)。
/// 省一次截屏开销，且保证两个结果基于同一帧画面。
/// force=true 时跳过两套 aHash（拿牌池变化需重新匹配）。
#[tauri::command]
async fn capture_both(
    engine: tauri::State<'_, Arc<PickEngine>>,
    ocr: tauri::State<'_, Arc<OcrEngine>>,
    matcher: tauri::State<'_, Arc<CardMatchEngine>>,
    force: bool,
) -> Result<(Vec<String>, Vec<(Option<String>, f32)>), String> {
    let engine = engine.inner().clone();
    let ocr = ocr.inner().clone();
    let matcher = matcher.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        engine.capture_both(&ocr, &matcher, force).map_err(|e| e.to_string())
    })
    .await
    .map_err(|e| format!("后台任务失败: {}", e))?
}

/// 找图模式测试匹配（Settings 「测试匹配」按钮用）：
/// 返回每张卡的 (chessId, score)，不应用阈值，供前端显示原始分数判断框选是否正确。
#[tauri::command]
async fn test_card_match(
    engine: tauri::State<'_, Arc<PickEngine>>,
    matcher: tauri::State<'_, Arc<CardMatchEngine>>,
) -> Result<Vec<(Option<String>, f32)>, String> {
    let engine = engine.inner().clone();
    let matcher = matcher.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        engine.test_card_match(&matcher).map_err(|e| e.to_string())
    })
    .await
    .map_err(|e| format!("后台任务失败: {}", e))?
}

/// 测试匹配 + 步进搜索最佳 Y 轴偏移（Settings 测试按钮用）：
/// 返回每张卡的 (chessId, score, dy)，前端保存 offsets 后正式匹配直接用。
#[tauri::command]
async fn test_match_with_offsets(
    engine: tauri::State<'_, Arc<PickEngine>>,
    matcher: tauri::State<'_, Arc<CardMatchEngine>>,
) -> Result<Vec<(Option<String>, f32, i32)>, String> {
    let engine = engine.inner().clone();
    let matcher = matcher.inner().clone();
    tauri::async_runtime::spawn_blocking(move || {
        engine.test_card_match_with_offsets(&matcher).map_err(|e| e.to_string())
    })
    .await
    .map_err(|e| format!("后台任务失败: {}", e))?
}

/// 设置卡牌区域 Y 轴裁剪偏移（Settings 保存时调用，正式匹配直接用偏移不需搜索）
#[tauri::command]
fn set_card_offsets(
    matcher: tauri::State<'_, Arc<CardMatchEngine>>,
    offsets: Vec<i32>,
) -> Result<(), String> {
    matcher.set_offsets(offsets);
    Ok(())
}

/// 注册全局热键（按 kind 设置对应热键：action=手动刷新+检测，auto=自动模式开关）
#[tauri::command]
fn register_hotkey(
    app: tauri::AppHandle,
    hotkey_mgr: tauri::State<'_, Arc<HotkeyManager>>,
    hotkey: String,
    kind: String,
) -> Result<(), String> {
    let kind = hotkey::HotkeyKind::from_str(&kind)?;
    hotkey_mgr.register(&app, &hotkey, kind)
}

/// 注销指定种类的热键
#[tauri::command]
fn unregister_hotkey(
    app: tauri::AppHandle,
    hotkey_mgr: tauri::State<'_, Arc<HotkeyManager>>,
    kind: String,
) -> Result<(), String> {
    let kind = hotkey::HotkeyKind::from_str(&kind)?;
    hotkey_mgr.unregister(&app, kind);
    Ok(())
}

/// 当前已注册的指定种类热键
#[tauri::command]
fn get_current_hotkey(
    hotkey_mgr: tauri::State<'_, Arc<HotkeyManager>>,
    kind: String,
) -> Result<Option<String>, String> {
    let kind = hotkey::HotkeyKind::from_str(&kind)?;
    Ok(hotkey_mgr.current(kind))
}

/// 截屏 + 裁切5个名字区域 → PaddleOCR 识别 → 返回文本（前端匹配后点击）
#[tauri::command]
fn capture_name_regions(
    engine: tauri::State<'_, Arc<PickEngine>>,
    ocr: tauri::State<'_, Arc<OcrEngine>>,
) -> Result<Vec<String>, String> {
    engine
        .capture_name_regions(ocr.as_ref())
        .map_err(|e| e.to_string())
}

/// 设置 OCR 字符级约束：传入当前赛季所有英雄名，提取字符合集构建 mask。
/// 模型 argmax 时只能在英雄字 + blank 里选，从根源杜绝识别出英雄名以外的字。
/// 传入空 Vec = 清除约束（恢复开放词汇表）。
/// 返回 [允许字符数, 总字符数] 供前端验证 mask 是否生效。
#[tauri::command]
fn set_ocr_allowed_chars(
    ocr: tauri::State<'_, Arc<OcrEngine>>,
    names: Vec<String>,
) -> Result<[usize; 2], String> {
    let result = if names.is_empty() {
        ocr.set_allowed_chars(None)
    } else {
        ocr.set_allowed_chars(Some(&names))
    };
    Ok([result.0, result.1])
}

/// 模拟点击指定坐标（前端 OCR 识别匹配后调用）
#[tauri::command]
fn click_position(engine: tauri::State<'_, Arc<PickEngine>>, x: i32, y: i32) -> Result<(), String> {
    engine.click_position(x, y).map_err(|e| e.to_string())
}

/// 设置一键卖出的英雄所在区域（前端框选后调用，None=清除）
#[tauri::command]
fn set_sell_region(engine: tauri::State<'_, Arc<PickEngine>>, region: Option<ShopRegion>) {
    engine.set_sell_region(region);
}

/// 一键卖出：截图卖出区域 → YOLO 识别血条 → 依次移到英雄位置按 E 卖出。
/// 返回卖出的英雄数量。
#[tauri::command]
fn sell_heroes(
    engine: tauri::State<'_, Arc<PickEngine>>,
    yolo: tauri::State<'_, Arc<YoloEngine>>,
) -> Result<usize, String> {
    engine.sell_heroes(yolo.as_ref()).map_err(|e| e.to_string())
}

/// 点击屏幕左下角焦点位置（距左 200、距底 200），让游戏窗口获得焦点（框选卖出区域后调用）
#[tauri::command]
fn click_focus_point(engine: tauri::State<'_, Arc<PickEngine>>) -> Result<(), String> {
    engine.click_focus_point().map_err(|e| e.to_string())
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            // 缓存目录：系统应用缓存目录
            let cache_dir = app
                .path()
                .app_cache_dir()
                .map_err(|e| Box::<dyn std::error::Error>::from(e))?;
            let provider = Arc::new(DataProvider::new(cache_dir.clone())?);
            let engine = Arc::new(PickEngine::new());
            let hotkey_mgr = Arc::new(HotkeyManager::new());
            // 初始化低级键盘钩子（启动专用线程运行消息泵）
            hotkey_mgr.init(&app.handle());
            app.manage(provider.clone());
            app.manage(engine);
            app.manage(hotkey_mgr);

            // OCR 引擎：固定 ORT_DYLIB_PATH 指向打包的 onnxruntime.dll，避免 System32 旧版污染
            // 必须在创建 OcrEngine 前设置（ort load-dynamic 运行期读此变量加载 dll）
            let resource_dir = app
                .path()
                .resource_dir()
                .map_err(|e| Box::<dyn std::error::Error>::from(e))?;
            // Windows 上 resource_dir() = exe 所在目录；tauri-bundler 保留配置里的 "resources/" 前缀，
            // 故 dll/模型实际在 <exe_dir>/resources/ 下（dev=target/debug/resources，release=target/release/resources）
            let resources_root = resource_dir.join("resources");
            let ort_dll = resources_root.join("onnxruntime.dll");
            std::env::set_var("ORT_DYLIB_PATH", &ort_dll);
            eprintln!("[ocr] ORT_DYLIB_PATH = {}", ort_dll.display());

            let model_dir = resources_root.join("models");
            let ocr_engine = match OcrEngine::new(&model_dir) {
                Ok(e) => {
                    eprintln!("[ocr] PaddleOCR 引擎初始化成功");
                    Arc::new(e)
                }
                Err(e) => {
                    eprintln!("[ocr] PaddleOCR 引擎初始化失败: {}. OCR 不可用", e);
                    Arc::new(OcrEngine::new_disabled())
                }
            };
            app.manage(ocr_engine);

            // YOLO 引擎：复用 ORT_DYLIB_PATH（已由 OCR 初始化时设置）加载 yolo.onnx。
            // 模型由用户后期自行训练导出放入 resources/models/yolo.onnx，
            // 未放入时走 new_disabled 降级（sell_heroes 调用时返回 Err，应用仍可启动）。
            let yolo_engine = match YoloEngine::new(&model_dir) {
                Ok(e) => {
                    eprintln!("[yolo] YOLO 引擎初始化成功");
                    Arc::new(e)
                }
                Err(e) => {
                    eprintln!(
                        "[yolo] YOLO 引擎初始化失败: {}. 一键卖出不可用（放入 yolo.onnx 后重启生效）",
                        e
                    );
                    Arc::new(YoloEngine::new_disabled())
                }
            };
            app.manage(yolo_engine);

            // 找图引擎：用默认赛季 s17 初始化（refresh 后会按真实赛季重载）。
            // 后台预热（tokio::spawn），不阻塞启动。模板未就绪时 capture_card_regions 返回 Err。
            let card_match_engine = Arc::new(CardMatchEngine::new(
                cache_dir.clone(),
                "s17".to_string(),
            ));
            let provider_for_preload = provider.clone();
            let matcher_for_preload = card_match_engine.clone();
            let app_for_preload = app.handle().clone();
            tauri::async_runtime::spawn(async move {
                if let Err(e) = matcher_for_preload
                    .preload(app_for_preload, provider_for_preload)
                    .await
                {
                    eprintln!("[image_match] 启动预热失败: {}", e);
                }
            });
            app.manage(card_match_engine);
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            // 数据层
            refresh_data,
            get_version_info,
            get_champions,
            get_lineups,
            get_pick_list,
            get_game_modes,
            set_game_mode,
            get_game_mode,
            // 拿牌引擎
            set_name_regions,
            set_card_regions,
            capture_card_regions,
            capture_both,
            test_card_match,
            test_match_with_offsets,
            set_card_offsets,
            register_hotkey,
            unregister_hotkey,
            get_current_hotkey,
            capture_name_regions,
            set_ocr_allowed_chars,
            click_position,
            // 一键卖出
            set_sell_region,
            sell_heroes,
            click_focus_point,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
