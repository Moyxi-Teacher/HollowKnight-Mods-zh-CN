//! 数据层：从官方接口拉取英雄/阵容数据，带本地 JSON 缓存
use anyhow::{anyhow, Context, Result};
use regex::Regex;
use reqwest::Client;
use serde::de::DeserializeOwned;
use std::{
    collections::HashMap,
    fs,
    path::{Path, PathBuf},
    sync::{Arc, RwLock},
    time::{SystemTime, UNIX_EPOCH},
};

use crate::models::*;

const VERSION_CONFIG_URL: &str = "https://lol.qq.com/zmtftzone/public-lib/versionconfig.json";
const VERSION_LIST_URL: &str = "https://mlol.qt.qq.com/go/database/versionlist?zone=lol&from=h5";
/// 主网站活跃模式注册表（JS 文本，非 JSON）。
/// 腾讯版本更新时会改此文件：增删模式、改代号、注释掉过期模式。
/// 解析后得到当前活跃模式的 name/season(=versionconfig 的 idSeason)/lineupUrl。
const MODE_REGISTRY_URL: &str = "https://lol.qq.com/tft/js/tft-mode-registry.js";
const LINEUP_URL_BASE: &str =
    "https://game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/6";
const LINEUP_FILE: &str = "lineup_detail_total.json";

/// 根据游戏模式返回阵容接口 URL
/// - 星神 s17: lineupJson/s17/6/lineup_detail_total.json
/// - 恭喜发财 s16m17: lineupJson/s17/6/1210/lineup_detail_total.json（复用 s17 框架，1210 后缀对应 chess-1210.js）
fn lineup_url_for(season: &str) -> String {
    match season {
        MODE_GONGXI => format!("{}/1210/{}", LINEUP_URL_BASE, LINEUP_FILE),
        _ => format!("{}/{}", LINEUP_URL_BASE, LINEUP_FILE),
    }
}

/// 英雄头像 CDN 基址（按 chessId 拼接：{base}{chessId}.png）
/// 注意：chess.js 的 originalImage/skillImage 字段实为技能图标，非英雄头像
const HERO_IMG_BASE: &str = "https://game.gtimg.cn/images/lol/act/img/tft/champions/";

/// 游戏模式 → 对应 versionconfig 中的 id_season 字段
/// versionconfig 含 25 个条目（恭喜发财/时光机/正赛/历史赛季），
/// 各条目 chessId 体系不同，必须精确匹配否则与 lineup 对不上
pub const MODE_STARSHEN: &str = "s17"; // 星神（正赛）
pub const MODE_GONGXI: &str = "s16m17"; // 恭喜发财

pub struct DataProvider {
    client: Client,
    cache_dir: PathBuf,
    /// 当前游戏模式对应的 id_season，可运行时切换
    target_season: RwLock<String>,
    version_info: RwLock<Option<Arc<VersionInfo>>>,
    chess_list: RwLock<Option<Arc<Vec<Chess>>>>,
    chess_map: RwLock<Option<Arc<HashMap<String, Chess>>>>,
    lineups: RwLock<Option<Arc<Vec<Lineup>>>>,
}

impl DataProvider {
    pub fn new(cache_dir: PathBuf) -> Result<Self> {
        fs::create_dir_all(&cache_dir)?;
        let client = Client::builder()
            .user_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) TFT-AutoPick")
            .build()?;
        Ok(Self {
            client,
            cache_dir,
            // 空字符串 = 未选择，refresh 时从 registry 的 current_set 自动取默认正赛模式
            target_season: RwLock::new(String::new()),
            version_info: RwLock::new(None),
            chess_list: RwLock::new(None),
            chess_map: RwLock::new(None),
            lineups: RwLock::new(None),
        })
    }

    /// 切换游戏模式（星神/恭喜发财），并清空内存+磁盘缓存强制下次 refresh 重新拉
    pub fn set_target_season(&self, season: &str) {
        let mut g = self.target_season.write().unwrap();
        if &*g != season {
            *g = season.to_string();
            drop(g);
            // 清空内存缓存，避免不同模式数据混淆
            *self.version_info.write().unwrap() = None;
            *self.chess_list.write().unwrap() = None;
            *self.chess_map.write().unwrap() = None;
            *self.lineups.write().unwrap() = None;
            // 清空磁盘缓存（vkey 可能跨模式相同，仅靠 vkey 比对会命中错误模式）
            let _ = fs::remove_file(self.meta_path());
            let _ = fs::remove_file(self.chess_path());
            let _ = fs::remove_file(self.lineups_path());
        }
    }

    pub fn current_target_season(&self) -> String {
        self.target_season.read().unwrap().clone()
    }

    /// 拉取当前活跃模式注册表（主网站 tft-mode-registry.js）。
    /// 返回当前正赛代号 + 全部活跃模式（已排除被注释的过期模式）。
    /// 抓取/解析失败返回错误，由调用方决定兜底。
    pub async fn fetch_game_modes(&self) -> Result<CurrentModeInfo> {
        let text = self.fetch_text(MODE_REGISTRY_URL).await?;
        parse_mode_registry(&text)
    }

    /// 拉版本配置，按 vkey 比对缓存，按需更新
    pub async fn refresh(&self) -> Result<VersionInfo> {
        // 1. 取最新版本指纹 vkey
        let ts = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .map(|d| d.as_secs())
            .unwrap_or(0);
        let vlist: VersionListWrap = self
            .fetch_json(&format!("{}&v={}", VERSION_LIST_URL, ts))
            .await?;
        let vkey = vlist
            .data
            .first()
            .map(|v| v.vkey.clone())
            .ok_or_else(|| anyhow!("versionlist 为空"))?;

        // 2. 抓活跃模式注册表（拿默认 season + 各模式 lineup URL）；失败则用硬编码兜底
        //    registry 来自主网站 tft-mode-registry.js，随版本更新自动同步模式代号
        let mode_info = self
            .fetch_game_modes()
            .await
            .unwrap_or_else(|_| CurrentModeInfo {
                current_set: MODE_STARSHEN.to_string(),
                modes: Vec::new(),
            });

        // 3. 确定 target_season：空则取 registry 的 current_set（兜底 MODE_STARSHEN）
        //    versionconfig 含 25 个条目（恭喜发财/时光机/正赛/历史赛季等），
        //    各条目 chessId 体系不同，必须精确匹配 target_season 否则与 lineup 对不上
        let target_season = {
            let g = self.target_season.read().unwrap().clone();
            if g.is_empty() {
                let default = if !mode_info.current_set.is_empty() {
                    mode_info.current_set.clone()
                } else {
                    mode_info
                        .modes
                        .iter()
                        .find(|m| !m.is_rgm)
                        .or_else(|| mode_info.modes.first())
                        .map(|m| m.season.clone())
                        .unwrap_or_else(|| MODE_STARSHEN.to_string())
                };
                *self.target_season.write().unwrap() = default.clone();
                default
            } else {
                g
            }
        };
        let configs: Vec<VersionConfig> = self.fetch_json(VERSION_CONFIG_URL).await?;
        let cfg = configs
            .iter()
            .find(|c| c.id_season == target_season)
            .or_else(|| configs.first())
            .ok_or_else(|| anyhow!("versionconfig 为空"))?;

        // 3. vkey 命中缓存则直接加载本地
        if let Some(meta) = self.load_meta() {
            if meta.vkey == vkey {
                if let (Some(chess), Some(lineups)) =
                    (self.load_chess_cache(), self.load_lineups_cache())
                {
                    return self.populate_cache(meta, chess, lineups);
                }
            }
        }

        // 4. 缓存未命中，拉英雄与阵容
        let chess_wrap: ChessWrap = self.fetch_json(&cfg.url_chess_data).await?;
        // lineup URL：优先 registry 该 season 的 lineup_url（随版本走），否则回退硬编码
        let lineup_url = mode_info
            .modes
            .iter()
            .find(|m| m.season == target_season)
            .filter(|m| !m.lineup_url.is_empty())
            .map(|m| format!("{}?v={}", m.lineup_url, ts))
            .unwrap_or_else(|| lineup_url_for(&target_season));
        let lineup_wrap: LineupWrap = self.fetch_json(&lineup_url).await?;

        // 过滤道具/锻造器，仅保留真正英雄
        let chess: Vec<Chess> = chess_wrap.data.into_iter().filter(|c| c.is_real_hero()).collect();
        let lineups = lineup_wrap.lineup_list;

        let meta = CacheMeta {
            vkey: vkey.clone(),
            // 用 chess.js 自带的 version（如 "16.14"），比 cfg.arr_version_limit 更准
            version: chess_wrap.version.clone(),
            season: chess_wrap.season.clone(),
            season_name: cfg.string_name.clone(),
        };

        // 5. 持久化
        self.save_meta(&meta)?;
        self.save_json("chess.json", &chess)?;
        self.save_json("lineups.json", &lineups)?;

        self.populate_cache(meta, chess, lineups)
    }

    /// 当前版本信息（须先 refresh）
    pub fn get_version_info(&self) -> Result<VersionInfo> {
        self.version_info
            .read()
            .unwrap()
            .as_ref()
            .map(|a| (**a).clone())
            .ok_or_else(|| anyhow!("数据未加载，请先刷新"))
    }

    /// 全部英雄
    pub fn get_champions(&self) -> Vec<Chess> {
        self.chess_list
            .read()
            .unwrap()
            .as_ref()
            .map(|a| (**a).clone())
            .unwrap_or_default()
    }

    /// 阵容简表（含每阶段该拿的 chessId）
    pub fn get_lineups(&self) -> Result<Vec<LineupBrief>> {
        let lineups = self
            .lineups
            .read()
            .unwrap()
            .as_ref()
            .map(|a| (**a).clone())
            .ok_or_else(|| anyhow!("数据未加载，请先刷新"))?;

        Ok(lineups
            .iter()
            .map(|l| {
                let detail = parse_detail(&l.detail).unwrap_or_else(|_| LineupDetail {
                    line_name: String::new(),
                    search_card_rhythm: Vec::new(),
                });
                let pick_stages = detail
                    .search_card_rhythm
                    .iter()
                    .map(|stage| stage.iter().map(|c| c.id.clone()).collect())
                    .collect();
                LineupBrief {
                    id: l.id.clone(),
                    line_name: detail.line_name,
                    quality: l.quality.clone(),
                    pick_stages,
                }
            })
            .collect())
    }

    /// 指定阵容、阶段(0/1/2) 的拿牌清单
    pub fn get_pick_list(&self, lineup_id: &str, stage: usize) -> Result<Vec<PickCard>> {
        let lineups = self
            .lineups
            .read()
            .unwrap()
            .as_ref()
            .map(|a| (**a).clone())
            .ok_or_else(|| anyhow!("数据未加载，请先刷新"))?;
        let chess_map = self
            .chess_map
            .read()
            .unwrap()
            .as_ref()
            .map(|a| (**a).clone())
            .ok_or_else(|| anyhow!("数据未加载，请先刷新"))?;

        let lineup = lineups
            .iter()
            .find(|l| l.id == lineup_id)
            .ok_or_else(|| anyhow!("未找到阵容 {}", lineup_id))?;
        let detail = parse_detail(&lineup.detail).context("解析阵容 detail 失败")?;
        let stage_cards = detail
            .search_card_rhythm
            .get(stage)
            .ok_or_else(|| anyhow!("阶段 {} 越界", stage))?;

        let cards: Vec<PickCard> = stage_cards
            .iter()
            .filter_map(|c| {
                let chess = chess_map.get(&c.id)?;
                Some(PickCard {
                    chess_id: chess.chess_id.clone(),
                    name: chess.display_name.clone(),
                    price: chess.price_u8(),
                    is_new: c.is_new,
                    image: format!("{}{}.png", HERO_IMG_BASE, chess.chess_id),
                })
            })
            .collect();
        Ok(cards)
    }

    // ---------- 内部辅助 ----------

    async fn fetch_json<T: DeserializeOwned>(&self, url: &str) -> Result<T> {
        let resp = self
            .client
            .get(url)
            .header("referer", "https://lol.qq.com/")
            .send()
            .await?
            .error_for_status()?;
        Ok(resp.json().await?)
    }

    /// 抓取 URL 文本（用于 tft-mode-registry.js 等 JS 资源，非 JSON）
    async fn fetch_text(&self, url: &str) -> Result<String> {
        let resp = self
            .client
            .get(url)
            .header("referer", "https://lol.qq.com/")
            .send()
            .await?
            .error_for_status()?;
        Ok(resp.text().await?)
    }

    fn populate_cache(
        &self,
        meta: CacheMeta,
        chess: Vec<Chess>,
        lineups: Vec<Lineup>,
    ) -> Result<VersionInfo> {
        let chess_count = chess.len();
        let map: HashMap<String, Chess> = chess.iter().map(|c| (c.chess_id.clone(), c.clone())).collect();

        let info = VersionInfo {
            version: meta.version,
            season: meta.season,
            season_name: meta.season_name,
            vkey: meta.vkey,
            chess_count,
        };

        *self.version_info.write().unwrap() = Some(Arc::new(info.clone()));
        *self.chess_list.write().unwrap() = Some(Arc::new(chess));
        *self.chess_map.write().unwrap() = Some(Arc::new(map));
        *self.lineups.write().unwrap() = Some(Arc::new(lineups));
        Ok(info)
    }

    fn meta_path(&self) -> PathBuf {
        self.cache_dir.join("meta.json")
    }
    fn chess_path(&self) -> PathBuf {
        self.cache_dir.join("chess.json")
    }
    fn lineups_path(&self) -> PathBuf {
        self.cache_dir.join("lineups.json")
    }

    fn load_meta(&self) -> Option<CacheMeta> {
        read_json(&self.meta_path())
    }
    fn load_chess_cache(&self) -> Option<Vec<Chess>> {
        read_json(&self.chess_path())
    }
    fn load_lineups_cache(&self) -> Option<Vec<Lineup>> {
        read_json(&self.lineups_path())
    }

    fn save_meta(&self, meta: &CacheMeta) -> Result<()> {
        self.save_json("meta.json", meta)
    }
    fn save_json<T: serde::Serialize>(&self, name: &str, val: &T) -> Result<()> {
        let path = self.cache_dir.join(name);
        let bytes = serde_json::to_vec(val)?;
        fs::write(&path, bytes)?;
        Ok(())
    }
}

fn read_json<T: DeserializeOwned>(path: &Path) -> Option<T> {
    let bytes = fs::read(path).ok()?;
    serde_json::from_slice(&bytes).ok()
}

/// 解析阵容 detail 字段。
/// 恭喜发财等模式的数据可能含裸控制字符（U+0000~U+001F），
/// serde_json 默认拒绝，故先尝试直接解析，失败则清理所有控制字符后重试。
/// 注意：\t \n \r 在 JSON 字符串值内同样非法，需一并清除。
fn parse_detail(s: &str) -> Result<LineupDetail> {
    serde_json::from_str(s).or_else(|_| {
        let clean: String = s
            .chars()
            .filter(|c| {
                let n = *c as u32;
                n >= 0x20 && n != 0x7f
            })
            .collect();
        serde_json::from_str(&clean).context("解析阵容 detail 失败")
    })
}

/// 解析主网站 tft-mode-registry.js 文本，提取当前活跃模式注册表。
/// 纯函数（无 IO），便于单元测试。
///
/// 该 JS 文件结构：
///   window.CurrentSet = 's17';
///   window.TFTModeConfig = [
///     { id:'1', name:"星神", season:'s17', isRGM:false, queueId:'1100',
///       lineupListUrl:'//...?v=' + (Date.now()...), ... },
///     // { ... 被注释的过期模式 ... },
///     { id:'5', name:"恭喜发财 英雄联盟传奇", season:'s16m17', isRGM:true, ... },
///   ];
///
/// 解析策略：
/// 1. 正则提取 CurrentSet
/// 2. 定位 TFTModeConfig 区域（到下一个 window.TFTModeHelper）
/// 3. 去掉以 `//` 开头的注释行（排除被注释的过期模式块）
/// 4. 正则匹配每个对象块 `{ ... }`（对象内无嵌套 {}）
/// 5. 每块提取 name/season/isRGM/queueId/lineupListUrl 字段
fn parse_mode_registry(text: &str) -> Result<CurrentModeInfo> {
    let current_set = Regex::new(r"window\.CurrentSet\s*=\s*'([^']+)'")
        .unwrap()
        .captures(text)
        .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
        .unwrap_or_default();

    // 定位 TFTModeConfig 数组区域（到下一个 window.TFTModeHelper 为止）
    let start = text
        .find("window.TFTModeConfig")
        .ok_or_else(|| anyhow!("未找到 TFTModeConfig"))?;
    let region = &text[start..];
    let end = region
        .find("window.TFTModeHelper")
        .unwrap_or(region.len());
    let config_region = &region[..end];

    // 去掉以 // 开头的注释行（过期模式整块被注释，每行都以 // 开头）
    let cleaned: String = config_region
        .lines()
        .filter(|line| !line.trim_start().starts_with("//"))
        .collect::<Vec<_>>()
        .join("\n");

    // 匹配每个对象块（对象内无嵌套 {}；extraDataLoaders 数组里的函数调用也无 {}）
    let obj_re = Regex::new(r"\{[^{}]*\}")?;
    let mut modes = Vec::new();
    for caps in obj_re.captures_iter(&cleaned) {
        let obj = caps.get(0).unwrap().as_str();
        let name = extract_str_field(obj, "name");
        let season = extract_str_field(obj, "season");
        if name.is_empty() || season.is_empty() {
            continue;
        }
        modes.push(GameMode {
            name,
            season,
            is_rgm: extract_bool_field(obj, "isRGM"),
            queue_id: extract_str_field(obj, "queueId"),
            lineup_url: normalize_lineup_url(&extract_str_field(obj, "lineupListUrl")),
        });
    }

    Ok(CurrentModeInfo { current_set, modes })
}

/// 从 JS 对象文本提取字符串字段值（支持单/双引号）：name:"星神" / season:'s17'
/// 用 \b 词边界避免误匹配（如 season 不匹配 idSeason）
fn extract_str_field(obj: &str, field: &str) -> String {
    let pattern = format!(r#"\b{}\s*:\s*['"]([^'"]*)['"]"#, regex::escape(field));
    Regex::new(&pattern)
        .ok()
        .and_then(|re| re.captures(obj))
        .and_then(|c| c.get(1).map(|m| m.as_str().to_string()))
        .unwrap_or_default()
}

/// 从 JS 对象文本提取布尔字段值：isRGM:true / isRGM:false
fn extract_bool_field(obj: &str, field: &str) -> bool {
    let pattern = format!(r"\b{}\s*:\s*(true|false)", regex::escape(field));
    Regex::new(&pattern)
        .ok()
        .and_then(|re| re.captures(obj))
        .and_then(|c| c.get(1).map(|m| m.as_str()))
        == Some("true")
}

/// 清理 registry 的 lineupListUrl：去时间戳后缀 + 补全协议。
/// 输入形如 "//game.gtimg.cn/.../lineup_detail_total.json?v=" 或 "https://..."
fn normalize_lineup_url(raw: &str) -> String {
    let trimmed = raw.trim_end_matches("?v=").trim_end_matches('?');
    if trimmed.starts_with("//") {
        format!("https:{}", trimmed)
    } else {
        trimmed.to_string()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    /// 解析主网站 tft-mode-registry.js 文本（纯函数，无网络）。
    /// 样本结构对齐真实文件：CurrentSet + TFTModeConfig 数组（含被注释的过期模式 + 两个活跃模式），
    /// 一个 lineupListUrl 用 // 开头，一个用 https:// 开头，extraDataLoaders 用 [ fn() ] 无嵌套 {}。
    #[test]
    fn parse_mode_registry_works() {
        let sample = r#"
(function (window) {
  window.CurrentSet = 's17';
  window.TFTModeConfig = [
    {
      id: '1',
      name: "星神",
      season: 's17',
      isRGM: false,
      queueId: '1100',
      lineupListUrl: '//game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/6/lineup_detail_total.json?v=' + (Date.now() / 180000 >> 0),
      extraDataLoaders: [
        createBlessLoader('s17')
      ]
    },
    // {
    //   id: '13',
    //   name: "天下无双格斗大赛",
    //   season: 's15m17',
    //   isRGM: true,
    //   queueId: '6100',
    //   lineupListUrl: '//game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/6/6100/lineup_detail_total.json?v=' + (Date.now() / 180000 >> 0),
    // },
    {
      id: '5',
      name: "恭喜发财 英雄联盟传奇",
      season: 's16m17',
      isRGM: true,
      queueId: '1210',
      lineupListUrl: 'https://game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/6/1210/lineup_detail_total.json?v=' + (Date.now() / 180000 >> 0),
      extraDataLoaders: [
        createTaskLoader('s16m17')
      ]
    },
  ];
  window.TFTModeHelper = { getModeList: function () { return window.TFTModeConfig; } };
})(window);
"#;
        let info = parse_mode_registry(sample).expect("解析注册表失败");

        assert_eq!(info.current_set, "s17");
        // 被注释的 s15m17 必须被排除，只剩 2 个活跃模式
        assert_eq!(info.modes.len(), 2, "活跃模式应为 2 个，实际 {:?}", info.modes);

        let starshen = info.modes.iter().find(|m| m.season == "s17").expect("缺星神");
        assert_eq!(starshen.name, "星神");
        assert!(!starshen.is_rgm);
        assert_eq!(starshen.queue_id, "1100");
        assert_eq!(
            starshen.lineup_url,
            "https://game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/6/lineup_detail_total.json"
        );

        let gongxi = info.modes.iter().find(|m| m.season == "s16m17").expect("缺恭喜发财");
        assert_eq!(gongxi.name, "恭喜发财 英雄联盟传奇");
        assert!(gongxi.is_rgm);
        assert_eq!(gongxi.queue_id, "1210");
        assert_eq!(
            gongxi.lineup_url,
            "https://game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/6/1210/lineup_detail_total.json"
        );

        // 被注释的过期模式不应出现
        assert!(info.modes.iter().all(|m| m.season != "s15m17"), "注释块未被过滤");
    }

    /// lineupListUrl 清理：去 ?v= 时间戳后缀 + 补全 https 协议
    #[test]
    fn normalize_lineup_url_works() {
        assert_eq!(
            normalize_lineup_url("//game.gtimg.cn/x/lineup.json?v="),
            "https://game.gtimg.cn/x/lineup.json"
        );
        assert_eq!(
            normalize_lineup_url("https://game.gtimg.cn/x/lineup.json?v="),
            "https://game.gtimg.cn/x/lineup.json"
        );
        // 已无后缀的 URL 原样返回（仅补协议）
        assert_eq!(
            normalize_lineup_url("//game.gtimg.cn/x/lineup.json"),
            "https://game.gtimg.cn/x/lineup.json"
        );
    }

    /// 实跑数据层：拉 versionconfig + chess + lineup，验证解析与拿牌清单
    #[tokio::test]
    async fn refresh_and_pick_works() {
        let dir = std::env::temp_dir().join("tft_autopick_test");
        let _ = std::fs::remove_dir_all(&dir);
        let provider = DataProvider::new(dir).unwrap();

        let info = provider.refresh().await.expect("refresh 失败");
        assert!(!info.version.is_empty(), "version 不能为空");
        assert!(!info.season.is_empty(), "season 不能为空");
        assert!(info.chess_count > 50, "英雄数量应 > 50，实际 {}", info.chess_count);

        let lineups = provider.get_lineups().expect("get_lineups 失败");
        assert!(!lineups.is_empty(), "应有阵容数据");

        // 取第一个阵容的阶段 0 拿牌清单
        let first = &lineups[0];
        let picks = provider
            .get_pick_list(&first.id, 0)
            .expect("get_pick_list 失败");
        println!(
            "版本={} 赛季={} 英雄={} 阵容数={} 首阵容[{}]阶段0拿牌={}",
            info.version, info.season, info.chess_count, lineups.len(), first.line_name,
            picks.iter().map(|c| c.name.clone()).collect::<Vec<_>>().join(",")
        );
        assert!(!picks.is_empty(), "阶段0拿牌清单不能为空");
    }

    /// 恭喜发财模式：验证阵容 URL 切换 + detail 控制字符清理 + chessId 匹配
    #[tokio::test]
    async fn gongxi_mode_pick_works() {
        let dir = std::env::temp_dir().join("tft_autopick_test_gongxi");
        let _ = std::fs::remove_dir_all(&dir);
        let provider = DataProvider::new(dir).unwrap();
        provider.set_target_season(MODE_GONGXI);

        let info = provider.refresh().await.expect("恭喜发财 refresh 失败");
        assert!(info.chess_count > 50, "恭喜发财英雄数量应 > 50，实际 {}", info.chess_count);

        let lineups = provider.get_lineups().expect("恭喜发财 get_lineups 失败");
        assert!(!lineups.is_empty(), "恭喜发财应有阵容数据，实际 {} 个", lineups.len());

        let first = &lineups[0];
        let picks = provider
            .get_pick_list(&first.id, 0)
            .expect("恭喜发财 get_pick_list 失败");
        println!(
            "恭喜发财: 版本={} 赛季={} 英雄={} 阵容数={} 首阵容[{}]阶段0拿牌={}",
            info.version, info.season, info.chess_count, lineups.len(), first.line_name,
            picks.iter().map(|c| c.name.clone()).collect::<Vec<_>>().join(",")
        );
        assert!(!picks.is_empty(), "恭喜发财阶段0拿牌清单不能为空");
    }
}
