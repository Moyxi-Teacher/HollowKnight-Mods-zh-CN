# TFT 拿牌助手

> A TFT (Teamfight Tactics) assistant with local OCR/YOLO/Image-match inference - Tauri 2 + Vue 3 + Rust.

一个基于 Tauri 2 + Vue 3 + Rust 的《云顶之弈》（TFT）辅助工具，提供商店卡牌自动识别拿牌、一键卖出、阵容推荐等功能。OCR、目标检测与图像匹配均在**本地**用 ONNX Runtime 推理，不联网上传画面，不修改游戏内存。

## 功能特性

- **双模式识别（OCR + 找图）**：同时运行 PaddleOCR 文字识别与 HSV 颜色直方图图像匹配，按融合策略取最优结果，互补提升准确率。
- **拿牌检测**：框选商店 5 张卡牌区域，按热键自动截屏 -> OCR + 找图并发识别 -> 融合匹配目标英雄 -> 模拟鼠标点击拿牌。
- **自动循环模式**：开启后以 200ms 间隔循环检测商店，配合双路 aHash 变化检测（名字区 + 卡牌区独立），商店未刷新时跳过识别，省 CPU。
- **一键卖出**：框选棋盘英雄区域 -> YOLO 识别英雄血条定位 -> 鼠标依次移到英雄位置按 E 卖出。
- **阵容推荐**：从官方接口拉取当前赛季阵容，按英雄筛选包含该英雄的后期阵容。
- **模式自适应**：从主网站 `tft-mode-registry.js` 解析当前活跃模式（星神 / 恭喜发财等），随版本自动更新，无需改代码。
- **游戏内热键**：用 Windows 低级键盘钩子（WH_KEYBOARD_LL）注册全局热键，在游戏全屏窗口内也能触发。
- **多窗口透明置顶**：主窗口 + 各功能弹窗均为独立无边框透明 Tauri 窗口，可叠加在游戏上。
- **实时识别显示**：主窗口底部状态栏实时显示 5 张卡的识别结果（英雄名用 `|` 隔开），便于观察识别准确度。

## 技术栈

**前端**：Vue 3.5 + TypeScript + Vite 5 + @tauri-apps/api 2

**后端（Rust）**：

- Tauri 2.11（应用框架）
- paddle-ocr-rs 0.6.1 + ort 2.0.0-rc.10（PaddleOCR PP-OCRv5 rec 模型 ONNX 推理，仅 rec 跳过 det/cls）
- ort + ONNX Runtime（YOLO 血条检测）
- rayon（HSV 直方图匹配多线程并行）
- xcap（截屏）、enigo（模拟鼠标键盘）、image / imageproc（图像预处理）
- windows-sys（WH_KEYBOARD_LL 低级键盘钩子）
- reqwest + regex（抓取并解析主网站模式注册表 + 下载卡牌原图模板）

## 识别策略

### 双模式融合

OCR 与找图同时运行，按以下规则融合结果：

| 情况 | 规则 | 理由 |
|------|------|------|
| 商店变了但 OCR 没认出英雄 | 不信任找图 | OCR 对真实卡牌识别率 >90%，没认出 = 很可能是空背景 |
| 两种都过阈值，结果相同 | 用任一 | 两种方式一致，可信度高 |
| 两种都过阈值，结果相近（编辑距离 ≤1） | 找图优先 | OCR 看错字时找图常能认对（如凯尔→凯隐） |
| 两种都过阈值，结果差异大（编辑距离 ≥2） | OCR 优先 | 找图错配时 OCR 文字唯一性更可靠（如慎 vs 嘉文四世） |
| 只 OCR 过阈值 | 用 OCR | 找图未命中 |
| 只找图过阈值 | 用找图 | OCR 未跑（商店未变化用缓存）或 OCR 无数据 |
| 都没过 | 不点 | 无命中 |

### OCR 匹配

- PaddleOCR PP-OCRv5 rec 模型，3 种预处理变体（Otsu 二值化 / 自适应阈值 / 反转+对比度拉伸）择优
- 字符级 mask 约束：只允许识别当前赛季英雄名用字，从根源杜绝无关字符
- 匹配规则：完全匹配 1.0 / 多字匹配 0.95 / 少字匹配 0.85（仅 OCR 文本长度 ≥3 时允许，防止单字噪声误匹配）
- 阈值 0.8

### 找图匹配（HSV 颜色直方图）

- 模板来源：官网 624×318 卡牌原图，取距右15、距上50的 80×80 方块
- 算法：RGB→HSV→量化到 128 bin 直方图（H8×S4×V4）→ L1 归一化 → 巴氏系数匹配
- 空区域检测：亮度方差 std < 30 视为空背景（卡牌被买后），直接返回 None
- 测试时步进搜索 Y 轴偏移 dy∈[-5,5]，记录最佳偏移并持久化，正式匹配直接用
- 阈值 0.8

### 性能优化

- **截屏共享**：`capture_both` 一次截屏同时做 OCR + 找图，省 1 次截屏且保证同帧结果
- **aHash 变化检测**：双路独立缓存（名字区 + 卡牌区），商店未变化时跳过识别
- **无延时点击**：多卡间不等待，click_position 内部 sleep 仅 5ms
- **循环间隔 200ms**：商店未变化时 aHash 跳过，CPU 极低
- **耗时日志**：控制台输出 `[capture_both] 截屏/OCR/找图/总计` 耗时

## 架构

```
src/                      前端（Vue）
├── windows/
│   ├── Main.vue          主窗口：模式选择 / 拿牌区 / 状态栏 / 自动循环
│   ├── Settings.vue      设置：透明度 / 名字区域+卡牌区域框选 / 测试匹配 / 热键录制
│   ├── Lineup.vue        阵容推荐 + 按英雄搜索
│   ├── Hero.vue          英雄选择（按费用分组）
│   └── RegionPicker.vue  全屏蒙版 + 十字光标框选
├── lib/shared.ts         窗口管理 / 事件收发 / 设置持久化
└── types.ts              与 Rust 端对应的 TS 类型

src-tauri/src/            后端（Rust）
├── lib.rs                Tauri 命令注册 / 引擎初始化
├── pick_engine.rs        拿牌引擎：截屏 / aHash 变化检测 / capture_both / 模拟点击 / 卖出
├── image_match.rs        HSV 颜色直方图匹配引擎（模板加载 / 巴氏系数 / 空区域检测 / 偏移搜索）
├── ocr.rs                PaddleOCR rec 引擎（多变体预处理 + 字符约束 + batch 推理）
├── yolo.rs               YOLO 血条检测引擎（letterbox + NMS）
├── hotkey.rs             WH_KEYBOARD_LL 全局热键监听
├── provider.rs           主网站模式注册表抓取与解析
└── models.rs             serde 数据模型
```

## 环境要求

- Windows 10/11（依赖 WH_KEYBOARD_LL、xcap 截屏，暂不支持 macOS / Linux）
- Node.js 18+
- Rust 1.77.2+（推荐 rustup 最新 stable）
- WebView2 Runtime（Windows 11 自带；Windows 10 需安装）

## 安装与构建

### 1. 克隆并安装前端依赖

```bash
git clone https://github.com/iWorkers/TFT_auto_pick.git
cd TFT_auto_pick
npm install
```

### 2. 准备资源文件（重要）

资源文件（ONNX Runtime dll + 模型）**不随源码分发**，需自行放入 `src-tauri/resources/`：

```
src-tauri/resources/
├── onnxruntime.dll                          # ONNX Runtime（CPU build）
└── models/
    ├── ch_PP-OCRv5_rec_mobile_infer.onnx    # PaddleOCR PP-OCRv5 rec mobile 模型
    └── yolo.onnx                            # 自训练 YOLO 血条检测模型
```

- **onnxruntime.dll**：从 [ONNX Runtime Releases](https://github.com/microsoft/onnxruntime/releases) 下载 Windows x64 **CPU** 包（onnxruntime-win-x64-*.zip），取其中的 `onnxruntime.dll`。版本需与 `ort = 2.0.0-rc.10` 兼容（ONNX Runtime 1.22.x）。务必用 CPU build，不要 DirectML build。
- **ch_PP-OCRv5_rec_mobile_infer.onnx**：从 [PaddleOCR 模型库](https://paddlepaddle.org.cn/models) 下载 PP-OCRv5 rec mobile 推理模型（ONNX 格式）。字典从模型 metadata 的 character 字段读取，无需外部字典文件。
- **yolo.onnx**：自行训练的英雄血条检测模型。导出为 YOLOv8n ONNX，输入 640×640，单类（血条）。若输入尺寸 / 类别数不同，改 `src-tauri/src/yolo.rs` 顶部的 `INPUT_SIZE` / `NUM_CLASSES` 常量。

详见 [`src-tauri/resources/README.md`](src-tauri/resources/README.md)。

### 3. 开发运行 / 发布构建

```bash
# 开发（热重载）
npm run tauri dev

# 发布构建（生成 exe）
npm run tauri build
```

> ⚠️ **发布必须用 `npm run tauri build`，不要用裸 `cargo build --release`**：Tauri CLI 会注入 `TAURI_ENV_*` 环境变量让 `generate_context!` 把前端嵌入 exe；裸 cargo build 缺这些变量会走 dev 模式加载 localhost，导致空白窗口。

构建产物：`src-tauri/target/release/tft-auto-pick.exe`（运行时需把 `resources/` 目录放在 exe 同级；`tauri build` 完整打包会自动复制，`--no-bundle` 需手动复制）。

## 使用说明

1. 启动后主窗口置顶显示。先到「设置」依次框选：
   - **卡牌名字区域**（5 个，OCR 用，框选卡牌底部的英雄名字）
   - **卡牌整体区域**（5 个，找图用，框选整张卡含头像+名字+费用）
2. 点击「测试匹配」验证找图识别效果。测试时自动步进搜索最佳 Y 轴偏移并保存，正式匹配直接用。
3. 在「选择英雄」里挑选要拿的英雄加入拿牌区。
4. **手动模式**：按动作热键（默认 `Space`）= 刷新商店 + 检测一次，命中目标自动拿牌。
5. **自动模式**：按自动热键开启循环检测（200ms 间隔），再按关闭。主窗口底部实时显示识别结果。
6. **一键卖出**：按卖出热键（默认 `Ctrl+Space`）-> 框选棋盘英雄区域 -> 自动识别血条并依次卖出。

所有热键可在设置里录制，用 WH_KEYBOARD_LL 钩子，游戏全屏内也能触发。

## YOLO 模型训练说明

一键卖出的血条检测依赖自训练 YOLO 模型，本项目不含模型文件。训练要点：

- 数据：在游戏内截图棋盘英雄区域，标注英雄血条（单类）。
- 模型：YOLOv8n（最轻量），导出 ONNX，输入 640×640。
- 后处理：代码按 YOLOv8 标准导出格式（`[1, 4+nc, anchors]` 或 `[1, anchors, 4+nc]`），兼容两种布局；置信度阈值 0.25，NMS IoU 0.45。
- 导出后命名为 `yolo.onnx` 放入 `src-tauri/resources/models/`。

## 免责声明

- 本项目仅供**学习交流与技术研究**，不得用于商业用途。
- 使用本工具可能违反《英雄联盟》/《云顶之弈》的用户协议，存在账号封禁风险，使用者自行承担一切后果。
- 本项目与 Riot Games、腾讯无关，不接受其任何形式的授权或背书。
- 请遵守当地法律法规，合理使用。

## License

MIT
