# 游戏内白色文字（深色背景）OCR 预处理指南

> 适用场景：游戏 UI / 字幕 / 提示文字为**白色或浅色**，背景为深色。  
> 目标：提升 PaddleOCR（PP-OCRv5 / v6）在游戏截图上的识别准确率。

---

## 1. 推荐预处理流水线

按优先级从高到低执行：

```
1. 裁剪目标区域（强烈建议，不要整屏）
2. 放大 2～3 倍（小字必做）
3. 转灰度
4. 反色（白字 → 黑字）          ← 关键步骤
5. CLAHE 对比度增强
6. （可选）轻微锐化 / 去噪
7. （可选）二值化（Otsu 或自适应阈值）
```

### 为什么要反色？

PaddleOCR 训练数据以**黑字白底**为主。  
将白字反转为黑字后，模型通常更稳定，尤其对带抗锯齿、轻微发光的白色文字效果更好。  
（v5/v6 对白字也能处理，但反色后正确率普遍再高一点。）

---

## 2. 参数经验值

| 步骤           | 推荐值              | 说明 |
|----------------|---------------------|------|
| 放大倍数       | 2.0 ~ 3.0           | 字高 < 18px 建议 ≥ 2.5 |
| 反色           | 必做                | 255 - pixel |
| CLAHE clipLimit| 1.5 ~ 2.5           | 太高会放大噪点 |
| 二值化         | Otsu 或自适应       | 背景干净用 Otsu，背景复杂用自适应 |
| 锐化           | 轻度                | 过度锐化会让抗锯齿变成噪点 |

---

## 3. Rust 实现示例

依赖建议：

```toml
[dependencies]
image = "0.25"
imageproc = "0.25"
```

### 3.1 基础版（推荐先从这个开始）

```rust
use image::{DynamicImage, GrayImage, imageops, Luma};
use imageproc::contrast;

/// 白色文字 + 深色背景预处理
/// scale: 放大倍数，建议 2.0 ~ 3.0
fn preprocess_white_on_dark(img: &DynamicImage, scale: f32) -> GrayImage {
    // 1. 转灰度
    let mut gray = img.to_luma8();

    // 2. 放大
    if scale > 1.0 {
        let (w, h) = gray.dimensions();
        let nw = ((w as f32) * scale) as u32;
        let nh = ((h as f32) * scale) as u32;
        gray = imageops::resize(&gray, nw, nh, imageops::FilterType::Lanczos3);
    }

    // 3. 反色：白字 → 黑字
    for pixel in gray.pixels_mut() {
        pixel.0[0] = 255 - pixel.0[0];
    }

    // 4. 简单对比度拉伸（替代 CLAHE，简单有效）
    // 可把 10/245 调成更激进的值
    contrast::stretch_contrast(&mut gray, 10, 245);

    gray
}
```

### 3.2 进阶版（加二值化）

```rust
use imageproc::contrast::{otsu_threshold, threshold};

fn preprocess_with_binarize(img: &DynamicImage, scale: f32) -> GrayImage {
    let mut gray = preprocess_white_on_dark(img, scale);

    // Otsu 自动阈值（背景较干净时效果好）
    let thresh = otsu_threshold(&gray);
    threshold(&mut gray, thresh);

    // 或者固定阈值：
    // threshold(&mut gray, 128);

    gray
}
```

### 3.3 自适应阈值（背景不均匀时更好）

```rust
use imageproc::contrast::adaptive_threshold;

fn preprocess_adaptive(img: &DynamicImage, scale: f32) -> GrayImage {
    let gray = preprocess_white_on_dark(img, scale);

    // block_radius 建议 7~21，根据文字大小调整
    adaptive_threshold(&gray, 11)
}
```

---

## 4. 实操测试顺序（建议按此顺序验证）

1. **只做「裁剪 + 放大 2 倍 + 反色」**  
   → 直接喂给 PaddleOCR，观察提升幅度。

2. 如果仍有明显错误 → 加入 **对比度拉伸 / CLAHE**。

3. 还有粘连或噪点 → 尝试 **Otsu 二值化**。

4. 背景复杂、局部亮度不均 → 换 **自适应阈值**。

5. 最后才考虑锐化或去噪（容易引入新问题）。

---

## 5. 额外实用技巧

- **固定 UI 区域**：按坐标裁剪，跳过检测模型，只做识别。准确率和速度都会明显提升。
- **多帧投票**：实时场景连续识别 3～5 帧，取出现次数最多的结果。
- **发光 / 描边文字**：反色后有时**不要**二值化，直接灰度效果更好（发光会被当成文字一部分）。
- **小字优先放大**：字高低于 16～18 像素时，放大带来的收益通常大于任何其他预处理。

---

## 6. 与 PaddleOCR 配合建议

- 优先使用 **PP-OCRv6 medium**（或至少 small）。
- 固定区域场景可只用 recognition 模型，跳过 detection。
- 适当降低 `drop_score`（如 0.4～0.5），避免把正确但置信度偏低的结果丢掉。
- 检测参数可尝试：
  - `det_db_thresh`: 0.2 ~ 0.3
  - `det_db_box_thresh`: 0.4 ~ 0.5
  - `det_db_unclip_ratio`: 1.6 ~ 2.0

---

## 7. 常见问题排查

| 现象               | 可能原因               | 建议 |
|--------------------|------------------------|------|
| 漏字 / 框不全      | 检测阈值过高、文字太小 | 放大 + 降低 det 阈值 |
| 错字（形近字）     | 抗锯齿 / 对比度不足    | 反色 + CLAHE + 放大 |
| 多字 / 噪点当字    | 二值化过度 / 背景复杂  | 去掉二值化或改用自适应 |
| 边缘字符被切       | unclip_ratio 太小      | 增大 unclip_ratio |
| 实时卡顿           | 整屏识别 + 大模型      | 固定区域裁剪 + 只用 recognition |

---

*文档版本：2026-07-25*  
*适用：Rust + PaddleOCR（ocr-rs / oar-ocr 等）*
