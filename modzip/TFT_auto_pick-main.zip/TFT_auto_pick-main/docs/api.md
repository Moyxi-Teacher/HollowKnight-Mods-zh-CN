# 云顶之弈官方数据接口文档

> 数据来源：`https://lol.qq.com/tft/#/index`
> 抓取时间：2026-07-22
> 当前赛季：Set17 星神 / Ver 16.14

所有接口均在腾讯 CDN 上，**无需鉴权**，响应头 `access-control-allow-origin: *`，Rust 端用 `reqwest` 直接 GET 即可。响应多为 JS 文件（本质是 JSON），`content-type: application/x-javascript`。

---

## 一、接口总览

| 数据 | 接口 | 说明 |
|------|------|------|
| 版本配置(总入口) | `https://lol.qq.com/zmtftzone/public-lib/versionconfig.json` | 返回当前赛季所有数据 URL，必须先拉它 |
| 版本列表 | `https://mlol.qt.qq.com/go/database/versionlist?zone=lol&from=h5&v={ts}` | 版本号比对，判断是否需更新缓存 |
| 英雄(棋子) | versionconfig.urlChessData | 如 `.../tft/js/16.14-2026.S17-1210/chess-1210.js` |
| 特质(羁绊) | versionconfig.urlRaceData | `race-1210.js` |
| 职业(羁绊) | versionconfig.urlJobData | `job-1210.js` |
| 装备 | versionconfig.urlEquipData | `equip-1210.js` |
| 强化海克斯 | versionconfig.urlBuffData | `hex-1210.js` |
| 英雄任务 | versionconfig.urlTaskData | `ChampionTask.js` |
| 阵容推荐 | `https://game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/6/lineup_detail_total.json?v={ts}` | 拿牌推荐核心数据 |

### 版本化路径规律

`{版本号}-{赛季}-{modeId}/{type}-{modeId}.js`，例如 `16.14-2026.S17-1210/chess-1210.js`。

- 版本号：`16.14`
- 赛季：`2026.S17`
- modeId：`1210`（常规排位模式）

赛季更新后该路径会变，**必须先拉 versionconfig 动态取 URL，不能写死**。

---

## 二、关键字段结构

### 1. versionconfig.json（总入口）

```json
[
  {
    "booleanPreVersion": false,
    "arrVersionLimit": ["16.14"],
    "stringName": "Set16恭喜发财",
    "idSeason": "s16m17",
    "urlChessData": "https://game.gtimg.cn/images/lol/act/img/tft/js/16.14-2026.S17-1210/chess-1210.js",
    "urlRaceData": "https://game.gtimg.cn/images/lol/act/img/tft/js/16.14-2026.S17-1210/race-1210.js",
    "urlJobData": "https://game.gtimg.cn/images/lol/act/img/tft/js/16.14-2026.S17-1210/job-1210.js",
    "urlEquipData": "https://game.gtimg.cn/images/lol/act/img/tft/js/16.14-2026.S17-1210/equip-1210.js",
    "urlBuffData": "https://game.gtimg.cn/images/lol/act/img/tft/js/16.14-2026.S17-1210/hex-1210.js",
    "urlTaskData": "https://game.gtimg.cn/images/lol/act/img/tft/ChampionTask/ChampionTask.js"
  }
]
```

返回数组，每个元素代表一个可用赛季/模式。`arrVersionLimit` 是版本号，`idSeason` 形如 `s{set}m{mode}`。实际使用取第一个（当前赛季）。

### 2. versionlist（版本列表）

```json
{
  "baton": 0, "code": 0,
  "data": [
    {"id":"223","name":"16.14","vkey":"20260716","title":"16.14版本","public_date":"2026-07-16","key":"lol_20260716_223"},
    {"id":"222","name":"16.13","vkey":"20260625","title":"16.13版本","public_date":"2026-06-25","key":"lol_20260625_222"}
  ]
}
```

用 `vkey`（如 `20260716`）做版本指纹，与本地缓存比对，决定是否拉新数据。

### 3. chess（英雄/棋子）

```json
{
  "version":"16.14","season":"2026.S17","modeId":"1210","time":"2026-07-21 17:10:00",
  "data":[
    {
      "chessId":"100006",
      "displayName":"崔丝塔娜",
      "TFTID":"100006",
      "hero_EN_name":"TFT16_Tristana",
      "price":"2",                       // 费用 1-5
      "raceIds":"10263",                 // 特质ID，逗号分隔（可多个）
      "jobIds":"10231",                  // 职业ID，逗号分隔（可多个）
      "races":"...",                     // 特质名称
      "jobs":"...",                      // 职业名称
      "skillName":"毁灭射击",
      "skillType":"主动",
      "skillImage":"https://.../xxx.png",
      "skillIntroduce":"...",
      "skillDetail":"...",
      "life":"..","magic":"..","armor":"..","spellBlock":"..",
      "attack":"..","attackSpeed":"..","attackRange":"..",
      "crit":"..","crit_damage":"..",
      "attackData":"70/105/158",         // 1/2/3星攻击成长
      "lifeData":"..",                   // 1/2/3星生命成长
      "originalImage":"https://game.gtimg.cn/.../xxx.png",   // ★ 棋子原画，模板匹配关键图
      "recEquip":"92556,92577",          // 推荐装备ID
      "proStatus":"无",
      "id":"33163"
    }
  ]
}
```

> 注意：前几条 `chessId` 以 `100000~100005` 开头的是道具/锻造器（如"纹总之书""成装锻造器"），非英雄，`raceIds`/`jobIds` 为空，需过滤。

### 4. race（特质羁绊）

```json
{
  "raceId":"10267",
  "name":"暗裔剑魔",
  "traitId":"10267",
  "introduce":"【亚托克斯】获得相当于其200%全能吸血的物理加成...",
  "alias":"10267.png",
  "level": { "1":"...", "2":"...", "3":"..." }    // 各档位羁绊效果
}
```

### 5. job（职业羁绊）

结构同 race：`jobId` / `name` / `traitId` / `introduce` / `level`。

### 6. equip（装备）、hex（强化海克斯）

待补充字段（接口已确认存在，结构需进一步抓取）。

### 7. lineup（阵容推荐 —— 拿牌助手核心）

接口：`https://game.gtimg.cn/images/lol/act/tftzlkauto/json/lineupJson/s17/{n}/lineup_detail_total.json?v={ts}`

外层结构：

```json
{
  "lineup_list": [
    {
      "id":"14127",
      "quality":"SS",                    // 评级 SS/S/A/B/C
      "author":"862",
      "lineupauthor_data": { "name":"公众号小鱼一图流", "imgUrl":"..." },
      "channel":"5,6","status":"5",
      "sortID":"65536",
      "rel_time":"2026-06-25 11:30:35",
      "edition":"289","season":"55","modeId":"1",
      "simulator_edition":"16.13","create_edition":"16.8",
      "simulator_season":"2026.S17",
      "detail": "{...}"                  // ★ 二次嵌套的 JSON 字符串，需再 parse 一次
    }
  ]
}
```

`detail` 解析后的关键字段：

```json
{
  "line_name":"【4重薇古丝95】4重装战士3牧羊人2暗星",
  "needLevel":9, "needLevel_early":6, "needLevel_middle":8,
  "hero_location_l6": [ {hero_location_l6/l8/l9 元素} ],
  "hero_location_l8": [ ... ],
  "hero_location_l9": [ ... ],
  "search_card_rhythm": [                // ★★★ 搜牌节奏，拿牌推荐依据
    [ {"isNew":true,"id":"100244"}, {"isNew":true,"id":"100226"}, ... ],   // 阶段1 早期
    [ {"isNew":false,"id":"100244"}, {"isNew":true,"id":"100203"}, ... ],  // 阶段2 中期
    [ {"isNew":false,"id":"100252"}, {"isNew":true,"id":"100232"}, ... ]   // 阶段3 后期
  ],
  "hexbuff": { "recomm":"94693,94753,94730", "replace":"94809,94832,..." },
  "bless_id_list": [ {"stage":1,"blessIds":["137","100"]}, ... ],
  "hex_info":"拿5费的和经济类的",
  "bless_info":"全选加经验、金币、D牌之类的",
  "early_info":"早期过渡说明",
  "d_time":"8级搜2星努努...",
  "equipment_info":"装备说明",
  "location_info":"站位说明",
  "early_round":"2-3",
  "metaphase_round":"4-3"
}
```

`hero_location_l6/l8/l9` 元素结构：

```json
{
  "chess_type":"hero",          // hero | pet
  "hero_id":"100244",           // chessId
  "equipment_id":"92556,92577,92514",
  "equipment_replace": {"main":"92556,92577","backup":"92514"},
  "location":"1,4",             // 行,列 站位
  "numStar":1,                  // 星级
  "isChosenHero":false,
  "is_goop":false,"is_powerup":false,"is_mecha":false,
  "add_trait_id":"","add_trait_icon":""
}
```

---

## 三、对自动拿牌助手的关键意义

### 1. search_card_rhythm（搜牌节奏）

官方阵容作者标注的搜牌节奏：3 段数组对应早/中/后期，每段列出该阶段该拿的英雄 `chessId`，`isNew` 标记是否本阶段新加入。

这直接驱动自动拿牌推荐逻辑：

1. 玩家选定阵容 → 取其 `search_card_rhythm`
2. 判断当前所处阶段（按轮次/人口）→ 选对应段
3. 该段 `chessId` 列表 = 本阶段"该拿的牌"白名单
4. 截屏识别商店 5 张牌 → 命中白名单则用 `enigo` 模拟点击购买
5. `originalImage` 字段提供每个英雄官方原画 → 用作模板匹配的模板图

### 2. 数据流闭环

```
versionconfig.json
        │ (动态拿URL)
        ▼
chess.js ───────► 英雄表(chessId→名称/费用/原画模板)
        │
lineup_detail_total.json ──► 阵容 + search_card_rhythm(搜牌节奏)
        │
        ▼
   选阵容 → 当前阶段 → 该拿的chessId白名单
        │
        ▼
   截屏识别商店牌 → 命中白名单 → enigo模拟点击购买
```

---

## 四、Rust 数据层设计建议

```rust
use serde::Deserialize;

#[derive(Deserialize)]
struct VersionConfig {
    #[serde(rename = "arrVersionLimit")]
    arr_version_limit: Vec<String>,
    #[serde(rename = "stringName")]
    string_name: String,
    #[serde(rename = "urlChessData")]
    url_chess_data: String,
    #[serde(rename = "urlRaceData")]
    url_race_data: String,
    #[serde(rename = "urlJobData")]
    url_job_data: String,
    #[serde(rename = "urlEquipData")]
    url_equip_data: String,
    #[serde(rename = "urlBuffData")]
    url_buff_data: String,
}

#[derive(Deserialize)]
struct ChessData {
    version: String,
    data: Vec<Chess>,
}

#[derive(Deserialize)]
struct Chess {
    #[serde(rename = "chessId")]
    chess_id: String,
    #[serde(rename = "displayName")]
    display_name: String,
    price: String,
    #[serde(rename = "raceIds")]
    race_ids: String,           // 逗号分隔，解析时 split
    #[serde(rename = "jobIds")]
    job_ids: String,
    #[serde(rename = "originalImage")]
    original_image: String,     // 模板匹配用
}

#[derive(Deserialize)]
struct LineupWrap {
    #[serde(rename = "lineup_list")]
    lineup_list: Vec<Lineup>,
}

#[derive(Deserialize)]
struct Lineup {
    id: String,
    quality: String,
    detail: String,             // 二次 JSON 字符串，parse 后得 LineupDetail
}

#[derive(Deserialize)]
struct LineupDetail {
    #[serde(rename = "line_name")]
    line_name: String,
    #[serde(rename = "search_card_rhythm")]
    search_card_rhythm: Vec<Vec<RhythmCard>>,
    #[serde(rename = "hero_location_l6")]
    hero_location_l6: Vec<HeroLoc>,
    #[serde(rename = "hero_location_l8")]
    hero_location_l8: Vec<HeroLoc>,
    #[serde(rename = "hero_location_l9")]
    hero_location_l9: Vec<HeroLoc>,
}

#[derive(Deserialize)]
struct RhythmCard {
    #[serde(rename = "isNew")]
    is_new: bool,
    id: String,                 // chessId
}

// 数据管理器
struct DataProvider {
    client: reqwest::Client,
    cache: sled::Db,            // 本地缓存
}

impl DataProvider {
    /// 拉版本配置，比对版本号，按需更新
    async fn refresh(&self) -> anyhow::Result<()>;

    /// chessId → 英雄 映射表
    async fn get_chess_map(&self) -> std::collections::HashMap<String, Chess>;

    /// 全部阵容
    async fn get_lineups(&self) -> Vec<Lineup>;

    /// 指定阵容、阶段(0/1/2) → 该拿的 chessId 列表
    fn get_pick_list(&self, lineup_id: &str, stage: usize) -> Vec<String>;
}
```

### 缓存策略

- 用 `versionlist` 的 `vkey`（如 `20260716`）做版本指纹，存入 sled。
- 启动时比对 `vkey`，相同则直接用缓存，不同则重新拉取 versionconfig + 各数据文件。
- 英雄原画模板图下载到本地，按 `chessId` 命名（如 `templates/100006.png`），避免每次识别都联网。

### 注意事项

- `chess.js` 前几条（`chessId` 100000~100005）是道具/锻造器，非英雄，`raceIds`/`jobIds` 为空，需过滤。
- `lineup.detail` 是字符串化的 JSON，需二次 `serde_json::from_str`。
- `raceIds`/`jobIds` 是逗号分隔字符串，解析时 split 并 trim。
- 各接口有 CDN 缓存（`max-age=120`），频繁请求无意义，本地缓存为主。


npm run tauri dev

npm run tauri build