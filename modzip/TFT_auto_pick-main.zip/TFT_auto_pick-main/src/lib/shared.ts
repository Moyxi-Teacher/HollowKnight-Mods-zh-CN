import { emit, listen } from "@tauri-apps/api/event";
import { WebviewWindow } from "@tauri-apps/api/webviewWindow";
import { getCurrentWindow } from "@tauri-apps/api/window";
import {
  DEFAULT_GAME_MODE,
  DEFAULT_SETTINGS,
  type AppSettings,
  type CustomPickItem,
  type GameMode,
  type ShopRegion,
} from "../types";

// ============ 事件名常量 ============
export const EVT_APPLY_PICKS = "apply-picks";
export const EVT_SETTINGS_SAVED = "settings-saved";
export const EVT_REGION_SELECTED = "region-selected";
export const EVT_MODE_CHANGED = "mode-changed";
export const EVT_OPACITY_CHANGED = "opacity-changed";

// ============ 事件收发封装 ============
export const emitApplyPicks = (items: CustomPickItem[]) =>
  emit(EVT_APPLY_PICKS, items);
export const emitSettingsSaved = (s: AppSettings) => emit(EVT_SETTINGS_SAVED, s);
export const emitRegionSelected = (r: ShopRegion) =>
  emit(EVT_REGION_SELECTED, r);
export const emitModeChanged = (m: GameMode) => emit(EVT_MODE_CHANGED, m);
export const emitOpacityChanged = (o: number) => emit(EVT_OPACITY_CHANGED, o);

export function onApplyPicks(cb: (items: CustomPickItem[]) => void) {
  return listen<CustomPickItem[]>(EVT_APPLY_PICKS, (e) => cb(e.payload));
}
export function onSettingsSaved(cb: (s: AppSettings) => void) {
  return listen<AppSettings>(EVT_SETTINGS_SAVED, (e) => cb(e.payload));
}
export function onRegionSelected(cb: (r: ShopRegion) => void) {
  return listen<ShopRegion>(EVT_REGION_SELECTED, (e) => cb(e.payload));
}
export function onModeChanged(cb: (m: GameMode) => void) {
  return listen<GameMode>(EVT_MODE_CHANGED, (e) => cb(e.payload));
}
export function onOpacityChanged(cb: (o: number) => void) {
  return listen<number>(EVT_OPACITY_CHANGED, (e) => cb(e.payload));
}

// ============ 设置持久化 ============
const SETTINGS_KEY = "tft_autopick_settings";
const PICKS_KEY = "tft_autopick_picks";
const MODE_KEY = "tft_autopick_mode";

export function loadSettings(): AppSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (raw) return { ...DEFAULT_SETTINGS, ...JSON.parse(raw) };
  } catch {}
  return { ...DEFAULT_SETTINGS };
}

export function saveSettings(s: AppSettings) {
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(s));
}

export function loadPicks(): CustomPickItem[] {
  try {
    const raw = localStorage.getItem(PICKS_KEY);
    if (raw) return JSON.parse(raw);
  } catch {}
  return [];
}

export function persistPicks(items: CustomPickItem[]) {
  localStorage.setItem(PICKS_KEY, JSON.stringify(items));
}

export function loadMode(): GameMode {
  const raw = localStorage.getItem(MODE_KEY);
  if (raw) {
    try {
      // 新格式：完整 GameMode 对象 JSON
      const obj = JSON.parse(raw) as Partial<GameMode>;
      if (obj && typeof obj.season === "string" && typeof obj.name === "string") {
        return {
          name: obj.name,
          season: obj.season,
          is_rgm: !!obj.is_rgm,
          queue_id: obj.queue_id ?? "",
          lineup_url: obj.lineup_url ?? "",
        };
      }
    } catch {
      // 旧格式（"starshen"/"gongxi" 别名字符串）：迁移到 s17/s16m17 代号
      if (raw === "gongxi") {
        return { ...DEFAULT_GAME_MODE, name: "恭喜发财", season: "s16m17", is_rgm: true };
      }
    }
  }
  return { ...DEFAULT_GAME_MODE };
}

export function persistMode(m: GameMode) {
  localStorage.setItem(MODE_KEY, JSON.stringify(m));
}

// ============ 窗口创建 ============
let counter = 0;

export interface WindowSpec {
  hash: string; // 路由 hash，如 "lineup"
  title: string;
  width: number;
  height: number;
  /// 可选：传给弹窗的提示文案（RegionPicker 用，显示在顶部 tip-bar）
  /// 通过 url query string 传递：index.html#/<hash>?tip=<encoded>
  tip?: string;
}

/**
 * 打开一个独立无边框透明弹窗。
 * label 唯一（带计数器），避免重复创建冲突。
 * 白色闪屏由 index.html 内联样式（html,body 透明）在 HTML 解析期即生效来消除，
 * 不再用「隐藏创建+show」——Tauri2 Windows 透明窗口的 show() 不可靠，会导致蒙版不出现。
 */
export async function openPopup(spec: WindowSpec): Promise<WebviewWindow> {
  const label = `popup-${spec.hash}-${Date.now()}-${counter++}`;
  const url = spec.tip
    ? `index.html#/${spec.hash}?tip=${encodeURIComponent(spec.tip)}`
    : `index.html#/${spec.hash}`;
  const w = new WebviewWindow(label, {
    url,
    title: spec.title,
    width: spec.width,
    height: spec.height,
    decorations: false,
    transparent: true,
    alwaysOnTop: true,
    resizable: true,
    center: true,
    shadow: true,
    // transparent:true 只让原生窗口透明，WebView2 的 DefaultBackgroundColor 默认仍是白色，
    // 会导致 HTML 解析前闪一帧白屏。显式设为透明 RGBA，消除 webview 初始白底闪屏。
    backgroundColor: [0, 0, 0, 0],
  });
  await new Promise<void>((resolve, reject) => {
    w.once("tauri://created", () => resolve());
    w.once("tauri://error", (e: unknown) => reject(new Error("窗口创建失败: " + String(e))));
  });
  return w;
}

/** 关闭当前窗口（弹窗自身调用） */
export async function closeSelf() {
  await getCurrentWindow().close();
}

/** 让当前窗口置顶并获取焦点 */
export async function focusSelf() {
  const w = getCurrentWindow();
  await w.setAlwaysOnTop(true);
  await w.setFocus();
}

/**
 * 在当前窗口应用透明度（写 CSS 变量 --win-alpha）。
 * 返回一个取消监听函数：读取已保存的透明度初始化 + 监听实时变更。
 * 每个弹窗 onMounted 时调用一次，onUnmounted 调用返回值。
 */
export async function bindOpacity(): Promise<() => void> {
  const apply = (v: number) =>
    document.documentElement.style.setProperty("--win-alpha", String(v));
  apply(loadSettings().opacity);
  const un = await onOpacityChanged(apply);
  return un;
}
