// 与 Rust 端 serde 结构体一一对应
export interface VersionInfo {
  version: string;
  season: string;
  season_name: string;
  vkey: string;
  chess_count: number;
}

export interface Champion {
  chessId: string;
  displayName: string;
  price: string;
  raceIds: string;
  jobIds: string;
  originalImage: string;
  hero_EN_name: string;
}

export interface LineupBrief {
  id: string;
  line_name: string;
  quality: string;
  pick_stages: string[][];
}

export interface PickCard {
  chess_id: string;
  name: string;
  price: number;
  is_new: boolean;
  image: string;
}

// ============ 前端独有类型 ============

/// 一个游戏模式（与 Rust 端 GameMode 结构一一对应）。
/// 数据来自主网站 tft-mode-registry.js 的活跃模式注册表，随版本自动更新。
export interface GameMode {
  /// 模式显示名，如 "星神"、"恭喜发财 英雄联盟传奇"
  name: string;
  /// 模式代号 = versionconfig 的 idSeason，如 "s17"、"s16m17"
  season: string;
  /// 是否娱乐模式（恭喜发财等限时模式为 true，正赛为 false）
  is_rgm: boolean;
  /// 队列 ID（如 1100=星神正赛、1210=恭喜发财）
  queue_id: string;
  /// 阵容数据 URL（来自 registry 的 lineupListUrl，已去时间戳参数）
  lineup_url: string;
}

/// 当前活跃模式注册表（与 Rust 端 CurrentModeInfo 一一对应）
export interface CurrentModeInfo {
  /// 当前正赛代号（window.CurrentSet），如 "s17"
  current_set: string;
  /// 全部活跃模式（已排除被注释的过期模式）
  modes: GameMode[];
}

/// 模式未加载时的兜底默认（星神正赛 s17）。
/// 仅在注册表尚未拉取/拉取失败时使用，refresh 成功后会被实际数据覆盖。
export const DEFAULT_GAME_MODE: GameMode = {
  name: "星神",
  season: "s17",
  is_rgm: false,
  queue_id: "",
  lineup_url: "",
};

export interface CustomPickItem {
  chessId: string;
  name: string;
  price: number;
  image: string;
}

export interface ShopRegion {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface AppSettings {
  /// 窗口透明度 0.3 ~ 1.0
  opacity: number;
  /// 5个卡牌名字区域（依次框选5次，OCR 模式用）
  nameRegions: ShopRegion[];
  /// 识别模式：ocr=文字识别 / image=找图匹配
  matchMode: "ocr" | "image";
  /// 5个卡牌整体区域（依次框选5次，找图模式用，与 nameRegions 平行但区域更大）
  cardRegions: ShopRegion[];
  /// 每个卡牌区域的 Y 轴裁剪偏移（测试时步进搜索记录，正式匹配直接用）
  cardOffsets: number[];
  /// 手动热键：按下 = 刷新商店 + 检测拿牌一次
  actionHotkey: string;
  /// 自动模式热键：按下 = 开启/关闭自动循环检测
  autoHotkey: string;
  /// 一键卖出热键：按下 = 弹出蒙版框选英雄区域 → 截图 → YOLO识别血条 → 按E卖出
  sellHotkey: string;
}

export const DEFAULT_SETTINGS: AppSettings = {
  opacity: 0.92,
  nameRegions: [],
  matchMode: "ocr",
  cardRegions: [],
  cardOffsets: [],
  actionHotkey: "Space",
  autoHotkey: "",
  sellHotkey: "Ctrl+Space",
};

/// 英雄头像 CDN URL（按 chessId 拼接）
/// chess.js 的 originalImage/skillImage 实为技能图标，不可用
export function heroImage(chessId: string): string {
  return `https://game.gtimg.cn/images/lol/act/img/tft/champions/${chessId}.png`;
}
