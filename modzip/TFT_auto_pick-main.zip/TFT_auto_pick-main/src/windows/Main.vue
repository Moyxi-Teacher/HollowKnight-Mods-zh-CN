<script setup lang="ts">
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import { onMounted, onUnmounted, ref } from "vue";
import {
  loadPicks,
  loadSettings,
  onApplyPicks,
  onOpacityChanged,
  onRegionSelected,
  onSettingsSaved,
  openPopup,
  persistPicks,
  persistMode,
  loadMode,
  emitModeChanged,
  saveSettings,
  closeSelf,
} from "../lib/shared";
import {
  DEFAULT_GAME_MODE,
  heroImage,
  type AppSettings,
  type Champion,
  type CurrentModeInfo,
  type CustomPickItem,
  type GameMode,
  type LineupBrief,
  type ShopRegion,
  type VersionInfo,
} from "../types";

/// 把5个名字区域同步到 Rust 端
async function syncNameRegionsToEngine(regions: ShopRegion[]) {
  try {
    await invoke("set_name_regions", { regions });
  } catch (e) {
    console.warn("同步名字区域失败", e);
  }
}

/// 把5个卡牌整体区域同步到 Rust 端（找图模式用）
async function syncCardRegionsToEngine(regions: ShopRegion[]) {
  try {
    await invoke("set_card_regions", { regions });
  } catch (e) {
    console.warn("同步卡牌区域失败", e);
  }
}

/// 把卡牌 Y 轴裁剪偏移同步到 Rust 端（测试时步进搜索记录，正式匹配直接用）
async function syncCardOffsetsToEngine(offsets: number[]) {
  try {
    await invoke("set_card_offsets", { offsets });
  } catch (e) {
    console.warn("同步卡牌偏移失败", e);
  }
}

/// 把已录制的热键注册到 Rust 端（kind: action=手动刷新+检测，auto=自动模式开关）
async function syncHotkeyToEngine(hotkey: string, kind: "action" | "auto") {
  if (!hotkey) return;
  try {
    await invoke("register_hotkey", { hotkey, kind });
    if (kind === "action") hotkeyStatus.value = `手动热键[${hotkey}] 已注册`;
  } catch (e) {
    if (kind === "action") hotkeyStatus.value = `热键[${hotkey}] 注册失败: ${e}`;
  }
}

const versionInfo = ref<VersionInfo | null>(null);
const lineups = ref<LineupBrief[]>([]);
const champions = ref<Champion[]>([]);
const loading = ref(false);
const errorMsg = ref("");

// 检测状态："" / "检测中..." / "已拿: XXX" / "未匹配" / "检测失败: ..."
const detectStatus = ref("");
const detecting = ref(false);
// 持久显示的 OCR 结果（窗口底部独立状态栏，商店未刷新时保留上次结果，不被 detectStatus 覆盖）
const ocrResultDisplay = ref("");
// OCR 字符约束状态（显示 mask 是否生效，如"约束 85/18385"）
const ocrMaskStatus = ref("");
// 热键注册状态（用于调试：确认热键是否注册成功）
const hotkeyStatus = ref("");

const gameMode = ref<GameMode>(loadMode());
const customPicks = ref<CustomPickItem[]>(loadPicks());
const settings = ref<AppSettings>(loadSettings());

// 可选游戏模式列表（来自主网站活跃模式注册表，随版本自动更新）。
// 初始用兜底列表，loadGameModes 成功后替换为注册表实际数据。
const FALLBACK_MODES: GameMode[] = [
  DEFAULT_GAME_MODE,
  { name: "恭喜发财", season: "s16m17", is_rgm: true, queue_id: "", lineup_url: "" },
];
const gameModes = ref<GameMode[]>(FALLBACK_MODES);

// 弹窗引用（避免重复打开）
const openWindows = ref<Set<string>>(new Set());

/// 清洗文本：只保留中文字符，去除英文/数字/空格/标点/不可见字符
/// TFT 英雄名为纯中文，OCR 在 Rust 端用 PaddleOCR 完成，此处仅清洗识别结果用于匹配
function normalizeText(s: string): string {
  return s.replace(/[^\u4e00-\u9fff]/g, "").trim();
}

/// 编辑距离（Levenshtein）：用于判断 OCR 文本与找图识别英雄名的差异度。
/// 用途：合并模式下，当两种识别都过阈值但结果不同时，按距离决策信任哪个。
/// - 距离 0 = 完全相同（如 "凯尔" vs "凯尔"）
/// - 距离 1 = 一字之差（如 "凯尔" vs "凯隐"）→ 相近，找图更可能对（颜色认得准）
/// - 距离 ≥2 = 差异大（如 "慎" vs "嘉文四世"）→ OCR 更可能对（文字唯一性强）
function levenshtein(a: string, b: string): number {
  if (a === b) return 0;
  if (!a) return b.length;
  if (!b) return a.length;
  const m = a.length;
  const n = b.length;
  // 滚动数组优化空间
  let prev = new Array(n + 1);
  let curr = new Array(n + 1);
  for (let j = 0; j <= n; j++) prev[j] = j;
  for (let i = 1; i <= m; i++) {
    curr[0] = i;
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      curr[j] = Math.min(prev[j] + 1, curr[j - 1] + 1, prev[j - 1] + cost);
    }
    [prev, curr] = [curr, prev];
  }
  return prev[n];
}

/// 检测版本号：每次 runDetect 启动递增，用于"新触发取代旧触发"。
let detectVersion = 0;
/// 缓存上次的 OCR 结果：商店未变化时（aHash 跳过 OCR）用缓存结果重新匹配，
/// 因为拿牌池会动态变化（用户随时加英雄），上次没匹配的卡现在可能匹配到新目标。
/// 牌取了图自然就变，aHash 会检测到变化触发重新 OCR，无需记点击状态。
let lastOcrNames: string[] = [];
/// 找图模式缓存：上次每张卡的 (chessId, score)。
/// 与 lastOcrNames 平行，商店未变化时用缓存重新匹配（拿牌池可能变了）。
/// chessId 是 Rust 端全量 HSV 匹配的 top-1（必为某英雄，可能不在拿牌池内）。
let lastCardIds: [string | null, number][] = [];
/// 上次传给 Rust 端的拿牌池 chessId 列表（排序后字符串比较）。
/// 拿牌池变化时须 force=true 强制重新匹配：找图缓存是 chessId（Rust 已匹配的结果），
/// 不像 OCR 缓存文本可前端重新匹配。拿牌池新增英雄后，缓存的 null 需重新匹配新英雄。
let lastTargetIds = "";

/// 根据 chessId 查英雄名；未找到则返回原始 ID。用于状态栏显示识别结果。
function heroNameByChessId(chessId: string | null): string {
  if (!chessId) return "·";
  const c = champions.value.find((c) => c.chessId === chessId);
  return c?.displayName || chessId;
}

/// 执行一次检测
/// delay=true：手动模式，截屏前延时 400ms 等刷新动画（热键=刷新+检测同一按键）
/// delay=false：自动模式，商店静止无需延时
/// 版本化取消：新触发让旧检测在 await 后放弃点击，保证点击基于最新截屏。
/// 多卡匹配：一次扫描5张卡收集所有命中目标，按 price 降序依次点击。
/// 合并模式：OCR + 找图并发，按分数合并结果（找图 > 0.83 优先，否则用 OCR）
async function runDetect(delay: boolean = false) {
  const myVersion = ++detectVersion;
  detecting.value = true;
  detectStatus.value = "检测中...";
  try {
    if (delay) {
      // 手动模式：热键=刷新+检测，按下瞬间游戏才开始刷新商店（卡牌翻转动画约400ms），
      // 立即截屏会截到刷新前的旧卡牌，故延时后再截屏
      await new Promise((r) => setTimeout(r, 400));
      if (myVersion !== detectVersion) return;
    }

    // 合并模式：找图 + OCR 并发，找图 score > 0.83 优先，否则用 OCR（score > 0.83）
    await runDetectCombined(myVersion);
  } catch (e) {
    if (myVersion === detectVersion) detectStatus.value = `检测失败: ${e}`;
  } finally {
    if (myVersion === detectVersion) {
      detecting.value = false;
      // 自动模式保持显示最新结果；手动模式 10 秒后清空
      if (!autoMode.value) {
        setTimeout(() => {
          if (myVersion === detectVersion) detectStatus.value = "";
        }, 10000);
      }
    }
  }
}

/// OCR 匹配分数定义（合并模式用）：
/// - 完全匹配（ocrText === targetName）→ 1.0
/// - ocrText 包含 targetName（OCR 多字）→ 0.95
/// - targetName 包含 ocrText（OCR 少字）→ 0.85（仅当 ocrText 长度 ≥3）
///
/// 关键 bug 修复（2026-07-27）：禁止单字/双字 OCR 的少字匹配。
/// 之前单字"世"（OCR 误识别商店边框线为"世"）会触发 targetName.includes("世")
/// 匹配到"嘉文四世"（score=0.85 > 0.83 阈值）→ 误识别为嘉文四世。
/// 原理：单字 OCR 对任何含该字的多字英雄名都会触发双向包含，
///       而单字常来自 OCR 噪声（边框、光效、技能图标拼出的笔画），不可信。
/// 阈值：ocrText 长度 ≥3 才允许少字匹配。
///   - 长度 1（如"世"）：纯噪声，禁止少字匹配
///   - 长度 2（如"嘉文"）：少字匹配可能误伤（如"慎"匹配"慎娘"），保守禁用
///   - 长度 3+（如"嘉文四"匹配"嘉文四世"）：OCR 漏字，少字匹配合理
/// allChampions 版：匹配所有英雄（用于状态栏显示合并后的识别结果，不管在不在拿牌池）
function matchOcrToAllChampions(
  ocrText: string,
  allChampions: Champion[],
): { chessId: string; name: string; score: number } | null {
  if (!ocrText) return null;
  for (const c of allChampions) {
    const targetName = normalizeText(c.displayName);
    if (!targetName) continue;
    if (ocrText === targetName) return { chessId: c.chessId, name: c.displayName, score: 1.0 };
    if (ocrText.includes(targetName)) return { chessId: c.chessId, name: c.displayName, score: 0.95 };
    // 少字匹配：仅当 OCR 文本长度 ≥3 时允许（避免单字噪声误匹配）
    if (ocrText.length >= 3 && targetName.includes(ocrText)) {
      return { chessId: c.chessId, name: c.displayName, score: 0.85 };
    }
  }
  return null;
}

/// matchOcrToTarget（拿牌池版）：只匹配拿牌池，用于点击逻辑
function matchOcrToTarget(
  ocrText: string,
  sortedTargets: { t: CustomPickItem; name: string }[],
): { target: CustomPickItem; score: number } | null {
  if (!ocrText) return null;
  for (const { t, name: targetName } of sortedTargets) {
    if (!targetName) continue;
    if (ocrText === targetName) return { target: t, score: 1.0 };
    if (ocrText.includes(targetName)) return { target: t, score: 0.95 };
    // 少字匹配：仅当 OCR 文本长度 ≥3 时允许（避免单字噪声误匹配）
    if (ocrText.length >= 3 && targetName.includes(ocrText)) {
      return { target: t, score: 0.85 };
    }
  }
  return null;
}

/// 合并模式检测：找图 + OCR 并发，按分数合并结果。
/// 规则：找图 score > 0.83 优先用找图结果；找图 ≤ 0.83 时用 OCR（score > 0.83）的结果。
/// 两种模式互补：找图对颜色差异大的英雄准确，OCR 对名字清晰的英雄准确。
async function runDetectCombined(myVersion: number) {
  if (customPicks.value.length === 0) {
    if (autoMode.value) detectStatus.value = "拿牌池为空";
    return;
  }

  // 拿牌池变化检测：变化时 force=true 强制找图重新匹配（跳过 aHash）
  const targetIds = customPicks.value.map((p) => p.chessId);
  const targetIdsKey = [...targetIds].sort().join(",");
  const targetsChanged = targetIdsKey !== lastTargetIds;
  lastTargetIds = targetIdsKey;

  // 一次截屏同时做 OCR + 找图（capture_both）。
  // 比两个独立命令省 1 次截屏，且保证两个结果基于同一帧画面（避免时序不一致）。
  // 两套独立 aHash 检测在 Rust 端完成：各自 skip 时对应结果返回空数组。
  // Rust 返回 tuple (Vec<String>, Vec<(Option<String>, f32)>)，序列化为 JSON 数组，用数组解构。
  const [ocrResult, imageResult] = await invoke<[string[], [string | null, number][]]>(
    "capture_both",
    { force: targetsChanged },
  );
  if (myVersion !== detectVersion) return;

  // 处理 aHash 变化检测（两套独立）。
  // 关键修复：OCR 和找图 aHash 独立，可能其中一个检测到变化而另一个没检测到（aHash 假阴性）。
  // 商店变化时两者区域都应该变化，如果只有一个检测到，另一个的缓存是「上一个商店状态」的过期数据。
  // 例如：卡牌被买后，OCR 检测到变化（名字区变了）但找图没检测到（卡牌区 aHash 偶然相似），
  // 此时找图缓存里仍是被买前的旧英雄（如嘉文四世 0.95），用旧缓存会导致：
  //   - OCR 空（卡被买，无文字）+ 找图旧缓存高置信 → 误显示嘉文四世
  // 修复：任一检测到变化（shopChanged）时，另一个没检测到的模式不用缓存，用空结果兜底。
  //   只用检测到变化的那个模式的结果，避免新旧商店状态混淆。
  //   下次循环 Rust 端 aHash 会自动修正（last_card_hash 仍是旧值，与新截图对比会检测到变化）。
  const ocrChanged = ocrResult.length > 0;
  const imageChanged = imageResult.length > 0;
  const shopChanged = ocrChanged || imageChanged;
  let ocrTexts: string[];
  let imageResults: [string | null, number][];
  if (ocrChanged) {
    lastOcrNames = ocrResult;
    ocrTexts = ocrResult;
  } else if (shopChanged) {
    // 商店变了但 OCR aHash 没检测到 → OCR 缓存过期，不用（用空结果，OCR 不参与合并）
    ocrTexts = [];
  } else {
    // 商店没变，用缓存（自动模式省 CPU 的关键路径）
    ocrTexts = lastOcrNames;
  }
  if (imageChanged) {
    lastCardIds = imageResult;
    imageResults = imageResult;
  } else if (shopChanged) {
    // 商店变了但找图 aHash 没检测到 → 找图缓存过期，不用（用空结果，找图不参与合并）
    imageResults = [];
  } else {
    // 商店没变，用缓存（自动模式省 CPU 的关键路径）
    imageResults = lastCardIds;
  }

  // 两边都无数据（首次启动且商店未变化）→ return
  if (ocrTexts.length === 0 && imageResults.length === 0) {
    if (autoMode.value) detectStatus.value = "商店未变化（等待刷新）";
    return;
  }

  // 对齐到 5 张卡
  while (ocrTexts.length < 5) ocrTexts.push("");
  while (imageResults.length < 5) imageResults.push([null, 0]);

  // 清洗 OCR 文本（只保留中文）
  const cleanedOcr = ocrTexts.map((n) => normalizeText(n));

  // 拿牌池按 price 降序（OCR 双向包含匹配用）
  const sortedTargets = [...customPicks.value]
    .sort((a, b) => b.price - a.price)
    .map((t) => ({ t, name: normalizeText(t.name) }));

  // 阈值说明：
  // - IMG_THRESHOLD = 0.8：找图阈值（HSV 巴氏系数）。用户调低到 0.8，
  //   因为有了 OCR 防线（A 分支：OCR 没认出英雄且商店变了就不信任找图），
  //   找图误识别的后果可控——空背景场景被 A 分支拦住，相似英雄误配由 B 距离判断兜底。
  // - OCR_THRESHOLD = 0.8：OCR 命中阈值。
  //   OCR 分数定义：完全匹配1.0 / 多字匹配0.95 / 少字匹配0.85（仅 ocrText 长度 ≥3）。
  //   阈值 0.8 让所有合法匹配（含少字匹配 0.85）都能过阈值。
  //   注意：少字匹配已用 ocrText.length >= 3 限制防止单字噪声误匹配，
  //         所以 0.8 阈值下少字匹配不会引入"世"→嘉文四世这类 bug。
  // - DIST_NEAR = 1：编辑距离相近阈值（≤1 视为相近，找图优先；≥2 视为远，OCR 优先）
  //
  // 合并策略（基于两种识别方式的特性 + 文字距离判断）：
  //   OCR 误识别率极低（文字唯一性强，空区域无文字自然不匹配）
  //   找图误识别率高（空区域/相似色都会误识别）
  //   但找图对颜色差异敏感——OCR 看错字时，找图常能认对英雄
  //
  //   规则：
  //   A. 商店变了但 OCR 没认出英雄 → 不信任找图（避免空背景误识别）
  //      理由：OCR 对真实卡牌识别率 >90%，跑了却没认出 = 卡牌很可能不存在（空背景），
  //            此时找图高分很可能是空背景与某英雄模板碰巧相似
  //   B. 两种都过阈值：
  //      B1. 结果相同 → 用任一（OCR 文本与找图英雄名一致）
  //      B2. 结果不同但编辑距离相近（≤1）→ 找图优先
  //          理由：一字之差说明 OCR 看错了字（如 凯尔→凯隐），找图认色更可能对
  //      B3. 结果不同且距离大（≥2）→ OCR 优先
  //          理由：差异大说明找图错配（如 慎 vs 嘉文四世），OCR 文字唯一性更可靠
  //   C. 只 OCR 过阈值 → 用 OCR
  //   D. 只找图过阈值 → 用找图
  //      理由：OCR 没跑（商店未变化用缓存）或 OCR 无数据且商店未变，找图是唯一信号
  //   E. 都没过 → 不点
  const IMG_THRESHOLD = 0.8;
  const OCR_THRESHOLD = 0.8;
  const DIST_NEAR = 1;

  const hits: { slot: number; name: string; price: number }[] = [];
  const displayParts: string[] = [];

  for (let i = 0; i < 5; i++) {
    const [imgChessId, imgScore] = imageResults[i];
    const ocrText = cleanedOcr[i] || "";

    // OCR 匹配所有英雄（用于判断 OCR 是否识别到任何英雄，不只拿牌池）
    const ocrAllMatch = matchOcrToAllChampions(ocrText, champions.value);
    const ocrAllHit = ocrAllMatch && ocrAllMatch.score > OCR_THRESHOLD;

    // OCR 匹配拿牌池（用于点击逻辑）
    const ocrMatchInPool = ocrText ? matchOcrToTarget(ocrText, sortedTargets) : null;
    const ocrHitInPool = ocrMatchInPool && ocrMatchInPool.score > OCR_THRESHOLD ? ocrMatchInPool.target : null;

    // 找图匹配
    const imgAllHit = !!(imgChessId && imgScore > IMG_THRESHOLD);
    // 找图在拿牌池内才算命中
    const imgHitInPool = imgAllHit
      ? customPicks.value.find((p) => p.chessId === imgChessId) ?? null
      : null;

    // 找图识别的英雄名（用于与 OCR 文本比较距离）
    const imgHeroName = imgChessId ? heroNameByChessId(imgChessId) : "";

    // 关键判断：OCR 没认出英雄（识别为空、乱码、或 aHash 假阴性无数据）且商店变了。
    // 商店变化时，OCR 对真实卡牌识别率 >90%；OCR 没认出英雄 = 卡牌很可能不存在
    // （被买后的空背景）。此时找图高分（0.95+）很可能是空背景与某英雄模板碰巧相似，
    // 不信任找图，显示 · 不点（保守策略：宁漏勿误，避免乱花钱）。
    // 覆盖三种场景：
    //   1. OCR 跑了识别为空（ocrChanged=true, ocrText=""）
    //   2. OCR 跑了输出乱码不匹配英雄（ocrChanged=true, ocrAllHit=false）
    //   3. OCR aHash 假阴性（ocrChanged=false, shopChanged=true, ocrTexts 被设为空）
    // 第3种：OCR aHash 漏检但找图 aHash 检测到变化 → 商店确实变了但 OCR 无数据，
    //        保守不信任找图（找图可能错配空背景），下次循环 OCR aHash 会修正。
    const ocrNoHitAndShopChanged = !ocrAllHit && shopChanged;

    // 合并决策（同时用于点击和显示，逻辑一致）：
    let hitTarget: CustomPickItem | null;
    let recognizedName: string;

    if (ocrNoHitAndShopChanged) {
      // A. 商店变了但 OCR 没认出英雄 → 不信任找图（避免空背景误识别）
      hitTarget = null;
      recognizedName = "·";
    } else if (ocrAllHit && imgAllHit) {
      // B. 两种都过阈值 → 按文字距离判断
      const ocrName = ocrAllMatch!.name;
      if (ocrText === imgHeroName || ocrName === imgHeroName) {
        // B1. 结果相同 → 用任一（优先 OCR 在拿牌池的命中）
        hitTarget = ocrHitInPool ?? imgHitInPool;
        recognizedName = ocrName;
      } else {
        const dist = levenshtein(ocrText, imgHeroName);
        if (dist <= DIST_NEAR) {
          // B2. 距离相近 → 找图优先
          hitTarget = imgHitInPool;
          recognizedName = imgHeroName;
        } else {
          // B3. 距离大 → OCR 优先
          hitTarget = ocrHitInPool;
          recognizedName = ocrName;
        }
      }
    } else if (ocrAllHit) {
      // C. 只 OCR 过 → 用 OCR
      hitTarget = ocrHitInPool;
      recognizedName = ocrAllMatch!.name;
    } else if (imgAllHit) {
      // D. 只找图过（≥0.8） → 用找图
      //    此分支触发条件：OCR 没认出英雄（ocrAllHit=false）且商店未变化（shopChanged=false）
      //    即 OCR aHash skip 用缓存，缓存没认出英雄，找图缓存或新结果过了 0.8 阈值
      //    商店变化时会被 A 分支拦截，所以这里只在商店未变化时信任找图
      hitTarget = imgHitInPool;
      recognizedName = imgHeroName;
    } else {
      // E. 都没过 → 不点
      hitTarget = null;
      recognizedName = "·";
    }

    displayParts.push(recognizedName);

    // 点击逻辑：只点击在拿牌池内的命中卡
    if (hitTarget) {
      hits.push({ slot: i, name: hitTarget.name, price: hitTarget.price });
    }
  }

  ocrResultDisplay.value = `${shopChanged ? "" : "(缓存)"}${displayParts.join(" | ")}`;

  hits.sort((a, b) => b.price - a.price);

  // 点击命中的卡（用 cardRegions 中心，区域更大更稳）
  await clickHits(myVersion, hits, settings.value.cardRegions, shopChanged ? "" : "(缓存)");

  // 不清除缓存：点击可能失败（游戏不在前台），此时商店未变、aHash 不变，
  // 下次循环会用缓存重新匹配同一张卡并重新点击--这是期望行为（A 还在，应该继续尝试拿）。
  // 点击成功时，买牌后卡牌消失 -> 商店变化 -> aHash 检测到 -> 重新匹配（A 不在了，自然不重复）。
}

/// 依次点击命中的卡。匹配到后无延时点击（多卡间不等待）。
async function clickHits(
  myVersion: number,
  hits: { slot: number; name: string; price: number }[],
  regions: ShopRegion[] | undefined,
  tag: string,
) {
  if (hits.length > 0) {
    for (let idx = 0; idx < hits.length; idx++) {
      if (myVersion !== detectVersion) return;
      const h = hits[idx];
      const region = regions?.[h.slot];
      if (region) {
        const clickX = Math.round(region.x + region.width / 2);
        const clickY = Math.round(region.y + region.height / 2);
        await invoke("click_position", { x: clickX, y: clickY });
      }
    }
    detectStatus.value = `已拿: ${hits.map((h) => h.name).join(",")}${tag}`;
  } else {
    detectStatus.value = `未匹配${tag}`;
  }
}

// ============ 自动模式（循环检测） ============
const autoMode = ref(false);
let autoLoopTimer: number | null = null;
/// 自动循环间隔（毫秒）。
/// 200ms = 5fps：商店未变化时 Rust 端 aHash 跳过 OCR/找图，CPU 极低；
/// 商店变化时一次 capture_both（截屏+OCR+找图），耗时见控制台 [capture_both] 日志。
/// 30fps(33ms) 不现实：OCR 5张图×3变体=15次推理，单次10-30ms，总计150-450ms。
/// 如需更快响应，可根据日志中 OCR 实际耗时调整此值。
const AUTO_INTERVAL = 200;

function startAutoLoop() {
  if (autoLoopTimer !== null) return;
  const tick = async () => {
    autoLoopTimer = null;
    if (!autoMode.value) return;
    await runDetect(false); // 自动模式无延时（商店静止）
    if (autoMode.value) {
      autoLoopTimer = window.setTimeout(tick, AUTO_INTERVAL);
    }
  };
  // 先等一个间隔再开始检测
  autoLoopTimer = window.setTimeout(tick, AUTO_INTERVAL);
}
function stopAutoLoop() {
  if (autoLoopTimer !== null) {
    clearTimeout(autoLoopTimer);
    autoLoopTimer = null;
  }
}
function toggleAutoMode() {
  autoMode.value = !autoMode.value;
  if (autoMode.value) {
    detectStatus.value = "自动模式: 开启";
    startAutoLoop();
  } else {
    stopAutoLoop();
    detectStatus.value = "自动模式: 关闭";
    setTimeout(() => {
      if (!autoMode.value) detectStatus.value = "";
    }, 2000);
  }
}

function applyOpacity(v: number) {
  document.documentElement.style.setProperty("--win-alpha", String(v));
}

/// 同步 OCR 字符级约束：把当前赛季所有英雄名传给 Rust 端构建 mask。
/// 模型 argmax 时只能在英雄字 + blank 里选，从根源杜绝识别出英雄名以外的字。
/// 每次 refresh（含切换模式重新加载数据）后调用，确保约束随赛季更新。
async function syncOcrAllowedChars() {
  if (champions.value.length === 0) {
    ocrMaskStatus.value = "约束未设置（无英雄数据）";
    return;
  }
  try {
    const [allowed, total] = await invoke<[number, number]>(
      "set_ocr_allowed_chars",
      { names: champions.value.map((c) => c.displayName) },
    );
    ocrMaskStatus.value = `约束 ${allowed}/${total} (${champions.value.length}英雄)`;
  } catch (e) {
    ocrMaskStatus.value = `约束失败: ${e}`;
    console.warn("设置 OCR 字符约束失败", e);
  }
}

async function refresh() {
  loading.value = true;
  errorMsg.value = "";
  try {
    versionInfo.value = await invoke<VersionInfo>("refresh_data");
    lineups.value = await invoke<LineupBrief[]>("get_lineups");
    champions.value = await invoke<Champion[]>("get_champions");
    // 设置 OCR 字符级约束：只允许识别英雄名字用字，从根源杜绝「药」「我」等非英雄字
    await syncOcrAllowedChars();
  } catch (e) {
    errorMsg.value = String(e);
  } finally {
    loading.value = false;
  }
}

/// 拉取主网站活跃模式注册表，动态填充模式下拉框。
/// 腾讯更新版本时会改 tft-mode-registry.js（增删模式/改代号），软件因此自动同步。
/// 同时校验本地缓存的 season 是否仍在注册表中：不在则切到当前正赛（current_set）。
async function loadGameModes() {
  try {
    const info = await invoke<CurrentModeInfo>("get_game_modes");
    if (info.modes.length === 0) return;
    gameModes.value = info.modes;

    const fresh = info.modes.find((m) => m.season === gameMode.value.season);
    if (fresh) {
      // 缓存的 season 仍有效：用注册表最新 name/lineup_url 刷新本地缓存
      gameMode.value = fresh;
      persistMode(fresh);
      emitModeChanged(fresh);
    } else {
      // 缓存的 season 已失效（版本更迭被下架）：切到当前正赛
      const def =
        info.modes.find((m) => m.season === info.current_set) ??
        info.modes.find((m) => !m.is_rgm) ??
        info.modes[0];
      gameMode.value = def;
      persistMode(def);
      emitModeChanged(def);
    }
  } catch (e) {
    // 注册表拉取失败：保留兜底列表，refresh 仍会用 Rust 端默认 season 兜底
    console.warn("拉取活跃模式注册表失败，使用兜底列表", e);
  }
}

/// 切换游戏模式：传入 season 代号（来自 select 的 option value）
async function onModeChange(season: string) {
  const m = gameModes.value.find((g) => g.season === season);
  if (!m) return;
  gameMode.value = m;
  persistMode(m);
  emitModeChanged(m);
  try {
    await invoke("set_game_mode", { season: m.season });
    await refresh();
  } catch (e) {
    errorMsg.value = String(e);
  }
}

async function openPopupWindow(hash: string, title: string, w: number, h: number) {
  if (openWindows.value.has(hash)) return;
  openWindows.value.add(hash);
  try {
    const win = await openPopup({ hash, title, width: w, height: h });
    win.once("tauri://destroyed", () => openWindows.value.delete(hash));
  } catch (e) {
    errorMsg.value = String(e);
    openWindows.value.delete(hash);
  }
}

// 事件监听
let unsubs: Array<() => void> = [];
onMounted(async () => {
  applyOpacity(settings.value.opacity);
  // 同步名字区域 / 卡牌区域 / 热键到 Rust 拿牌引擎
  if (settings.value.nameRegions && settings.value.nameRegions.length > 0) {
    await syncNameRegionsToEngine(settings.value.nameRegions);
  }
  if (settings.value.cardRegions && settings.value.cardRegions.length > 0) {
    await syncCardRegionsToEngine(settings.value.cardRegions);
  }
  if (settings.value.cardOffsets && settings.value.cardOffsets.length > 0) {
    await syncCardOffsetsToEngine(settings.value.cardOffsets);
  }
  if (settings.value.actionHotkey) {
    await syncHotkeyToEngine(settings.value.actionHotkey, "action");
  }
  if (settings.value.autoHotkey) {
    await syncHotkeyToEngine(settings.value.autoHotkey, "auto");
  }
  // 同步卖出热键到 Rust 端（卖出区域每次触发现选，不持久化）
  if (settings.value.sellHotkey) {
    await syncSellHotkeyToEngine(settings.value.sellHotkey);
  }
  // 拉活跃模式注册表（动态填充下拉框 + 校验缓存 season 是否仍有效）
  await loadGameModes();
  // 用前端缓存的游戏模式同步到 Rust 端（Rust 端每次重启会重置为默认值 s17）
  try {
    await invoke("set_game_mode", { season: gameMode.value.season });
  } catch {}
  await refresh();

  unsubs = [
    await onApplyPicks((items) => {
      const map = new Map(customPicks.value.map((p) => [p.chessId, p]));
      for (const it of items) if (!map.has(it.chessId)) map.set(it.chessId, it);
      customPicks.value = [...map.values()];
      persistPicks(customPicks.value);
    }),
    await onSettingsSaved((s) => {
      settings.value = s;
      saveSettings(s);
      applyOpacity(s.opacity);
      if (s.nameRegions && s.nameRegions.length > 0) syncNameRegionsToEngine(s.nameRegions);
      if (s.cardRegions && s.cardRegions.length > 0) syncCardRegionsToEngine(s.cardRegions);
      if (s.cardOffsets && s.cardOffsets.length > 0) syncCardOffsetsToEngine(s.cardOffsets);
      if (s.actionHotkey) syncHotkeyToEngine(s.actionHotkey, "action");
      if (s.autoHotkey) syncHotkeyToEngine(s.autoHotkey, "auto");
      // 卖出热键（卖出区域每次触发现选，无需同步持久化区域）
      if (s.sellHotkey) syncSellHotkeyToEngine(s.sellHotkey);
    }),
    await onOpacityChanged((o) => applyOpacity(o)),
    // 手动热键触发 → 延时检测一次（刷新+检测）
    await listen("detect-triggered", () => {
      runDetect(true);
    }),
    // 自动模式热键触发 → 开启/关闭循环检测
    await listen("auto-toggle", () => {
      toggleAutoMode();
    }),
    // 一键卖出热键触发 → 弹出蒙版框选 → 区域选中后 click_focus_point → sell_heroes
    await listen("sell-triggered", () => {
      runSell();
    }),
    // 框选卖出区域结果（RegionPicker emit region-selected）→ 执行卖出
    await onRegionSelected((r: ShopRegion) => {
      if (!pickingSell.value) return;
      pickingSell.value = false;
      executeSell(r);
    }),
  ];
});
onUnmounted(() => {
  unsubs.forEach((u) => u());
  stopAutoLoop();
});

function removePick(chessId: string) {
  customPicks.value = customPicks.value.filter((p) => p.chessId !== chessId);
  persistPicks(customPicks.value);
}
function clearAll() {
  customPicks.value = [];
  persistPicks(customPicks.value);
}

// ============ 一键卖出 ============
// 流程：按 Ctrl+Space（或点「一键卖出」按钮）→ 弹出全屏蒙版框选英雄所在区域 →
// 关闭后点击左下角焦点位置让游戏获焦 → 截图该区域 → YOLO 识别血条 → 依次移到英雄位置按 E（间隔 50ms）。
// 区域每次触发现选（棋盘状态会变），不持久化。
const sellStatus = ref("");
const sellRunning = ref(false);
// 当前是否正等待 RegionPicker 的框选结果（区分 region-selected 归属；ref 让按钮禁用态响应式）
const pickingSell = ref(false);

/// 注册卖出热键到 Rust 端（kind="sell"）
async function syncSellHotkeyToEngine(hotkey: string) {
  if (!hotkey) return;
  try {
    await invoke("register_hotkey", { hotkey, kind: "sell" });
  } catch (e) {
    console.warn("卖出热键注册失败", e);
  }
}

/// 触发一键卖出：弹出全屏蒙版让用户框选英雄所在区域，区域选中后继续截图→YOLO→按E。
/// 热键（Ctrl+Space 游戏内按下）与按钮点击走同一流程。
async function runSell() {
  if (sellRunning.value || pickingSell.value) return;
  pickingSell.value = true;
  sellStatus.value = "请框选英雄所在区域";
  try {
    const win = await openPopup({
      hash: "region",
      title: "框选英雄所在区域",
      width: 800,
      height: 600,
    });
    // 用户按 ESC 取消框选（RegionPicker 关闭但未 emit region-selected）：复位状态
    win.once("tauri://destroyed", () => {
      if (pickingSell.value) {
        pickingSell.value = false;
        sellStatus.value = "";
      }
    });
  } catch (e) {
    pickingSell.value = false;
    sellStatus.value = `打开框选失败: ${e}`;
  }
}

/// 框选完成后的卖出执行：set_sell_region → 等蒙版关闭 → click_focus_point → sell_heroes
async function executeSell(region: ShopRegion) {
  sellRunning.value = true;
  sellStatus.value = "卖出中...";
  try {
    await invoke("set_sell_region", { region });
    // RegionPicker 在 emit 后 250ms 才 closeSelf，等其关闭后再点击左下角焦点位置，
    // 否则点击会落在仍全屏的蒙版上，游戏无法获焦
    await new Promise((res) => setTimeout(res, 350));
    await invoke("click_focus_point");
    const count = await invoke<number>("sell_heroes");
    sellStatus.value = count > 0 ? `已卖出 ${count} 个英雄` : "未识别到英雄";
  } catch (e) {
    sellStatus.value = `卖出失败: ${e}`;
  } finally {
    sellRunning.value = false;
    // 3 秒后清空状态
    setTimeout(() => {
      if (!sellRunning.value) sellStatus.value = "";
    }, 3000);
  }
}
</script>

<template>
  <main class="app">
    <!-- 顶部栏：data-tauri-drag-region 让空白处可拖动无边框窗口 -->
    <header class="topbar" data-tauri-drag-region>
      <select
        class="mode-select"
        :value="gameMode.season"
        @change="onModeChange(($event.target as HTMLSelectElement).value)"
      >
        <option v-for="m in gameModes" :key="m.season" :value="m.season">{{ m.name }}</option>
      </select>
      <button @click="openPopupWindow('lineup', '阵容推荐', 480, 620)">阵容推荐</button>
      <button @click="openPopupWindow('settings', '设置', 460, 560)">设置</button>
      <div class="spacer"></div>
      <span v-if="hotkeyStatus" class="hotkey-status">{{ hotkeyStatus }}</span>
      <span v-if="autoMode" class="auto-badge" :class="{ active: detecting }">自动●</span>
      <span v-if="detectStatus" class="detect-status" :class="{ active: detecting }">
        {{ detectStatus }}
      </span>
      <span v-if="versionInfo" class="version-tag">
        {{ versionInfo.season_name }} · v{{ versionInfo.version }} · {{ versionInfo.chess_count }}英
      </span>
      <button class="refresh" @click="refresh" :disabled="loading" title="刷新数据">
        {{ loading ? "…" : "↻" }}
      </button>
      <button class="close-btn" @click="closeSelf" title="关闭">×</button>
    </header>

    <p v-if="errorMsg" class="error">{{ errorMsg }}</p>

    <!-- 自定义拿牌区 -->
    <section class="pick-area">
      <div class="pick-list">
        <div
          v-for="p in customPicks"
          :key="p.chessId"
          class="pick-chip"
          :class="`cost-${p.price}`"
          @click="removePick(p.chessId)"
          title="点击移除"
        >
          <img :src="heroImage(p.chessId)" :alt="p.name" />
          <span class="chip-name">{{ p.name }}</span>
        </div>
        <button
          class="add-btn"
          @click="openPopupWindow('hero', '选择英雄', 580, 640)"
          title="添加英雄"
        >
          ＋
        </button>
      </div>
      <button v-if="customPicks.length > 0" class="clear-btn" @click="clearAll">
        一键清空
      </button>
    </section>

    <!-- 一键卖出区：按 Ctrl+Space 或点按钮 → 弹蒙版框选英雄区域 → 截图YOLO按E卖出 -->
    <section class="sell-area">
      <button
        class="sell-btn"
        @click="runSell()"
        :disabled="sellRunning || pickingSell"
        title="一键卖出（Ctrl+Space）"
      >
        一键卖出
      </button>
      <span class="sell-tip">快捷键 Ctrl+Space，框选需要卖出英雄的所在区域</span>
      <span v-if="sellStatus" class="sell-status" :class="{ active: sellRunning }">
        {{ sellStatus }}
      </span>
    </section>

    <!-- OCR 结果持久状态栏（窗口底部，商店未刷新时保留上次结果） -->
    <footer class="ocr-result-bar">
      <span v-if="ocrMaskStatus" class="mask-status" :class="{ disabled: ocrMaskStatus.includes('禁用') }">{{ ocrMaskStatus }}</span>
      <span v-if="ocrResultDisplay">{{ ocrResultDisplay }}</span>
    </footer>
  </main>
</template>

<style scoped>
.app {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: var(--bg);
  border: 1px solid var(--border);
  border-radius: 8px;
  overflow: hidden;
}
.topbar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 10px;
  background: rgba(20, 20, 42, calc(var(--win-alpha) * 1.1));
  border-bottom: 1px solid var(--border);
}
.mode-select {
  padding: 3px 8px;
  font-size: 12px;
}
.spacer {
  flex: 1;
}
.version-tag {
  font-size: 11px;
  color: #9aa;
  margin-right: 4px;
}
.detect-status {
  font-size: 11px;
  color: #9aa;
  margin-right: 6px;
  padding: 2px 6px;
  border-radius: 4px;
  background: rgba(40, 40, 70, 0.6);
  border: 1px solid var(--border);
  max-width: 200px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.detect-status.active {
  color: #ffd76b;
  border-color: #ffd76b;
}
.auto-badge {
  font-size: 11px;
  color: #ff6bff;
  margin-right: 6px;
  padding: 2px 6px;
  border-radius: 4px;
  background: rgba(70, 30, 70, 0.6);
  border: 1px solid #ff6bff;
}
.auto-badge.active {
  color: #fff;
  background: rgba(140, 40, 140, 0.7);
}
.hotkey-status {
  font-size: 11px;
  color: #6bff9a;
  margin-right: 6px;
  padding: 2px 6px;
  border-radius: 4px;
  background: rgba(40, 70, 40, 0.6);
  border: 1px solid var(--border);
  max-width: 220px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.refresh {
  padding: 3px 8px;
}
.close-btn {
  padding: 2px 8px;
  font-size: 16px;
  line-height: 1;
  background: transparent;
  border-color: transparent;
  color: #9aa;
}
.close-btn:hover {
  background: rgba(255, 107, 107, 0.3);
  color: #ff6b6b;
}
.error {
  color: #ff6b6b;
  font-size: 11px;
  margin: 4px 10px;
}
.pick-area {
  flex: 1;
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 8px 10px;
  overflow: auto;
}
.pick-list {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
  align-items: center;
  flex: 1;
}
.pick-chip {
  display: flex;
  align-items: center;
  gap: 3px;
  padding: 2px 6px 2px 2px;
  background: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: 14px;
  cursor: pointer;
}
.pick-chip:hover {
  background: rgba(74, 42, 42, var(--win-alpha));
  border-color: #ff6b6b;
}
.pick-chip img {
  width: 24px;
  height: 24px;
  border-radius: 50%;
}
.chip-name {
  font-size: 11px;
  max-width: 60px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.cost-1 { border-color: #6b8b9a; }
.cost-2 { border-color: #6ba86b; }
.cost-3 { border-color: #6b8bf7; }
.cost-4 { border-color: #b86bf7; }
.cost-5 { border-color: #ffb86b; }
.add-btn {
  width: 30px;
  height: 30px;
  border-radius: 50%;
  border-style: dashed;
  border-color: #6b8bf7;
  color: #6b8bf7;
  font-size: 16px;
  line-height: 1;
  padding: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.add-btn:hover {
  background: rgba(74, 108, 247, 0.2);
}
.clear-btn {
  padding: 4px 8px;
  background: transparent;
  color: #ff6b6b;
  border-color: #5a2a2a;
}
.clear-btn:hover {
  background: rgba(58, 42, 42, var(--win-alpha));
}
/* ============ 一键卖出区 ============ */
.sell-area {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  border-top: 1px solid var(--border);
  background: rgba(20, 20, 42, calc(var(--win-alpha) * 0.5));
  flex-shrink: 0;
}
.sell-btn {
  padding: 4px 12px;
  font-size: 12px;
  font-weight: 600;
  color: #1a1a2e;
  background: linear-gradient(180deg, #ffe08a, #ffd76b);
  border: 1px solid #d4a83a;
  border-radius: 4px;
  cursor: pointer;
  flex-shrink: 0;
}
.sell-btn:hover:not(:disabled) {
  background: linear-gradient(180deg, #fff0a8, #ffe27a);
}
.sell-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.sell-tip {
  font-size: 11px;
  color: #ffd76b;
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.sell-status {
  font-size: 11px;
  color: #ffd76b;
  padding: 2px 6px;
  border-radius: 4px;
  background: rgba(60, 50, 20, 0.6);
  border: 1px solid #6b5a2a;
  flex-shrink: 0;
  max-width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.sell-status.active {
  color: #fff;
  background: rgba(120, 90, 20, 0.7);
}
/* OCR 结果持久状态栏（窗口底部，始终显示上次识别结果） */
.ocr-result-bar {
  display: flex;
  gap: 8px;
  align-items: center;
  padding: 4px 10px;
  background: rgba(15, 15, 30, calc(var(--win-alpha) * 1.1));
  border-top: 1px solid var(--border);
  font-size: 11px;
  color: #8ab4f8;
  font-family: "Cascadia Code", Consolas, monospace;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  flex-shrink: 0;
}
.ocr-result-bar .mask-status {
  color: #4ade80;
  font-weight: bold;
  flex-shrink: 0;
}
.ocr-result-bar .mask-status.disabled {
  color: #fb923c;
}
</style>
