<script setup lang="ts">
import { onMounted, onUnmounted, ref } from "vue";
import { getCurrentWindow, currentMonitor } from "@tauri-apps/api/window";
import { closeSelf, emitRegionSelected, focusSelf } from "../lib/shared";
import type { ShopRegion } from "../types";

// 拖拽框选状态（窗口内 CSS 像素坐标）
const dragging = ref(false);
const startX = ref(0);
const startY = ref(0);
const curX = ref(0);
const curY = ref(0);
const finished = ref<ShopRegion | null>(null);

// 窗口左上角的屏幕物理坐标 + DPI 缩放因子（把 CSS px 换算为屏幕物理 px）
const winOffsetX = ref(0);
const winOffsetY = ref(0);
const scaleFactor = ref(1);

// 提示文案：从 url query string 解析（?tip=<encoded>），无则用默认文案
// 调用方通过 openPopup({hash:"region", tip:"框选卡牌整体区域"}) 传入
const tipText = ref("按住鼠标拖拽框选商店区域 · ESC 取消");

function onKey(e: KeyboardEvent) {
  if (e.key === "Escape") onCancel();
}

onMounted(async () => {
  // 解析 url query string 中的 tip 参数
  try {
    const hash = window.location.hash;
    const queryPart = hash.split("?")[1] || "";
    const params = new URLSearchParams(queryPart);
    const tip = params.get("tip");
    if (tip) tipText.value = tip + " · ESC 取消";
  } catch {}

  await focusSelf();
  const win = getCurrentWindow();
  try {
    // 全屏铺满整个显示器（含任务栏），像截图软件那样
    await win.setFullscreen(true);
    const mon = await currentMonitor();
    scaleFactor.value = mon?.scaleFactor ?? 1;
    // 全屏后窗口原点即显示器原点
    const pos = await win.outerPosition();
    winOffsetX.value = pos.x;
    winOffsetY.value = pos.y;
  } catch (e) {
    console.error(e);
  }
  document.body.style.cursor = "crosshair";
  window.addEventListener("keydown", onKey);
});

function onMouseDown(e: MouseEvent) {
  if (e.button !== 0) return;
  dragging.value = true;
  finished.value = null;
  startX.value = e.clientX;
  startY.value = e.clientY;
  curX.value = e.clientX;
  curY.value = e.clientY;
  window.addEventListener("mousemove", onMouseMove);
  window.addEventListener("mouseup", onMouseUp);
}
function onMouseMove(e: MouseEvent) {
  curX.value = e.clientX;
  curY.value = e.clientY;
}
function onMouseUp() {
  dragging.value = false;
  window.removeEventListener("mousemove", onMouseMove);
  window.removeEventListener("mouseup", onMouseUp);
  const x = Math.min(startX.value, curX.value);
  const y = Math.min(startY.value, curY.value);
  const w = Math.abs(curX.value - startX.value);
  const h = Math.abs(curY.value - startY.value);
  if (w < 10 || h < 10) return;
  // CSS px → 屏幕物理 px（截屏识别用物理坐标）
  const sf = scaleFactor.value;
  const region: ShopRegion = {
    x: Math.round(x * sf + winOffsetX.value),
    y: Math.round(y * sf + winOffsetY.value),
    width: Math.round(w * sf),
    height: Math.round(h * sf),
  };
  finished.value = region;
  emitRegionSelected(region);
  setTimeout(() => closeSelf(), 250);
}

function onCancel() {
  closeSelf();
}

onUnmounted(() => {
  document.body.style.cursor = "";
  window.removeEventListener("mousemove", onMouseMove);
  window.removeEventListener("mouseup", onMouseUp);
  window.removeEventListener("keydown", onKey);
});

// 选框样式
function boxStyle() {
  if (!dragging.value && !finished.value) return { display: "none" };
  const x = Math.min(startX.value, curX.value);
  const y = Math.min(startY.value, curY.value);
  const w = Math.abs(curX.value - startX.value);
  const h = Math.abs(curY.value - startY.value);
  return {
    left: x + "px",
    top: y + "px",
    width: w + "px",
    height: h + "px",
  };
}
</script>

<template>
  <main class="picker" @mousedown="onMouseDown">
    <!-- 全屏半透明蒙版 -->
    <div class="mask"></div>
    <!-- 十字辅助线 -->
    <div v-if="dragging" class="cross-v" :style="{ left: curX + 'px' }"></div>
    <div v-if="dragging" class="cross-h" :style="{ top: curY + 'px' }"></div>
    <!-- 选框 -->
    <div v-if="dragging || finished" class="sel-box" :style="boxStyle()">
      <span v-if="dragging" class="size-label">
        {{ Math.round(Math.abs(curX - startX)) }} × {{ Math.round(Math.abs(curY - startY)) }}
      </span>
    </div>
    <!-- 提示 -->
    <div class="tip-bar" @mousedown.stop>
      <span>{{ tipText }}</span>
      <button @click="onCancel">取消</button>
    </div>
  </main>
</template>

<style scoped>
.picker {
  position: fixed;
  inset: 0;
  background: transparent;
  overflow: hidden;
  user-select: none;
}
.mask {
  position: absolute;
  inset: 0;
  background: rgba(0, 0, 0, 0.35);
  pointer-events: none;
}
.cross-v {
  position: absolute;
  top: 0;
  bottom: 0;
  width: 1px;
  background: rgba(106, 191, 255, 0.6);
  pointer-events: none;
}
.cross-h {
  position: absolute;
  left: 0;
  right: 0;
  height: 1px;
  background: rgba(106, 191, 255, 0.6);
  pointer-events: none;
}
.sel-box {
  position: absolute;
  border: 2px solid #6abfff;
  background: rgba(106, 191, 255, 0.18);
  pointer-events: none;
}
.size-label {
  position: absolute;
  top: 4px;
  left: 4px;
  font-size: 11px;
  color: #fff;
  background: rgba(0, 0, 0, 0.6);
  padding: 1px 4px;
  border-radius: 3px;
}
.tip-bar {
  position: absolute;
  top: 12px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 6px 12px;
  background: rgba(20, 20, 42, 0.9);
  border: 1px solid var(--border);
  border-radius: 6px;
  font-size: 12px;
  color: #ccd;
}
</style>
