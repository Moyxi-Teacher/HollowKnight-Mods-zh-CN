<script setup lang="ts">
import { onMounted, onUnmounted, ref } from "vue";
import { invoke } from "@tauri-apps/api/core";
import {
  bindOpacity,
  closeSelf,
  emitOpacityChanged,
  emitSettingsSaved,
  focusSelf,
  loadSettings,
  onRegionSelected,
  openPopup,
  saveSettings,
} from "../lib/shared";
import { DEFAULT_SETTINGS, type AppSettings, type Champion, type ShopRegion } from "../types";

const draft = ref<AppSettings>({ ...DEFAULT_SETTINGS });

let unregion: (() => void) | null = null;
let unopacity: (() => void) | null = null;

// 当前正在框选的槽位：type 区分 name（OCR模式名字区域）/ card（找图模式卡牌整体区域）
// idx 0-4 对应5张卡的位置
type PickingSlot = { type: "name" | "card"; idx: number } | null;
let pickingSlot: PickingSlot = null;

// 测试匹配状态（含步进搜索的最佳 Y 轴偏移 dy）
const testing = ref(false);
const testResult = ref<{ chessId: string | null; score: number; dy: number }[] | null>(null);
const testError = ref("");

// 英雄列表（chessId → displayName 映射，用于测试结果显示英雄名而非 ID）
const champions = ref<Champion[]>([]);

/// 根据 chessId 查英雄名；未找到则返回原始 ID
function heroName(chessId: string | null): string {
  if (!chessId) return "未匹配";
  const c = champions.value.find((c) => c.chessId === chessId);
  return c?.displayName || chessId;
}

onMounted(async () => {
  await focusSelf();
  draft.value = loadSettings();
  // 加载英雄列表用于测试结果 chessId → displayName 映射
  try {
    champions.value = await invoke<Champion[]>("get_champions");
  } catch (e) {
    console.warn("加载英雄列表失败", e);
  }
  // 确保 nameRegions / cardRegions / cardOffsets 都有5个槽位
  while (draft.value.nameRegions.length < 5) {
    draft.value.nameRegions.push({ x: 0, y: 0, width: 0, height: 0 });
  }
  while (draft.value.cardRegions.length < 5) {
    draft.value.cardRegions.push({ x: 0, y: 0, width: 0, height: 0 });
  }
  while (draft.value.cardOffsets.length < 5) {
    draft.value.cardOffsets.push(0);
  }
  unopacity = await bindOpacity();
  // 监听框选结果：RegionPicker emit region-selected 事件
  unregion = await onRegionSelected((r: ShopRegion) => {
    if (pickingSlot) {
      if (pickingSlot.type === "name") {
        draft.value.nameRegions[pickingSlot.idx] = r;
      } else {
        draft.value.cardRegions[pickingSlot.idx] = r;
      }
      pickingSlot = null;
    }
  });
});
onUnmounted(() => {
  unregion?.();
  unopacity?.();
});

// 透明度实时联动所有窗口
function onOpacity(v: number) {
  draft.value.opacity = v;
  emitOpacityChanged(v);
}

// 快捷键按键录制（录制到指定字段：actionHotkey / autoHotkey / sellHotkey）
type HotkeyField = "actionHotkey" | "autoHotkey" | "sellHotkey";
let recording = false;
function recordHotkey(field: HotkeyField) {
  if (recording) return;
  recording = true;
  const handler = (e: KeyboardEvent) => {
    e.preventDefault();
    e.stopPropagation();
    let key = e.key;
    if (key === " ") key = "Space";
    if (key.length === 1) key = key.toUpperCase();
    const mods: string[] = [];
    if (e.ctrlKey) mods.push("Ctrl");
    if (e.shiftKey) mods.push("Shift");
    if (e.altKey) mods.push("Alt");
    mods.push(key);
    draft.value[field] = mods.join("+");
    recording = false;
    window.removeEventListener("keydown", handler, true);
  };
  window.addEventListener("keydown", handler, true);
}

// 开始框选某个槽位的区域。type=name=名字条带，type=card=卡牌整体
async function startRegionPick(type: "name" | "card", slot: number) {
  pickingSlot = { type, idx: slot };
  const tipText = type === "name"
    ? `框选卡牌${slot + 1}底部英雄名字区域`
    : `框选卡牌${slot + 1}整体区域（含头像+名字+费用）`;
  await openPopup({
    hash: "region",
    title: tipText,
    width: 800,
    height: 600,
    tip: tipText,
  });
}

// 判断某个槽位是否已设置（type 区分 name/card）
function hasRegion(type: "name" | "card", slot: number): boolean {
  const r = type === "name" ? draft.value.nameRegions[slot] : draft.value.cardRegions[slot];
  return r && r.width > 0 && r.height > 0;
}

// 显示区域简要信息
function regionText(type: "name" | "card", slot: number): string {
  const r = type === "name" ? draft.value.nameRegions[slot] : draft.value.cardRegions[slot];
  if (!r || r.width === 0) return "未设置";
  return `${r.x},${r.y} · ${r.width}×${r.height}`;
}

// 显示 Y 轴裁剪偏移（测试时步进搜索记录，从缓存读取）
function offsetText(slot: number): string {
  const dy = draft.value.cardOffsets[slot];
  if (dy === undefined) return "";
  return ` | 偏移 ${dy}`;
}

// 测试匹配：先把当前 draft 的卡牌区域同步到引擎，再调 test_match_with_offsets 命令。
// 步进搜索找到每张卡分数最高的裁剪偏移 (dx, dy)，保存到 draft.cardOffsets。
// 正式匹配时直接用保存的偏移，不需每次搜索。
async function testMatch() {
  testing.value = true;
  testError.value = "";
  testResult.value = null;
  try {
    // 先同步 draft 区域到引擎（仅刷新内存状态，不影响持久化 settings）
    await invoke('set_card_regions', { regions: draft.value.cardRegions });
    // 步进搜索：返回 (chessId, score, dy)
    const result = await invoke<[string | null, number, number][]>('test_match_with_offsets');
    testResult.value = result.map(([chessId, score, dy]) => ({ chessId, score, dy }));
    // 保存 Y 轴偏移到 draft（保存 settings 时写入持久化，正式匹配用）
    draft.value.cardOffsets = result.map(([, , dy]) => dy);
  } catch (e) {
    testError.value = String(e);
  } finally {
    testing.value = false;
  }
}

// 测试结果是否全部命中（5 张卡都有 chessId 且 score > 0.8）
// score 是巴氏系数 ∈ [0,1]，HSV 直方图匹配（128 bin），0.8 视为匹配成功
// 与 Main.vue 的 IMG_THRESHOLD(0.8) 和 Rust 端 MATCH_THRESHOLD(0.8) 保持一致
function testAllHit(): boolean {
  if (!testResult.value) return false;
  return testResult.value.length === 5
    && testResult.value.every(r => r.chessId && r.score > 0.8);
}

// 找图模式：所有 5 个卡牌区域都设置才允许保存
function allCardRegionsSet(): boolean {
  return draft.value.cardRegions.every(r => r.width > 0 && r.height > 0);
}

function onSave() {
  // 合并模式：OCR + 找图两种区域都必须设置
  const validNameRegions = draft.value.nameRegions.filter((r) => r.width > 0 && r.height > 0);
  const validCardRegions = draft.value.cardRegions.filter((r) => r.width > 0 && r.height > 0);
  if (validNameRegions.length !== 5) {
    alert("必须框选全部 5 个卡牌名字区域（OCR 用）");
    return;
  }
  if (validCardRegions.length !== 5) {
    alert("必须框选全部 5 个卡牌整体区域（找图用）");
    return;
  }
  if (!testAllHit()) {
    alert("找图测试必须通过（5 张卡都正确识别）才允许保存");
    return;
  }
  const settings = { ...draft.value, nameRegions: validNameRegions, cardRegions: validCardRegions };
  saveSettings(settings);
  emitSettingsSaved(settings);
  closeSelf();
}
</script>

<template>
  <main class="win">
    <header class="head" data-tauri-drag-region>
      <span class="title">设置</span>
      <button class="close" @click="closeSelf">×</button>
    </header>
    <section class="body">
      <div class="section">窗口透明度</div>
      <div class="row">
        <input
          type="range"
          min="0.3"
          max="1"
          step="0.05"
          :value="draft.opacity"
          @input="onOpacity(Number(($event.target as HTMLInputElement).value))"
          class="slider"
        />
        <span class="val">{{ Math.round(draft.opacity * 100) }}%</span>
      </div>

      <div class="section">卡牌名字区域（OCR 用，依次框选5个卡牌底部的英雄名字）</div>
      <div v-for="i in 5" :key="`name-${i}`" class="row region-row">
        <span class="label">卡牌{{ i }}：</span>
        <span class="region-val" :class="{ none: !hasRegion('name', i - 1) }">
          {{ regionText('name', i - 1) }}
        </span>
        <button class="pick-btn" @click="startRegionPick('name', i - 1)">
          {{ hasRegion('name', i - 1) ? '重选' : '框选' }}
        </button>
      </div>

      <div class="section">卡牌整体区域（找图用，依次框选5张卡，含头像+名字+费用）</div>
      <div v-for="i in 5" :key="`card-${i}`" class="row region-row">
        <span class="label">卡牌{{ i }}：</span>
        <span class="region-val" :class="{ none: !hasRegion('card', i - 1) }">
          {{ regionText('card', i - 1) }}{{ offsetText(i - 1) }}
        </span>
        <button class="pick-btn" @click="startRegionPick('card', i - 1)">
          {{ hasRegion('card', i - 1) ? '重选' : '框选' }}
        </button>
      </div>
      <div class="row test-row">
        <button class="test-btn" :class="{ testing }" @click="testMatch" :disabled="!allCardRegionsSet() || testing">
          {{ testing ? '测试中...' : '测试匹配' }}
        </button>
        <span v-if="testError" class="test-error">{{ testError }}</span>
      </div>
      <div v-if="testResult" class="test-result">
        <div class="test-summary" :class="{ ok: testAllHit(), fail: !testAllHit() }">
          {{ testAllHit() ? '✓ 5 张卡全部正确识别' : '✗ 未全部正确，请调整框选' }}
        </div>
        <div v-for="(r, i) in testResult" :key="`test-${i}`" class="test-item">
          <span class="test-idx">卡{{ i + 1 }}:</span>
          <span class="test-id" :class="{ hit: r.chessId, miss: !r.chessId }" :title="r.chessId || ''">
            {{ heroName(r.chessId) }}
          </span>
          <span class="test-score" :class="{ ok: r.score > 0.8 }">
              {{ r.score.toFixed(4) }}
            </span>
        </div>
      </div>

      <div class="section">动作快捷键</div>
      <div class="row">
        <span class="label">刷新+检测：</span>
        <input
          type="text"
          :value="draft.actionHotkey"
          readonly
          class="hotkey-input"
          @click="recordHotkey('actionHotkey')"
          placeholder="点击录制"
        />
        <span class="tip">手动模式：按一次 = 刷新商店 + 检测一次</span>
      </div>
      <div class="row">
        <span class="label">自动开关：</span>
        <input
          type="text"
          :value="draft.autoHotkey"
          readonly
          class="hotkey-input"
          @click="recordHotkey('autoHotkey')"
          placeholder="点击录制"
        />
        <span class="tip">按下 = 开启/关闭自动循环检测</span>
      </div>
      <div class="row">
        <span class="label">一键卖出：</span>
        <input
          type="text"
          :value="draft.sellHotkey"
          readonly
          class="hotkey-input"
          @click="recordHotkey('sellHotkey')"
          placeholder="点击录制"
        />
        <span class="tip">按下 = 截图+YOLO识别+按E卖出</span>
      </div>
    </section>
    <footer class="foot">
      <button @click="closeSelf">取消</button>
      <button class="primary" @click="onSave">保存</button>
    </footer>
  </main>
</template>

<style scoped>
.win {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
}
.head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  background: rgba(20, 20, 42, calc(var(--win-alpha) * 1.1));
  border-bottom: 1px solid var(--border);
}
.title {
  font-size: 13px;
  font-weight: 600;
}
.close {
  background: transparent;
  border: none;
  font-size: 18px;
  color: #9aa;
}
.close:hover {
  color: #ff6b6b;
}
.body {
  flex: 1;
  padding: 10px 14px;
  overflow-y: auto;
}
.section {
  font-size: 12px;
  color: #9aa;
  margin: 14px 0 6px;
  padding-top: 10px;
  border-top: 1px solid var(--border);
}
.section:first-child {
  margin-top: 0;
  border-top: none;
  padding-top: 0;
}
.row {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
  margin-bottom: 8px;
}
.label {
  width: 70px;
  color: #ccd;
}
.slider {
  flex: 1;
}
.val {
  width: 50px;
  color: #ffd76b;
  font-size: 12px;
}
.region-row {
  margin-bottom: 6px;
}
.region-val {
  flex: 1;
  font-size: 12px;
  color: #9aa;
}
.region-val.none {
  color: #666;
}
.pick-btn {
  padding: 3px 10px;
  font-size: 12px;
}
.hotkey-input {
  width: 140px;
  cursor: pointer;
  text-align: center;
  padding: 4px 8px;
}
.tip {
  font-size: 11px;
  color: #777;
}
.foot {
  padding: 10px 14px;
  border-top: 1px solid var(--border);
  display: flex;
  justify-content: flex-end;
  gap: 8px;
}
.primary {
  background: #4a6cf7;
  border-color: #4a6cf7;
  color: #fff;
}

/* 测试匹配 */
.test-row {
  margin-top: 10px;
  margin-bottom: 8px;
}
.test-btn {
  padding: 4px 14px;
  font-size: 12px;
  background: #2a5a8a;
  border-color: #2a5a8a;
  color: #fff;
}
.test-btn:disabled {
  background: #333;
  border-color: #333;
  color: #666;
  cursor: not-allowed;
}
.test-btn.testing {
  background: #5a2a2a;
  border-color: #ff6b6b;
  color: #ff6b6b;
  cursor: wait;
}
.test-error {
  color: #ff6b6b;
  font-size: 11px;
  margin-left: 8px;
}
.test-result {
  margin: 8px 0 12px;
  padding: 8px 10px;
  background: rgba(20, 20, 42, 0.6);
  border: 1px solid var(--border);
  border-radius: 6px;
  font-size: 12px;
}
.test-summary {
  font-weight: 600;
  margin-bottom: 6px;
  padding-bottom: 4px;
  border-bottom: 1px solid var(--border);
}
.test-summary.ok { color: #6bff8a; }
.test-summary.fail { color: #ff8a6b; }
.test-item {
  display: flex;
  gap: 10px;
  padding: 2px 0;
  font-size: 11px;
}
.test-idx {
  width: 36px;
  color: #9aa;
}
.test-id {
  flex: 1;
  font-family: monospace;
}
.test-id.hit { color: #6bff8a; }
.test-id.miss { color: #ff6b6b; }
.test-score {
  width: 60px;
  text-align: right;
  color: #ffd76b;
}
.test-score.ok { color: #6bff8a; }
</style>
