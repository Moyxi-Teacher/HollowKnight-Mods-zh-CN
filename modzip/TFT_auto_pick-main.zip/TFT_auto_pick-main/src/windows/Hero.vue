<script setup lang="ts">
import { invoke } from "@tauri-apps/api/core";
import { computed, onMounted, onUnmounted, ref, watch } from "vue";
import {
  bindOpacity,
  closeSelf,
  emitApplyPicks,
  focusSelf,
  loadMode,
  onModeChanged,
} from "../lib/shared";
import { heroImage, type Champion, type CustomPickItem, type GameMode } from "../types";

const champions = ref<Champion[]>([]);
const loading = ref(false);
const errorMsg = ref("");
const gameMode = ref<GameMode>(loadMode());

// 当前选中的费用 tab：5/4/3/2/1
const activePrice = ref<number>(5);
const selectedIds = ref<Set<string>>(new Set());

const priceTabs = [5, 4, 3, 2, 1];

const grouped = computed(() => {
  const map: Record<number, Champion[]> = {};
  for (const c of champions.value) {
    // 5费以上的英雄归入5费分类
    const p = Math.min(Number(c.price), 5);
    if (!map[p]) map[p] = [];
    map[p].push(c);
  }
  return map;
});

const currentList = computed(() => grouped.value[activePrice.value] ?? []);

const selectedCount = computed(() => selectedIds.value.size);

async function loadChampions() {
  loading.value = true;
  errorMsg.value = "";
  try {
    champions.value = await invoke<Champion[]>("get_champions");
    // 若当前 tab 无英雄，切到第一个有英雄的 tab
    if ((grouped.value[activePrice.value] ?? []).length === 0) {
      for (const p of priceTabs) {
        if ((grouped.value[p] ?? []).length > 0) {
          activePrice.value = p;
          break;
        }
      }
    }
  } catch (e) {
    errorMsg.value = String(e);
  } finally {
    loading.value = false;
  }
}

function toggle(chessId: string) {
  const s = new Set(selectedIds.value);
  if (s.has(chessId)) s.delete(chessId);
  else s.add(chessId);
  selectedIds.value = s;
}

function onConfirm() {
  const items: CustomPickItem[] = champions.value
    .filter((c) => selectedIds.value.has(c.chessId))
    .map((c) => ({
      chessId: c.chessId,
      name: c.displayName,
      price: Number(c.price),
      image: heroImage(c.chessId),
    }));
  emitApplyPicks(items);
  closeSelf();
}

let unmode: (() => void) | null = null;
let unopacity: (() => void) | null = null;
onMounted(async () => {
  await focusSelf();
  unopacity = await bindOpacity();
  await loadChampions();
  unmode = await onModeChanged((m) => {
    gameMode.value = m;
    selectedIds.value = new Set();
    loadChampions();
  });
});
onUnmounted(() => {
  unmode?.();
  unopacity?.();
});
</script>

<template>
  <main class="win">
    <header class="head" data-tauri-drag-region>
      <span class="title">选择英雄 · {{ gameMode.name }}</span>
      <button class="close" @click="closeSelf">×</button>
    </header>

    <!-- 费用 tab 选项卡 -->
    <nav class="tabs">
      <button
        v-for="p in priceTabs"
        :key="p"
        class="tab"
        :class="{ active: activePrice === p, [`cost-${p}`]: activePrice === p }"
        @click="activePrice = p"
      >
        {{ p }}费
        <span class="cnt">{{ (grouped[p] ?? []).length }}</span>
      </button>
    </nav>

    <p v-if="errorMsg" class="err">{{ errorMsg }}</p>

    <section class="body">
      <div v-if="loading" class="hint">加载中...</div>
      <div v-else class="hero-grid">
        <button
          v-for="c in currentList"
          :key="c.chessId"
          class="hero-cell"
          :class="{ selected: selectedIds.has(c.chessId) }"
          @click="toggle(c.chessId)"
        >
          <img :src="heroImage(c.chessId)" :alt="c.displayName" />
          <span class="hero-name">{{ c.displayName }}</span>
        </button>
        <div v-if="!loading && currentList.length === 0" class="hint">无英雄</div>
      </div>
    </section>

    <footer class="foot">
      <span class="count">已选 {{ selectedCount }}</span>
      <button class="primary" @click="onConfirm" :disabled="selectedCount === 0">
        完成
      </button>
    </footer>
  </main>
</template>

<style scoped>
.win {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
}
.head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  background: rgba(20, 20, 42, calc(var(--win-alpha) * 1.1));
  border-bottom: 1px solid var(--border);
}
.title {
  font-size: 13px;
  font-weight: 600;
}
.close {
  background: transparent;
  border: none;
  font-size: 18px;
  color: #9aa;
}
.close:hover {
  color: #ff6b6b;
}
.tabs {
  display: flex;
  gap: 4px;
  padding: 8px 12px 0;
}
.tab {
  flex: 1;
  padding: 6px 4px;
  background: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: 6px 6px 0 0;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
}
.tab.active {
  background: rgba(74, 108, 247, var(--win-alpha));
  border-color: #4a6cf7;
  color: #fff;
}
.tab.active.cost-1 { border-color: #6b8b9a; }
.tab.active.cost-2 { border-color: #6ba86b; }
.tab.active.cost-3 { border-color: #6b8bf7; }
.tab.active.cost-4 { border-color: #b86bf7; }
.tab.active.cost-5 { border-color: #ffb86b; }
.cnt {
  font-size: 10px;
  opacity: 0.7;
}
.err {
  color: #ff6b6b;
  font-size: 12px;
  margin: 6px 12px;
}
.body {
  flex: 1;
  padding: 10px 12px;
  overflow-y: auto;
}
.hint {
  color: #777;
  text-align: center;
  padding: 30px 0;
  font-size: 13px;
}
.hero-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(70px, 1fr));
  gap: 6px;
}
.hero-cell {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 6px 2px;
  background: var(--bg-input);
  border: 2px solid transparent;
  border-radius: 6px;
}
.hero-cell:hover {
  background: rgba(58, 58, 90, var(--win-alpha));
}
.hero-cell.selected {
  border-color: #6bff9a;
  background: rgba(42, 74, 42, var(--win-alpha));
}
.hero-cell img {
  width: 48px;
  height: 48px;
  border-radius: 6px;
}
.hero-name {
  font-size: 11px;
  margin-top: 3px;
  max-width: 64px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.foot {
  padding: 10px 12px;
  border-top: 1px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.count {
  font-size: 12px;
  color: #9aa;
}
.primary {
  background: #4a6cf7;
  border-color: #4a6cf7;
  color: #fff;
}
</style>
