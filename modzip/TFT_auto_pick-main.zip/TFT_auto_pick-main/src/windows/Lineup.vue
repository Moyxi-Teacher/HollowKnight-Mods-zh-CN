<script setup lang="ts">
import { invoke } from "@tauri-apps/api/core";
import { computed, onMounted, onUnmounted, ref, watch } from "vue";
import {
  bindOpacity,
  closeSelf,
  emitApplyPicks,
  focusSelf,
  loadMode,
  onModeChanged,
} from "../lib/shared";
import { heroImage, type Champion, type CustomPickItem, type GameMode, type LineupBrief, type PickCard } from "../types";

const allLineups = ref<LineupBrief[]>([]);
const selectedLineup = ref("");
const selectedStage = ref(2);
const pickList = ref<PickCard[]>([]);
const loading = ref(false);
const errorMsg = ref("");
const gameMode = ref<GameMode>(loadMode());

// 英雄表（按费筛选供用户选择）
const champions = ref<Champion[]>([]);

// ============ 指定英雄搜索阵容 ============
const priceTabs = [5, 4, 3, 2, 1];
const searchPrice = ref<number>(5);       // 当前选中的费用 tab
const searchHeroId = ref<string>("");      // 下拉选中的英雄 chessId
const filterHeroId = ref<string>("");      // 实际生效的筛选英雄（点【搜索阵容】后赋值）

// 当前费用下的英雄列表（5费以上归入5费）
const priceHeroes = computed(() =>
  champions.value.filter((c) => Math.min(Number(c.price), 5) === searchPrice.value)
);

// 展示的阵容：有筛选则只留"后期(pick_stages[2])含该英雄"的，否则全部
const displayLineups = computed(() => {
  if (!filterHeroId.value) return allLineups.value;
  return allLineups.value.filter((l) => (l.pick_stages[2] ?? []).includes(filterHeroId.value));
});

const filterHeroName = computed(
  () => champions.value.find((c) => c.chessId === filterHeroId.value)?.displayName ?? ""
);

async function loadChampions() {
  let lastErr = "";
  for (let i = 0; i < 10; i++) {
    try {
      champions.value = await invoke<Champion[]>("get_champions");
      return;
    } catch (e) {
      lastErr = String(e);
      await new Promise((r) => setTimeout(r, 500));
    }
  }
  // 英雄表非关键路径，失败不阻塞阵容加载
  console.warn("英雄表加载失败", lastErr);
}

async function loadLineups() {
  loading.value = true;
  errorMsg.value = "";
  // 切换模式/重载时清空搜索状态
  searchHeroId.value = "";
  filterHeroId.value = "";
  try {
    // 刚进程序时主窗 refresh 可能尚未完成，自动重试
    let lastErr = "";
    for (let i = 0; i < 10; i++) {
      try {
        allLineups.value = await invoke<LineupBrief[]>("get_lineups");
        break;
      } catch (e) {
        lastErr = String(e);
        await new Promise((r) => setTimeout(r, 500));
      }
    }
    if (allLineups.value.length === 0) {
      errorMsg.value = lastErr || "无阵容数据";
    } else {
      selectedLineup.value = allLineups.value[0].id;
      await loadPreview();
    }
  } catch (e) {
    errorMsg.value = String(e);
  } finally {
    loading.value = false;
  }
}

async function loadPreview() {
  if (!selectedLineup.value) return;
  loading.value = true;
  try {
    pickList.value = await invoke<PickCard[]>("get_pick_list", {
      lineupId: selectedLineup.value,
      stage: selectedStage.value,
    });
  } catch (e) {
    errorMsg.value = String(e);
  } finally {
    loading.value = false;
  }
}

function onPriceChange(p: number) {
  searchPrice.value = p;
  searchHeroId.value = ""; // 切费清空已选英雄
}

function onSearch() {
  filterHeroId.value = searchHeroId.value;
}

function onReset() {
  searchHeroId.value = "";
  filterHeroId.value = "";
}

function onApply() {
  const items: CustomPickItem[] = pickList.value.map((c) => ({
    chessId: c.chess_id,
    name: c.name,
    price: c.price,
    image: heroImage(c.chess_id),
  }));
  emitApplyPicks(items);
  closeSelf();
}

let unmode: (() => void) | null = null;
let unopacity: (() => void) | null = null;
onMounted(async () => {
  await focusSelf();
  unopacity = await bindOpacity();
  await loadChampions();
  await loadLineups();
  // 主窗口切换模式时，重新加载阵容（与主窗联动）
  unmode = await onModeChanged((m) => {
    gameMode.value = m;
    loadLineups();
  });
});
onUnmounted(() => {
  unmode?.();
  unopacity?.();
});

watch(selectedLineup, () => loadPreview());
watch(selectedStage, () => loadPreview());
// 筛选后若当前选中阵容不在列表里，自动切到第一个
watch(displayLineups, (list) => {
  if (list.length === 0) {
    selectedLineup.value = "";
    return;
  }
  if (!list.some((l) => l.id === selectedLineup.value)) {
    selectedLineup.value = list[0].id;
  }
});
</script>

<template>
  <main class="win">
    <header class="head" data-tauri-drag-region>
      <span class="title">阵容推荐 · {{ gameMode.name }}</span>
      <button class="close" @click="closeSelf">×</button>
    </header>
    <section class="body">
      <div class="row">
        <select v-model="selectedLineup" class="flex1">
          <option v-for="l in displayLineups" :key="l.id" :value="l.id">
            [{{ l.quality }}] {{ l.line_name }}
          </option>
        </select>
        <select v-model.number="selectedStage">
          <option :value="0">早期</option>
          <option :value="1">中期</option>
          <option :value="2">后期</option>
        </select>
      </div>
      <p v-if="errorMsg" class="err">{{ errorMsg }}</p>
      <div class="preview">
        <div v-if="loading" class="hint">加载中...</div>
        <div v-else-if="pickList.length === 0" class="hint">无拿牌数据</div>
        <div v-else class="grid">
          <div v-for="c in pickList" :key="c.chess_id" class="card" :class="`cost-${c.price}`">
            <img :src="heroImage(c.chess_id)" :alt="c.name" />
            <span class="name">{{ c.name }}</span>
            <span class="price">{{ c.price }}费</span>
            <span v-if="c.is_new" class="badge">新</span>
          </div>
        </div>
      </div>

      <!-- 指定英雄搜索阵容 -->
      <div class="search-area">
        <div class="search-title">指定英雄搜索阵容（按后期阵容匹配）</div>
        <div class="search-row">
          <div class="price-tabs">
            <button
              v-for="p in priceTabs"
              :key="p"
              class="price-tab"
              :class="[`cost-${p}`, { active: searchPrice === p }]"
              @click="onPriceChange(p)"
            >
              {{ p }}费
            </button>
          </div>
          <select v-model="searchHeroId" class="hero-select" :disabled="priceHeroes.length === 0">
            <option value="">请选择英雄</option>
            <option v-for="c in priceHeroes" :key="c.chessId" :value="c.chessId">
              {{ c.displayName }}
            </option>
          </select>
          <button class="btn-search" @click="onSearch" :disabled="!searchHeroId">搜索阵容</button>
          <button class="btn-all" @click="onReset" :disabled="!filterHeroId">全部</button>
        </div>
        <div v-if="filterHeroId" class="filter-hint">
          已筛选后期含「{{ filterHeroName }}」的阵容 · 共 {{ displayLineups.length }} 个
        </div>
      </div>
    </section>
    <footer class="foot">
      <button class="primary" @click="onApply" :disabled="pickList.length === 0">
        一键应用到拿牌区
      </button>
    </footer>
  </main>
</template>

<style scoped>
.win {
  display: flex;
  flex-direction: column;
  height: 100vh;
  background: var(--bg-elevated);
  border: 1px solid var(--border);
  border-radius: 10px;
  overflow: hidden;
}
.head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  background: rgba(20, 20, 42, calc(var(--win-alpha) * 1.1));
  border-bottom: 1px solid var(--border);
}
.title {
  font-size: 13px;
  font-weight: 600;
}
.close {
  background: transparent;
  border: none;
  font-size: 18px;
  color: #9aa;
  padding: 0 4px;
}
.close:hover {
  color: #ff6b6b;
}
.body {
  flex: 1;
  padding: 10px 12px;
  overflow-y: auto;
}
.row {
  display: flex;
  gap: 8px;
  margin-bottom: 10px;
}
.row select {
  padding: 5px 8px;
  font-size: 12px;
}
.flex1 {
  flex: 1;
}
.hint {
  color: #777;
  font-size: 13px;
  text-align: center;
  padding: 30px 0;
}
.grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 6px;
}
.card {
  display: flex;
  flex-direction: column;
  align-items: center;
  background: var(--bg-input);
  border: 1px solid var(--border);
  border-radius: 6px;
  padding: 6px 4px;
  font-size: 12px;
  position: relative;
}
.card img {
  width: 44px;
  height: 44px;
  border-radius: 6px;
  margin-bottom: 3px;
}
.price {
  color: #ffd76b;
  font-size: 11px;
}
.badge {
  position: absolute;
  top: 3px;
  right: 3px;
  background: #6bff9a;
  color: #1a1a2e;
  font-size: 10px;
  padding: 0 4px;
  border-radius: 3px;
}
.cost-1 { border-color: #6b8b9a; }
.cost-2 { border-color: #6ba86b; }
.cost-3 { border-color: #6b8bf7; }
.cost-4 { border-color: #b86bf7; }
.cost-5 { border-color: #ffb86b; }

/* ============ 指定英雄搜索区 ============ */
.search-area {
  margin-top: 14px;
  padding-top: 12px;
  border-top: 1px dashed var(--border);
}
.search-title {
  font-size: 12px;
  color: #9aa;
  margin-bottom: 8px;
}
.search-row {
  display: flex;
  gap: 6px;
  align-items: center;
  flex-wrap: wrap;
}
.price-tabs {
  display: flex;
  gap: 3px;
}
.price-tab {
  padding: 3px 9px;
  font-size: 11px;
  border-radius: 4px;
  border: 1px solid var(--border);
  background: transparent;
  color: #9aa;
  cursor: pointer;
}
.price-tab.active {
  color: #fff;
  font-weight: 600;
}
.price-tab.cost-1.active { border-color: #6b8b9a; background: rgba(107, 139, 154, 0.35); }
.price-tab.cost-2.active { border-color: #6ba86b; background: rgba(107, 168, 107, 0.35); }
.price-tab.cost-3.active { border-color: #6b8bf7; background: rgba(107, 139, 247, 0.35); }
.price-tab.cost-4.active { border-color: #b86bf7; background: rgba(184, 107, 247, 0.35); }
.price-tab.cost-5.active { border-color: #ffb86b; background: rgba(255, 184, 107, 0.35); }
.hero-select {
  padding: 4px 8px;
  font-size: 12px;
  min-width: 120px;
}
.btn-search {
  padding: 4px 10px;
  font-size: 12px;
  background: #4a6cf7;
  border-color: #4a6cf7;
  color: #fff;
}
.btn-search:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.btn-all {
  padding: 4px 10px;
  font-size: 12px;
  background: transparent;
  color: #9aa;
}
.btn-all:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}
.filter-hint {
  margin-top: 8px;
  font-size: 11px;
  color: #6bff9a;
  padding: 3px 8px;
  background: rgba(40, 70, 40, 0.5);
  border: 1px solid #2a5a2a;
  border-radius: 4px;
  display: inline-block;
}
.foot {
  padding: 10px 12px;
  border-top: 1px solid var(--border);
  display: flex;
  justify-content: flex-end;
}
.primary {
  background: #4a6cf7;
  border-color: #4a6cf7;
  color: #fff;
}
.err {
  color: #ff6b6b;
  font-size: 12px;
}
</style>
