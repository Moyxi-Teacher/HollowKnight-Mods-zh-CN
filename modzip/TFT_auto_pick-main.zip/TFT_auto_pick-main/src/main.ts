import { createApp } from "vue";
import "./style.css";
import Main from "./windows/Main.vue";

// 按 hash 路由选择窗口组件（同一 index.html 入口，多窗口复用）
// 主窗口: 无 hash；弹窗: #/lineup #/hero #/settings #/region?tip=...
// region 路由支持 ?tip=<encoded> query string，由 RegionPicker 解析显示自定义提示文案
function pickComponent() {
  const hash = window.location.hash.replace(/^#\/?/, "");
  const route = hash.split("?")[0]; // 去掉 query string 后的路由名
  switch (route) {
    case "lineup":
      return import("./windows/Lineup.vue").then((m) => m.default);
    case "hero":
      return import("./windows/Hero.vue").then((m) => m.default);
    case "settings":
      return import("./windows/Settings.vue").then((m) => m.default);
    case "region":
      return import("./windows/RegionPicker.vue").then((m) => m.default);
    default:
      return Promise.resolve(Main);
  }
}

pickComponent().then((App) => {
  createApp(App).mount("#app");
});
