using System;
using System.Collections.Generic;
using Hkmp.Logging;
using Hkmp.Networking.Packet.Connection;
using Hkmp.Networking.Packet.Data;
using Hkmp.Networking.Packet.Update;
using Hkmp.Util;

namespace Hkmp.Networking.Packet;

/// <summary>
/// Delegate for client packet handlers.
/// </summary>
internal delegate void ClientPacketHandler(IPacketData packet);

/// <summary>
/// Generic client packet handler delegate that has a IPacketData implementation as parameter.
/// </summary>
/// <typeparam name="TPacketData">The type of the packet data that is passed as parameter.</typeparam>
public delegate void GenericClientPacketHandler<in TPacketData>(TPacketData packet) where TPacketData : IPacketData;

/// <summary>
/// Packet handler that only has the client ID as parameter and does not use the packet data.
/// </summary>
internal delegate void EmptyServerPacketHandler(ushort id);

/// <summary>
/// Packet handler for the server that has the client ID and packet data as parameters.
/// </summary>
internal delegate void ServerPacketHandler(ushort id, IPacketData packet);

/// <summary>
/// Generic server packet handler delegate that has a IPacketData implementation and client ID as parameter.
/// </summary>
/// <typeparam name="TPacketData">The type of the packet data that is passed as parameter.</typeparam>
public delegate void GenericServerPacketHandler<in TPacketData>(ushort id, TPacketData packet)
    where TPacketData : IPacketData;

/// <summary>
/// Manages packets that are received by the given NetClient.
/// </summary>
internal class PacketManager {
    /// <summary>
    /// Handlers that deal with update packet data from the server intended for the client.
    /// </summary>
    private readonly Dictionary<ClientUpdatePacketId, ClientPacketHandler> _clientUpdatePacketHandlers;

    /// <summary>
    /// Handlers that deal with connection packet data from the server intended for the client.
    /// </summary>
    private readonly Dictionary<ClientConnectionPacketId, ClientPacketHandler> _clientConnectionPacketHandlers;

    /// <summary>
    /// Handlers that deal with update packet data from the client intended for the server.
    /// </summary>
    private readonly Dictionary<ServerUpdatePacketId, ServerPacketHandler> _serverUpdatePacketHandlers;
    
    /// <summary>
    /// Handlers that deal with connection packet data from the client intended for the server.
    /// </summary>
    private readonly Dictionary<ServerConnectionPacketId, ServerPacketHandler> _serverConnectionPacketHandlers;

    /// <summary>
    /// Handlers that deal with client addon update packet data from the server intended for the client.
    /// </summary>
    private readonly Dictionary<byte, Dictionary<byte, ClientPacketHandler>> _clientAddonUpdatePacketHandlers;
    
    /// <summary>
    /// Handlers that deal with client addon connection packet data from the server intended for the client.
    /// </summary>
    private readonly Dictionary<byte, Dictionary<byte, ClientPacketHandler>> _clientAddonConnectionPacketHandlers;

    /// <summary>
    /// Handlers that deal with server addon update packet data from a client intended for the server.
    /// </summary>
    private readonly Dictionary<byte, Dictionary<byte, ServerPacketHandler>> _serverAddonUpdatePacketHandlers;
    
    /// <summary>
    /// Handlers that deal with server addon connection packet data from a client intended for the server.
    /// </summary>
    private readonly Dictionary<byte, Dictionary<byte, ServerPacketHandler>> _serverAddonConnectionPacketHandlers;

    public PacketManager() {
        _clientUpdatePacketHandlers = new Dictionary<ClientUpdatePacketId, ClientPacketHandler>();
        _clientConnectionPacketHandlers = new Dictionary<ClientConnectionPacketId, ClientPacketHandler>();

        _serverUpdatePacketHandlers = new Dictionary<ServerUpdatePacketId, ServerPacketHandler>();
        _serverConnectionPacketHandlers = new Dictionary<ServerConnectionPacketId, ServerPacketHandler>();

        _clientAddonUpdatePacketHandlers = new Dictionary<byte, Dictionary<byte, ClientPacketHandler>>();
        _clientAddonConnectionPacketHandlers = new Dictionary<byte, Dictionary<byte, ClientPacketHandler>>();

        _serverAddonUpdatePacketHandlers = new Dictionary<byte, Dictionary<byte, ServerPacketHandler>>();
        _serverAddonConnectionPacketHandlers = new Dictionary<byte, Dictionary<byte, ServerPacketHandler>>();
    }

    #region Client-related update packet handling

    /// <summary>
    /// Handle data received by a client.
    /// </summary>
    /// <param name="packet">The client update packet to handle.</param>
    public void HandleClientUpdatePacket(ClientUpdatePacket packet) {
        // Execute corresponding packet handlers for normal packet data
        UnpackPacketDataDict(packet.GetPacketData(), ExecuteClientUpdatePacketHandler);

        // Execute corresponding packet handlers for addon packet data of each addon in the packet
        foreach (var idPacketDataPair in packet.GetAddonPacketData()) {
            var addonId = idPacketDataPair.Key;
            var packetDataDict = idPacketDataPair.Value.PacketData;

            UnpackPacketDataDict(
                packetDataDict,
                (packetId, packetData) => ExecuteClientAddonUpdatePacketHandler(addonId, packetId, packetData)
            );
        }
    }

    /// <summary>
    /// Executes the correct packet handler corresponding to this update packet data.
    /// </summary>
    /// <param name="packetId">The client packet ID for this data.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteClientUpdatePacketHandler(ClientUpdatePacketId packetId, IPacketData packetData) {
        if (!_clientUpdatePacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Error($"There is no client update packet handler registered for ID: {packetId}");
            return;
        }

        // Invoke the packet handler for this ID on the Unity main thread
        ThreadUtil.RunActionOnMainThread(() => {
            try {
                handler.Invoke(packetData);
            } catch (Exception e) {
                Logger.Error($"Exception occured while executing client packet handler for packet ID {packetId}:\n{e}");
            }
        });
    }

    /// <summary>
    /// Register an update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    private void RegisterClientUpdatePacketHandler(
        ClientUpdatePacketId packetId,
        ClientPacketHandler handler
    ) {
        if (_clientUpdatePacketHandlers.ContainsKey(packetId)) {
            Logger.Warn($"Tried to register already existing client packet handler: {packetId}");
            return;
        }

        _clientUpdatePacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// Register a data-independent update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    public void RegisterClientUpdatePacketHandler(
        ClientUpdatePacketId packetId,
        Action handler
    ) => RegisterClientUpdatePacketHandler(packetId, _ => handler());

    /// <summary>
    /// Register an update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <typeparam name="T">The type of the packet data passed as parameter to the handler.</typeparam>
    public void RegisterClientUpdatePacketHandler<T>(
        ClientUpdatePacketId packetId,
        GenericClientPacketHandler<T> handler
    ) where T : IPacketData => RegisterClientUpdatePacketHandler(packetId, iPacket => handler((T) iPacket));

    /// <summary>
    /// De-register an update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    public void DeregisterClientUpdatePacketHandler(ClientUpdatePacketId packetId) {
        if (!_clientUpdatePacketHandlers.Remove(packetId)) {
            Logger.Warn($"Tried to remove nonexistent client packet handler: {packetId}");
        }
    }

    #endregion

    #region Client-related connection packet handling

    /// <summary>
    /// Handle connection packet data received by a client.
    /// </summary>
    /// <param name="packet">The client connection packet to handle.</param>
    public void HandleClientConnectionPacket(ClientConnectionPacket packet) {
        // Execute corresponding packet handlers for normal packet data
        UnpackPacketDataDict(packet.GetPacketData(), ExecuteClientConnectionPacketHandler);

        // Execute corresponding packet handlers for addon packet data of each addon in the packet
        foreach (var idPacketDataPair in packet.GetAddonPacketData()) {
            var addonId = idPacketDataPair.Key;
            var packetDataDict = idPacketDataPair.Value.PacketData;

            UnpackPacketDataDict(
                packetDataDict,
                (packetId, packetData) => ExecuteClientAddonConnectionPacketHandler(addonId, packetId, packetData)
            );
        }
    }

    /// <summary>
    /// Executes the correct packet handler corresponding to this connection packet data.
    /// </summary>
    /// <param name="packetId">The client packet ID for this data.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteClientConnectionPacketHandler(ClientConnectionPacketId packetId, IPacketData packetData) {
        if (!_clientConnectionPacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Error($"There is no client connection packet handler registered for ID: {packetId}");
            return;
        }

        // Invoke the packet handler for this ID on the Unity main thread
        ThreadUtil.RunActionOnMainThread(() => {
            try {
                handler.Invoke(packetData);
            } catch (Exception e) {
                Logger.Error($"Exception occured while executing client packet handler for packet ID {packetId}:\n{e}");
            }
        });
    }

    /// <summary>
    /// Register a connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    private void RegisterClientConnectionPacketHandler(
        ClientConnectionPacketId packetId,
        ClientPacketHandler handler
    ) {
        if (_clientConnectionPacketHandlers.ContainsKey(packetId)) {
            Logger.Warn($"Tried to register already existing client connection packet handler: {packetId}");
            return;
        }

        _clientConnectionPacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// Register a data-independent connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    public void RegisterClientConnectionPacketHandler(
        ClientConnectionPacketId packetId,
        Action handler
    ) => RegisterClientConnectionPacketHandler(packetId, _ => handler());

    /// <summary>
    /// Register a connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <typeparam name="T">The type of the packet data passed as parameter to the handler.</typeparam>
    public void RegisterClientConnectionPacketHandler<T>(
        ClientConnectionPacketId packetId,
        GenericClientPacketHandler<T> handler
    ) where T : IPacketData => RegisterClientConnectionPacketHandler(packetId, iPacket => handler((T) iPacket));

    /// <summary>
    /// De-register a connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The client packet ID.</param>
    public void DeregisterClientConnectionPacketHandler(ClientConnectionPacketId packetId) {
        if (!_clientConnectionPacketHandlers.Remove(packetId)) {
            Logger.Warn($"Tried to remove nonexistent client connection packet handler: {packetId}");
        }
    }

    #endregion
    
    #region Server-related update packet handling

    /// <summary>
    /// Handle update data received by the server.
    /// </summary>
    /// <param name="id">The ID of the client that sent the packet.</param>
    /// <param name="packet">The server update packet.</param>
    public void HandleServerUpdatePacket(ushort id, ServerUpdatePacket packet) {
        // Execute corresponding packet handlers
        UnpackPacketDataDict(
            packet.GetPacketData(),
            (packetId, packetData) => ExecuteServerUpdatePacketHandler(id, packetId, packetData)
        );

        // Execute corresponding packet handler for addon packet data of each addon in the packet
        foreach (var idPacketDataPair in packet.GetAddonPacketData()) {
            var addonId = idPacketDataPair.Key;
            var packetDataDict = idPacketDataPair.Value.PacketData;

            UnpackPacketDataDict(
                packetDataDict,
                (packetId, packetData) => ExecuteServerAddonUpdatePacketHandler(
                    id,
                    addonId,
                    packetId,
                    packetData
                )
            );
        }
    }

    /// <summary>
    /// Executes the correct update packet handler corresponding to this packet data.
    /// </summary>
    /// <param name="id">The ID of the client that sent the data.</param>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteServerUpdatePacketHandler(ushort id, ServerUpdatePacketId packetId, IPacketData packetData) {
        if (!_serverUpdatePacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Warn($"There is no server update packet handler registered for ID: {packetId}");
            return;
        }

        // Invoke the packet handler for this ID directly, in contrast to the client packet handling.
        // We don't do anything game specific with server packet handler, so there's no need to do it
        // on the Unity main thread
        try {
            handler.Invoke(id, packetData);
        } catch (Exception e) {
            Logger.Error($"Exception occured while executing server update packet handler for packet ID {packetId}:\n{e}");
        }
    }

    /// <summary>
    /// Register an update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    private void RegisterServerUpdatePacketHandler(ServerUpdatePacketId packetId, ServerPacketHandler handler) {
        if (_serverUpdatePacketHandlers.ContainsKey(packetId)) {
            Logger.Warn($"Tried to register already existing server update packet handler: {packetId}");
            return;
        }

        _serverUpdatePacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// Register a data-independent update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    public void RegisterServerUpdatePacketHandler(
        ServerUpdatePacketId packetId,
        EmptyServerPacketHandler handler
    ) => RegisterServerUpdatePacketHandler(packetId, (id, _) => handler(id));

    /// <summary>
    /// Register an update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <typeparam name="T">The type of the packet data passed as parameter to the handler.</typeparam>
    public void RegisterServerUpdatePacketHandler<T>(
        ServerUpdatePacketId packetId,
        GenericServerPacketHandler<T> handler
    ) where T : IPacketData => RegisterServerUpdatePacketHandler(
        packetId,
        (id, iPacket) => handler(id, (T) iPacket)
    );

    /// <summary>
    /// De-register an update packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    public void DeregisterServerUpdatePacketHandler(ServerUpdatePacketId packetId) {
        if (!_serverUpdatePacketHandlers.Remove(packetId)) {
            Logger.Warn($"Tried to remove nonexistent server update packet handler: {packetId}");
        }
    }

    #endregion

    #region Server-related connection packet handling

    /// <summary>
    /// Handle connection data received by the server.
    /// </summary>
    /// <param name="id">The ID of the client that sent the packet.</param>
    /// <param name="packet">The server connection packet.</param>
    public void HandleServerConnectionPacket(ushort id, ServerConnectionPacket packet) {
        // Execute corresponding packet handlers
        UnpackPacketDataDict(
            packet.GetPacketData(),
            (packetId, packetData) => ExecuteServerConnectionPacketHandler(id, packetId, packetData)
        );

        // Execute corresponding packet handler for addon packet data of each addon in the packet
        foreach (var idPacketDataPair in packet.GetAddonPacketData()) {
            var addonId = idPacketDataPair.Key;
            var packetDataDict = idPacketDataPair.Value.PacketData;

            UnpackPacketDataDict(
                packetDataDict,
                (packetId, packetData) => ExecuteServerAddonConnectionPacketHandler(
                    id,
                    addonId,
                    packetId,
                    packetData
                )
            );
        }
    }

    /// <summary>
    /// Executes the correct connection packet handler corresponding to this packet data.
    /// </summary>
    /// <param name="id">The ID of the client that sent the data.</param>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteServerConnectionPacketHandler(ushort id, ServerConnectionPacketId packetId, IPacketData packetData) {
        if (!_serverConnectionPacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Warn($"There is no server connection packet handler registered for ID: {packetId}");
            return;
        }

        // Invoke the packet handler for this ID directly, in contrast to the client packet handling.
        // We don't do anything game specific with server packet handler, so there's no need to do it
        // on the Unity main thread
        try {
            handler.Invoke(id, packetData);
        } catch (Exception e) {
            Logger.Error($"Exception occured while executing server connection packet handler for packet ID {packetId}:\n{e}");
        }
    }

    /// <summary>
    /// Register a connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    private void RegisterServerConnectionPacketHandler(ServerConnectionPacketId packetId, ServerPacketHandler handler) {
        if (_serverConnectionPacketHandlers.ContainsKey(packetId)) {
            Logger.Warn($"Tried to register already existing client packet handler: {packetId}");
            return;
        }

        _serverConnectionPacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// Register a data-independent connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    public void RegisterServerConnectionPacketHandler(
        ServerConnectionPacketId packetId,
        EmptyServerPacketHandler handler
    ) => RegisterServerConnectionPacketHandler(packetId, (id, _) => handler(id));

    /// <summary>
    /// Register a connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <typeparam name="T">The type of the packet data passed as parameter to the handler.</typeparam>
    public void RegisterServerConnectionPacketHandler<T>(
        ServerConnectionPacketId packetId,
        GenericServerPacketHandler<T> handler
    ) where T : IPacketData => RegisterServerConnectionPacketHandler(
        packetId,
        (id, iPacket) => handler(id, (T) iPacket)
    );

    /// <summary>
    /// De-register a connection packet handler for the given ID.
    /// </summary>
    /// <param name="packetId">The server packet ID.</param>
    public void DeregisterServerConnectionPacketHandler(ServerConnectionPacketId packetId) {
        if (!_serverConnectionPacketHandlers.Remove(packetId)) {
            Logger.Warn($"Tried to remove nonexistent server connection packet handler: {packetId}");
        }
    }

    #endregion
    
    #region Client-addon-related update packet handling

    /// <summary>
    /// Execute the packet handler for the client addon data from the update packet.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteClientAddonUpdatePacketHandler(
        byte addonId,
        byte packetId,
        IPacketData packetData
    ) {
        var addonPacketIdMessage = $"for addon ID {addonId} and packet ID {packetId}";
        var noHandlerWarningMessage =
            $"There is no client addon update packet handler registered {addonPacketIdMessage}";
        if (!_clientAddonUpdatePacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        if (!addonPacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        // Invoke the packet handler on the Unity main thread
        ThreadUtil.RunActionOnMainThread(() => {
            try {
                handler.Invoke(packetData);
            } catch (Exception e) {
                Logger.Error($"Exception occurred while executing client addon packet handler {addonPacketIdMessage}:\n{e}");
            }
        });
    }

    /// <summary>
    /// Register an update packet handler for client addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is already a handler registered for the
    /// given ID.</exception>
    public void RegisterClientAddonUpdatePacketHandler(
        byte addonId,
        byte packetId,
        ClientPacketHandler handler
    ) {
        if (!_clientAddonUpdatePacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            addonPacketHandlers = new Dictionary<byte, ClientPacketHandler>();

            _clientAddonUpdatePacketHandlers[addonId] = addonPacketHandlers;
        }

        if (addonPacketHandlers.ContainsKey(packetId)) {
            throw new InvalidOperationException("There is already an update packet handler for the given ID");
        }

        addonPacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// De-register an update packet handler for client addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is no handler registered for the
    /// given ID.</exception>
    public void DeregisterClientAddonUpdatePacketHandler(byte addonId, byte packetId) {
        const string invalidOperationExceptionMessage = "Could not remove nonexistent addon update packet handler";

        if (!_clientAddonUpdatePacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }

        if (!addonPacketHandlers.Remove(packetId)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }
    }

    /// <summary>
    /// Clear all registered client addon update packet handlers.
    /// </summary>
    public void ClearClientAddonUpdatePacketHandlers() {
        _clientAddonUpdatePacketHandlers.Clear();
    }

    #endregion
    
    #region Client-addon-related connection packet handling

    /// <summary>
    /// Execute the packet handler for the client addon data from the connection packet.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteClientAddonConnectionPacketHandler(
        byte addonId,
        byte packetId,
        IPacketData packetData
    ) {
        var addonPacketIdMessage = $"for addon ID {addonId} and packet ID {packetId}";
        var noHandlerWarningMessage =
            $"There is no client addon connection packet handler registered {addonPacketIdMessage}";
        if (!_clientAddonConnectionPacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        if (!addonPacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        // Invoke the packet handler on the Unity main thread
        ThreadUtil.RunActionOnMainThread(() => {
            try {
                handler.Invoke(packetData);
            } catch (Exception e) {
                Logger.Error($"Exception occurred while executing client addon connection packet handler {addonPacketIdMessage}:\n{e}");
            }
        });
    }

    /// <summary>
    /// Register a connection packet handler for client addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is already a handler registered for the
    /// given ID.</exception>
    public void RegisterClientAddonConnectionPacketHandler(
        byte addonId,
        byte packetId,
        ClientPacketHandler handler
    ) {
        if (!_clientAddonConnectionPacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            addonPacketHandlers = new Dictionary<byte, ClientPacketHandler>();

            _clientAddonConnectionPacketHandlers[addonId] = addonPacketHandlers;
        }

        if (addonPacketHandlers.ContainsKey(packetId)) {
            throw new InvalidOperationException("There is already a packet handler for the given ID");
        }

        addonPacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// De-register a connection packet handler for client addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is no handler registered for the
    /// given ID.</exception>
    public void DeregisterClientAddonConnectionPacketHandler(byte addonId, byte packetId) {
        const string invalidOperationExceptionMessage = "Could not remove nonexistent addon packet handler";

        if (!_clientAddonConnectionPacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }

        if (!addonPacketHandlers.Remove(packetId)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }
    }

    /// <summary>
    /// Clear all registered client addon connection packet handlers.
    /// </summary>
    public void ClearClientAddonConnectionPacketHandlers() {
        _clientAddonConnectionPacketHandlers.Clear();
    }

    #endregion

    #region Server-addon-related update packet handling

    /// <summary>
    /// Execute the packet handler for the server addon data from a client from an update packet.
    /// </summary>
    /// <param name="id">The ID of the client.</param>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteServerAddonUpdatePacketHandler(
        ushort id,
        byte addonId,
        byte packetId,
        IPacketData packetData
    ) {
        var addonPacketIdMessage = $"for addon ID {addonId} and packet ID {packetId}";
        var noHandlerWarningMessage =
            $"There is no server addon update packet handler registered {addonPacketIdMessage}";
        if (!_serverAddonUpdatePacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        if (!addonPacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        // Invoke the packet handler for this ID directly, in contrast to the client packet handling.
        // We don't do anything game specific with server packet handler, so there's no need to do it
        // on the Unity main thread
        try {
            handler.Invoke(id, packetData);
        } catch (Exception e) {
            Logger.Error($"Exception occurred while executing server addon update packet handler {addonPacketIdMessage}:\n{e}");
        }
    }

    /// <summary>
    /// Register an update packet handler for server addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is already a handler registered for the
    /// given ID.</exception>
    public void RegisterServerAddonUpdatePacketHandler(
        byte addonId,
        byte packetId,
        ServerPacketHandler handler
    ) {
        if (!_serverAddonUpdatePacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            addonPacketHandlers = new Dictionary<byte, ServerPacketHandler>();

            _serverAddonUpdatePacketHandlers[addonId] = addonPacketHandlers;
        }

        if (addonPacketHandlers.ContainsKey(packetId)) {
            throw new InvalidOperationException("There is already an update packet handler for the given ID");
        }

        addonPacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// De-register an update packet handler for server addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is no handler register for the
    /// given ID.</exception>
    public void DeregisterServerAddonUpdatePacketHandler(byte addonId, byte packetId) {
        const string invalidOperationExceptionMessage = "Could not remove nonexistent addon update packet handler";

        if (!_serverAddonUpdatePacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }

        if (!addonPacketHandlers.Remove(packetId)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }
    }

    #endregion

    #region Server-addon-related connection packet handling

    /// <summary>
    /// Execute the packet handler for the server addon data from a client from an connection packet.
    /// </summary>
    /// <param name="id">The ID of the client.</param>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="packetData">The packet data instance.</param>
    private void ExecuteServerAddonConnectionPacketHandler(
        ushort id,
        byte addonId,
        byte packetId,
        IPacketData packetData
    ) {
        var addonPacketIdMessage = $"for addon ID {addonId} and packet ID {packetId}";
        var noHandlerWarningMessage =
            $"There is no server addon connection packet handler registered {addonPacketIdMessage}";
        if (!_serverAddonUpdatePacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        if (!addonPacketHandlers.TryGetValue(packetId, out var handler)) {
            Logger.Warn(noHandlerWarningMessage);
            return;
        }

        // Invoke the packet handler for this ID directly, in contrast to the client packet handling.
        // We don't do anything game specific with server packet handler, so there's no need to do it
        // on the Unity main thread
        try {
            handler.Invoke(id, packetData);
        } catch (Exception e) {
            Logger.Error($"Exception occurred while executing server addon connection packet handler {addonPacketIdMessage}:\n{e}");
        }
    }

    /// <summary>
    /// Register a connection packet handler for server addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <param name="handler">The handler for the data.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is already a handler registered for the
    /// given ID.</exception>
    public void RegisterServerAddonConnectionPacketHandler(
        byte addonId,
        byte packetId,
        ServerPacketHandler handler
    ) {
        if (!_serverAddonConnectionPacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            addonPacketHandlers = new Dictionary<byte, ServerPacketHandler>();

            _serverAddonConnectionPacketHandlers[addonId] = addonPacketHandlers;
        }

        if (addonPacketHandlers.ContainsKey(packetId)) {
            throw new InvalidOperationException("There is already a connection packet handler for the given ID");
        }

        addonPacketHandlers[packetId] = handler;
    }

    /// <summary>
    /// De-register a connection packet handler for server addon data.
    /// </summary>
    /// <param name="addonId">The ID of the addon.</param>
    /// <param name="packetId">The ID of the packet data for the addon.</param>
    /// <exception cref="InvalidOperationException">Thrown if there is no handler register for the
    /// given ID.</exception>
    public void DeregisterServerAddonConnectionPacketHandler(byte addonId, byte packetId) {
        const string invalidOperationExceptionMessage = "Could not remove nonexistent addon connection packet handler";

        if (!_serverAddonConnectionPacketHandlers.TryGetValue(addonId, out var addonPacketHandlers)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }

        if (!addonPacketHandlers.Remove(packetId)) {
            throw new InvalidOperationException(invalidOperationExceptionMessage);
        }
    }

    #endregion
    
    #region Packet handling utilities

    /// <summary>
    /// Iterates over the given dictionary and executes the handler for each IPacketData instance inside.
    /// This method will unpack packet data collections and execute the handler for each instance in its
    /// collection.
    /// </summary>
    /// <param name="packetDataDict">The dictionary mapping packet IDs to packet data instances.</param>
    /// <param name="handler">The handler to execute for each packet data instance.</param>
    /// <typeparam name="T">The type of the packet ID.</typeparam>
    private void UnpackPacketDataDict<T>(
        Dictionary<T, IPacketData> packetDataDict,
        Action<T, IPacketData> handler
    ) {
        foreach (var idPacketDataPair in packetDataDict) {
            var packetId = idPacketDataPair.Key;
            var packetData = idPacketDataPair.Value;

            // Check if this is a collection and if so, execute the handler for each instance in it
            if (packetData is RawPacketDataCollection rawPacketDataCollection) {
                foreach (var dataInstance in rawPacketDataCollection.DataInstances) {
                    handler.Invoke(packetId, dataInstance);
                }
            } else {
                handler.Invoke(packetId, packetData);
            }
        }
    }

    /// <summary>
    /// Handle received data and leftover data and store subsequent leftover data again.
    /// </summary>
    /// <param name="buffer">Byte array of the buffer containing received data. The entirety of the array does not
    /// necessarily contain received bytes. Rather, the first <paramref name="numReceived"/> bytes are received data.
    /// </param>
    /// <param name="numReceived">Number of received bytes in the buffer.</param>
    /// <param name="leftoverData">Reference byte array that should be filled with leftover data.</param>
    /// <returns>A list of packets that were constructed from the received data.</returns>
    public static List<Packet> HandleReceivedData(byte[] buffer, int numReceived, ref byte[] leftoverData) {
        // Make a new byte array exactly the length of number of received bytes and fill it
        var receivedData = new byte[numReceived];
        for (var i = 0; i < numReceived; i++) {
            receivedData[i] = buffer[i];
        }

        var currentData = receivedData;

        // Check whether we have leftover data from the previous read, and concatenate the two byte arrays
        if (leftoverData is { Length: > 0 }) {
            currentData = new byte[leftoverData.Length + receivedData.Length];

            // Copy over the leftover data into the current data array
            for (var i = 0; i < leftoverData.Length; i++) {
                currentData[i] = leftoverData[i];
            }

            // Copy over the trimmed data into the current data array
            for (var i = 0; i < receivedData.Length; i++) {
                currentData[leftoverData.Length + i] = receivedData[i];
            }

            leftoverData = null;
        }

        // Create packets from the data
        return ByteArrayToPackets(currentData, ref leftoverData);
    }

    /// <summary>
    /// Construct packets from the given array of bytes and store excess data in the given leftover array.
    /// </summary>
    /// <param name="data">Byte array of data to construct packets from.</param>
    /// <param name="leftover">The array that should be filled with leftover data.</param>
    /// <returns>A list of packets constructed from this data.</returns>
    private static List<Packet> ByteArrayToPackets(byte[] data, ref byte[] leftover) {
        var packets = new List<Packet>();

        // Keep track of current index in the data array
        var readIndex = 0;

        // The only break from this loop is when there is no new packet to be read
        do {
            // If there is still 2 bytes to read in the data, it represents the next packet's length
            var packetLength = 0;
            var unreadDataLength = data.Length - readIndex;
            if (unreadDataLength > 1) {
                packetLength = BitConverter.ToUInt16(data, readIndex);
                readIndex += 2;
            }

            // There is no new packet, so we can break
            if (packetLength <= 0) {
                break;
            }

            // Check whether our given data array actually contains the same number of bytes as the packet length
            if (data.Length - readIndex < packetLength) {
                // There is not enough bytes in the data array to fill the requested packet with
                // So we put everything, including the packet length ushort (2 bytes) into the leftover byte array
                leftover = new byte[unreadDataLength];
                for (var i = 0; i < unreadDataLength; i++) {
                    // Make sure to index data 2 bytes earlier, since we incremented when we read the packet
                    // length ushort
                    leftover[i] = data[readIndex - 2 + i];
                }

                break;
            }

            // Read the next packet's length in bytes
            var packetData = new byte[packetLength];
            for (var i = 0; i < packetLength; i++) {
                packetData[i] = data[readIndex + i];
            }

            readIndex += packetLength;

            // Create a packet out of this byte array
            var newPacket = new Packet(packetData);

            // Add it to the list of parsed packets
            packets.Add(newPacket);
        } while (true);

        return packets;
    }

    #endregion
}
