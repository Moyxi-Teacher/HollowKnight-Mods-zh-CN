﻿using HutongGames.PlayMaker;
using SereCore;

namespace RandomizerMod.FsmStateActions
{
    internal class RandomizerSetBool : FsmStateAction
    {
        private readonly string _name;
        private readonly bool _playerdata;
        private readonly bool _val;

        public RandomizerSetBool(string boolName, bool val, bool playerdata = false)
        {
            _name = boolName;
            _val = val;
            _playerdata = playerdata;
        }

        public override void OnEnter()
        {
            if (_playerdata)
            {
                Ref.PD.SetBool(_name, _val);
            }
            else
            {
                RandomizerMod.Instance.Settings.SetBool(_val, _name);
            }

            Finish();
        }
    }
}