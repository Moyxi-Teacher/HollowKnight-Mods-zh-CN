﻿using Modding;
using SFCore;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace ExtraNotchesForExtraCharms
{
    public class ExtraNotchesForExtraCharms : Mod, ICustomMenuMod, IGlobalSettings<GlobalSettings>
    {
        internal static ExtraNotchesForExtraCharms Instance;

        public override string GetVersion() => "1.0.0.0";

        #region Global Settings
        internal static GlobalSettings globalSettings = new GlobalSettings();

        public void OnLoadGlobal(GlobalSettings s)
        {
            globalSettings = s;
        }

        public GlobalSettings OnSaveGlobal()
        {
            return globalSettings;
        }
        #endregion

        /// <summary>
        /// Stores the number of extra notches currently applied
        /// </summary>
        private int extraNotches = 0;

        public override void Initialize(Dictionary<string, Dictionary<string, GameObject>> preloadedObjects)
        {
            Log("Initializing");

            Instance = this;

            On.HeroController.Start += OnStart;
            On.GameManager.SaveGame += OnSave;
            On.GameManager.ReturnToMainMenu += OnQuit;

            Log("Initialized");
        }

        /// <summary>
        /// We will add charm notches once, when a save is loaded
        /// </summary>
        /// <param name="orig"></param>
        /// <param name="self"></param>
        private void OnStart(On.HeroController.orig_Start orig, HeroController self)
        {
            orig(self);

            Log($"Starting slots: {PlayerData.instance.charmSlots}");
            extraNotches = GetExtraNotches();
            PlayerData.instance.charmSlots += extraNotches;
            //Log($"New slots: {PlayerData.instance.charmSlots}");
            GameManager.instance.RefreshOvercharm();
        }

        private void OnSave(On.GameManager.orig_SaveGame orig, GameManager self)
        {
            PlayerData.instance.charmSlots -= extraNotches;
            //Log($"Slots reset to {PlayerData.instance.charmSlots}");
            orig(self);

            extraNotches = GetExtraNotches();
            PlayerData.instance.charmSlots += extraNotches;
            //Log($"Slots increased by {extraNotches} -> {PlayerData.instance.charmSlots}");
            GameManager.instance.RefreshOvercharm();
        }

        /// <summary>
        /// Naturally, we will remove the notches when a save is closed so they don't stack between runs
        /// </summary>
        /// <param name="orig"></param>
        /// <param name="self"></param>
        /// <param name="saveMode"></param>
        /// <param name="callback"></param>
        /// <returns></returns>
        private IEnumerator OnQuit(On.GameManager.orig_ReturnToMainMenu orig, GameManager self, 
                                    GameManager.ReturnToMainMenuSaveModes saveMode, Action<bool> callback)
        {
            PlayerData.instance.charmSlots -= extraNotches;
            extraNotches = 0;
            //Log($"Slots reset on quit: {PlayerData.instance.charmSlots}");
            GameManager.instance.RefreshOvercharm();
            return orig(self, saveMode, callback);
        }

        /// <summary>
        /// Calculates the number of extra notches to add
        /// </summary>
        /// <returns></returns>
        private int GetExtraNotches()
        {
            FieldInfo fieldInfo = typeof(CharmHelper).GetField("CustomSprites",
                                                                BindingFlags.NonPublic | BindingFlags.Static);
            List<Sprite> customCharmList = (List<Sprite>)fieldInfo.GetValue(null);
            int maxCharms = customCharmList.Count;
            int extraNotches = maxCharms / globalSettings.charmsPerNotch;
            Log($"{maxCharms} modded charms -> {extraNotches} extra charm notches");

            return extraNotches;
        }

        #region Menu Options
        public bool ToggleButtonInsideMenu => false;

        public MenuScreen GetMenuScreen(MenuScreen modListMenu, ModToggleDelegates? modToggleDelegates)
        {
            return ModMenu.CreateMenuScreen(modListMenu);
        }
        #endregion
    }
}