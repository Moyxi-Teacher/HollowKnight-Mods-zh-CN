﻿using Satchel.BetterMenus;

namespace ExtraNotchesForExtraCharms
{
    public static class ModMenu
    {
        private static Menu menu;
        private static MenuScreen menuScreen;

        /// <summary>
        /// Builds the Exaltation Expanded menu
        /// </summary>
        /// <param name="modListMenu"></param>
        /// <returns></returns>
        public static MenuScreen CreateMenuScreen(MenuScreen modListMenu)
        {
            // Declare the menu
            menu = new Menu("Exaltation Expanded Options", new Element[] { });

            // Populate main menu
            menu.AddElement(new HorizontalOption("Charms Per Notch",
                                                    "",
                                                    CostValues(),
                                                    value => ExtraNotchesForExtraCharms.globalSettings.charmsPerNotch = value + 1,
                                                    () => ExtraNotchesForExtraCharms.globalSettings.charmsPerNotch - 1));

            // Insert the menu into the overall menu
            menuScreen = menu.GetMenuScreen(modListMenu);

            return menuScreen;
        }

        /// <summary>
        /// String values for int options
        /// </summary>
        /// <returns></returns>
        private static string[] CostValues()
        {
            return new string[] { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
        }
    }
}
