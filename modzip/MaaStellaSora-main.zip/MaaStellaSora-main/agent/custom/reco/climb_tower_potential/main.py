from maa.agent.agent_server import AgentServer
from maa.custom_recognition import CustomRecognition
from maa.context import Context

from .data import Data, Parameters
from .state import State
from .interactor import PotentialInteractor
from .handler_default import ChoosePotentialHandler
from .handler_preset import RecommendationHandler
from .handler_json import AssistantPriorityHandler

from utils import logger as logger_module
from utils.dev_config import DRAW_DATA_SAVE_ENABLED
logger = logger_module.get_logger("climb_tower_potential")


@AgentServer.custom_recognition("choose_potential_recognition")
class ChoosePotentialRecognition(CustomRecognition):

    def analyze(
            self,
            context: Context,
            argv: CustomRecognition.AnalyzeArg,
    ) -> CustomRecognition.AnalyzeResult:
        """自动选择潜能的主流程。

        读取 attach 参数与已拥有潜能状态，识别当前三张潜能卡片，
        根据自定义优先级列表选出最优潜能并返回其 box；
        不满足条件时执行刷新，最终兜底识别系统推荐图标。
        选择完成后将已拥有潜能状态写回节点 attach 持久化。

        Args:
            context: maa.context.Context
            argv: CustomAction.RunArg，含当前截图与节点名

        Returns:
            CustomRecognition.AnalyzeResult: 返回 AnalyzeResult
        """
        node_name = argv.node_name
        params = self._get_params(context, node_name)
        data = Data(params=params)
        screen = PotentialInteractor(context)

        # 1. 提前获取不受左侧道具列表遮挡、且后续选择潜能流程中不需要再次获取的数据
        # （金币、刷新花费、核心潜能、潜能数量与类型等均位于界面上方/右侧，提前识别可充分利用等待时间）
        data.current_coin = screen.get_current_coin()
        data.refresh_cost = screen.get_refresh_cost()
        data.core_potential = screen.check_core_potential()
        data.potential_types = screen.get_potential_types(data.core_potential)
        if DRAW_DATA_SAVE_ENABLED and data.params.potential_source != "enhance":
            data.level_upped = screen.check_level_upped()

        # 2. 加载相应的潜能处理类
        if data.params.handler == "json":
            handler = AssistantPriorityHandler(screen, data)
        elif data.params.handler == "preset":
            handler = RecommendationHandler(screen, data)
        # elif data.params.handler == "preset+bag":
        #     handler = RecommendationPlusBagScanHandler(screen, data)
        else: # default
            handler = ChoosePotentialHandler(screen, data)

        # 3. 等待左方获得道具列表消失（仅初次进入时可能存在，刷新后不会重复出现）
        # 确保后续读取左侧潜能的潜能名称、推荐图标时不会被遮挡；若发生等待会自动更新最新截图
        handler.wait_for_item_list_gone()

        # 4. 进入潜能选择与刷新循环
        while True:
            # 获取潜能数据，并选择潜能
            potential = handler.read_potentials_info().choose()

            # 如果已启用潜能抽取数据保存功能，且当前潜能不是核心潜能，保存当前潜能抽取数据
            if DRAW_DATA_SAVE_ENABLED and "preset" in data.params.handler and not data.core_potential:
                State.potential_draw_info.add(data)

            if potential:
                break
            elif data.refreshable:
                logger.info("没有找到符合条件的潜能，尝试刷新")
                refresh_result = handler.refresh()
                if not refresh_result:
                    logger.error(f"刷新潜能失败。本错误为罕见错误，为保证爬塔质量，将结束任务")
                    context.tasker.post_stop()
                    return CustomRecognition.AnalyzeResult(box=None, detail={})
            else:
                logger.info("[潜能选择] 没有找到符合条件的潜能，将按照保底顺序选择")
                potential = handler.choose_fallback_potential()
                break

        # 点击潜能
        click_result = handler.pick(potential)
        if not click_result:
            logger.error(f"点击潜能失败。本错误为罕见错误，为保证爬塔质量，将结束任务")
            context.tasker.post_stop()
            return CustomRecognition.AnalyzeResult(box=None, detail={})

        # 保存已选潜能数据到状态类中
        if isinstance(handler, (AssistantPriorityHandler, RecommendationHandler)):
            State.owned_potentials.save(
                potential,
                handler=handler.HANDLER_TYPE,
            )

        return CustomRecognition.AnalyzeResult(box=potential.box, detail={})

    @staticmethod
    def _get_params(context: Context, node_name: str) -> Parameters:
        """获取节点 attach 中的所有参数，缺失时返回安全默认值。

        Args:
            context: maa.context.Context
            node_name: 当前节点名称，用于动态获取节点数据

        Returns:
            Parameters: 参数对象，包含常用字段（根据 attach 可选）：
                - potential_source (str): 潜能来源标识（例如 "enhance"）。
                - max_refresh_count (int): 最大刷新次数；0 表示禁用刷新。
                - reserved_coin (int): 预留金币，计算可用金币时需减去此值。
                - priority_list (list): json自定义优先级列表，用于按优先级选择潜能。
                - owned_potentials (dict): 已拥有潜能的状态信息。
                - handler (str): 使用的处理器类型（如 "json"、"preset" 等）。
                - environment (str): 塔难度环境。
                - threshold_coef_str (str): 刷新阈值系数字符串配置。
                - threshold_decay_str (str): 刷新阈值衰减系数字符串配置。
        """
        node_data = context.get_node_data(node_name)
        attach = node_data.get("attach", {})
        params = Parameters(**attach)
        return params
