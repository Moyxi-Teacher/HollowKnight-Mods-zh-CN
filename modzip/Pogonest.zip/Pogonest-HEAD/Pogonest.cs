﻿using Modding;
using MonoMod.Cil;
using MonoMod.RuntimeDetour;
using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace Pogonest {
    public class Pogonest: Mod {
        new public string GetName() => "Pogonest";
        public override string GetVersion() => "1.0.0.0";

        private static MethodInfo origNailTriggerEnter = typeof(NailSlash).GetMethod("orig_OnTriggerEnter2D", BindingFlags.NonPublic | BindingFlags.Instance);
        private ILHook nailTriggerHook;

        public override void Initialize(Dictionary<string, Dictionary<string, GameObject>> preloadedObjects) {
            nailTriggerHook = new ILHook(origNailTriggerEnter, nailTrigger);
        }

        private void nailTrigger(ILContext il) {
            ILCursor cursor = new ILCursor(il).Goto(0);
            cursor.GotoNext(i => i.MatchLdcR4(270));
            cursor.GotoNext(i => i.MatchStloc(0));
            cursor.EmitDelegate<Func<Int32, Int32>>(j => { return 11; });
        }
    }
}