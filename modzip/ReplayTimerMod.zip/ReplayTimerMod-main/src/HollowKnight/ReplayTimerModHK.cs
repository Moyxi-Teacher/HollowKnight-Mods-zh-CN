#if HOLLOW_KNIGHT_BUILD
using System.IO;
using System.Reflection;
using Modding;

namespace ReplayTimerMod
{
    public class ReplayTimerModHK : Mod
    {
        private FrameRecorder frameRecorder = null!;
        private GhostPlayback ghostPlayback = null!;
        private ReplayUI replayUI = null!;
        private RoomTimerHUD roomTimerHUD = null!;
        private ReplaySelectionState replaySelectionState = null!;

        private bool lateInitDone = false;

        public static ReplayTimerModHK? Instance { get; private set; }

        public override string GetVersion() =>
            Assembly.GetExecutingAssembly().GetName().Version?.ToString() ?? "0.0.0";

        public override void Initialize()
        {
            Instance = this;
            Log("Initialize");

            GameHooks.Init();

            string baseDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) ?? ".";

            // HK build uses lightweight in-memory config backing for now.
            GhostSettings.Init(baseDirectory);

            string dataDir = Path.Combine(Path.Combine(baseDirectory, "ReplayMod"), "data");
            DataStore.Init(dataDir);
            
            replaySelectionState = new ReplaySelectionState();
            PBManager.SetSelectionState(replaySelectionState);
            PBManager.Init();

            frameRecorder = new FrameRecorder();
            ghostPlayback = new GhostPlayback();
            ghostPlayback.SetSelectionState(replaySelectionState);
            replayUI = new ReplayUI();
            roomTimerHUD = new RoomTimerHUD();

            RoomTracker.Init();

            RoomTracker.OnRoomEnter += OnRoomEnter;
            RoomTracker.OnRoomExit += OnRoomExit;
            RoomTracker.OnRecordingDiscarded += OnRecordingDiscarded;

#if V1221
            ModHooks.Instance.HeroUpdateHook += OnHeroUpdate;
#else
            ModHooks.HeroUpdateHook += OnHeroUpdate;
#endif
        }

        private void OnHeroUpdate()
        {
            TryLateInit();

            bool shouldTick = false;
            try { shouldTick = LoadRemover.ShouldTick(); } catch { Log("couldnt check tick timer"); }

            RoomTracker.Tick(shouldTick);
            frameRecorder.Tick(shouldTick);
            ghostPlayback.Tick(shouldTick);
            replayUI.Tick();
            roomTimerHUD.Tick(shouldTick);
        }

        private void TryLateInit()
        {
            if (lateInitDone) return;
            if (HeroController.instance == null) return;

            lateInitDone = true;
            Log("Hero ready - setting up UI and ghost");
            ghostPlayback.Setup();
            replayUI.Setup();
            roomTimerHUD.Setup();
        }

        private void OnRoomEnter(string sceneName, string entryFromScene)
        {
            if (!GhostSettings.TrackingEnabled)
            {
                // Start playback but don't record.
                ghostPlayback.StartPlayback(sceneName, entryFromScene);
                return;
            }

            frameRecorder.StartRecording();
            ghostPlayback.StartPlayback(sceneName, entryFromScene);
        }

        private void OnRoomExit(string sceneName, string entryFromScene, string exitToScene, float lrTime)
        {
            ghostPlayback.StopPlayback();

            if (!GhostSettings.TrackingEnabled)
            {
                frameRecorder.DiscardRecording();
                return;
            }

            RoomKey key = new RoomKey(sceneName, entryFromScene, exitToScene);

            bool saveAllRuns = GhostSettings.SaveAllRunsEnabled;

            if (!saveAllRuns && !PBManager.WouldBePB(key, lrTime))
            {
                frameRecorder.DiscardRecording();
                return;
            }

            RecordedRoom? recording = frameRecorder.FinishRecording(key, lrTime);
            if (recording == null)
                return;

            var result = PBManager.Evaluate(recording, saveAllRuns);
            if (result.Kind == ResultKind.FirstRun
                || result.Kind == ResultKind.NewPB
                || result.Kind == ResultKind.SavedHistory)
                replayUI.OnPBUpdated();
        }

        private void OnRecordingDiscarded()
        {
            ghostPlayback.StopPlayback();
            frameRecorder.DiscardRecording();
        }
    }
}
#endif